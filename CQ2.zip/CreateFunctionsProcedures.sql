--*********************************************************************
--*********************************************************************
--**** Create all functions
--*********************************************************************
--*********************************************************************

GO
CREATE FUNCTION [HIVE].[fnDate2Str]
(
	@Date DATETIME
)
RETURNS VARCHAR(100)
AS
BEGIN

	DECLARE @timezone_offset_string VARCHAR(8)
	DECLARE @timezone_offset VARCHAR(2)
	
    -- Get Timezone offset to create xml acceptable datetimes
	SELECT	@timezone_offset = DATEDIFF(hh,GETDATE(),GETUTCDATE()),
			@timezone_offset_string = CASE WHEN @timezone_offset<9 THEN '-0' ELSE '' END + @timezone_offset + ':00'
   
	RETURN convert(varchar(50),@Date,126)+@timezone_offset_string 

END
GO
GO
CREATE FUNCTION HIVE.fnHasUserRole 
(
	@ProjectID VARCHAR(50),
	@UserID VARCHAR(50),
	@Role VARCHAR(50)
)
RETURNS BIT
AS
BEGIN
	DECLARE @HasRole BIT
	SELECT @HasRole = 0

	SELECT @HasRole = 1
		FROM PM.PM_PROJECT_USER_ROLES
		WHERE project_id = @ProjectID AND [user_id] = @UserID
			AND (user_role_cd = @Role
				OR (user_role_cd = 'ADMIN' AND @Role IN ('DATA_OBFSC','DATA_AGG','DATA_LDS','DATA_DEID','DATA_PROT','USER','MANAGER'))
				OR (user_role_cd = 'MANAGER' AND @Role IN ('DATA_OBFSC','DATA_AGG','DATA_LDS','DATA_DEID','USER'))
				OR (user_role_cd = 'USER' AND @Role IN ('DATA_OBFSC','DATA_AGG','DATA_LDS','DATA_DEID'))
				OR (user_role_cd = 'DATA_PROT' AND @Role IN ('DATA_OBFSC','DATA_AGG','DATA_LDS','DATA_DEID','USER'))
				OR (user_role_cd = 'DATA_DEID' AND @Role IN ('DATA_OBFSC','DATA_AGG','DATA_LDS','USER'))
				OR (user_role_cd = 'DATA_LDS' AND @Role IN ('DATA_OBFSC','DATA_AGG'))
				OR (user_role_cd = 'DATA_AGG' AND @Role IN ('DATA_OBFSC'))
			)

	RETURN @HasRole
END
GO
GO
CREATE FUNCTION [HIVE].[fnSketchEstimate]
(
	@V FLOAT,
	@N INT,
	@J INT,
	@Bins INT,
	@Scale INT
)
RETURNS FLOAT
AS
BEGIN
	
	DECLARE @Estimate FLOAT

	SELECT @Estimate = FLOOR(M*F+0.5)
		FROM (
			SELECT 
				(CASE WHEN (E >= 5*@Bins) OR (@N = @Bins) THEN E*@Scale ELSE -fBins*LOG((fBins-fN)/fBins)*@Scale END) M, 
				(CASE WHEN @N=0 THEN 1 ELSE @J/fN END) F
			FROM (
				SELECT fN, fBins,
					fN/(@V/CAST(1073741824 AS FLOAT))*fN E
				FROM (
					SELECT CAST(@N AS FLOAT) fN, CAST(@Bins AS FLOAT) fBins
				) t
			) t
		) t

	RETURN @Estimate

END
GO
GO
CREATE FUNCTION [HIVE].[fnStr2Bit]
(
	@Str NVARCHAR(MAX)
)
RETURNS BIT
AS
BEGIN

	RETURN (CASE WHEN @Str = 'true' THEN 1 ELSE 0 END)

END
GO
GO
CREATE FUNCTION [HIVE].[fnStr2BitDefault]
(
	@Str NVARCHAR(MAX),
	@Default BIT
)
RETURNS BIT
AS
BEGIN

	RETURN (CASE @Str WHEN 'true' THEN 1 WHEN 'false' THEN 0 ELSE @Default END)

END
GO
GO
CREATE FUNCTION [HIVE].[fnXMLValue]
(
	@Tag NVARCHAR(MAX),
	@Value NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN

	RETURN (CASE WHEN @Value IS NULL THEN '/>' ELSE '>'+REPLACE(REPLACE(REPLACE(@Value,'&','&amp;'),'>','&gt;'),'<','&lt;') + '</'+@Tag+'>' END)

END
GO

--*********************************************************************
--*********************************************************************
--**** Create all procedures
--*********************************************************************
--*********************************************************************

GO
CREATE PROCEDURE [CRC].[uspGetResponse]
	@Service VARCHAR(100) = NULL,
	@Operation VARCHAR(100) = NULL,
	@RequestXML XML = NULL,
	@UserID VARCHAR(50) = NULL,
	@RequestType VARCHAR(100) = NULL OUTPUT,
	@ResponseXML XML = NULL OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Determine the procedure that will process the operation
	DECLARE @opProc VARCHAR(100)
	SELECT @opProc = OBJECT_SCHEMA_NAME(@@PROCID) + '.'
						+ (CASE @Operation
							WHEN 'request'		THEN 'uspRunPSM'
							WHEN 'pdorequest'	THEN 'uspRunPDO'
							WHEN 'getNameInfo'	THEN 'uspRunGetNameInfo'
							ELSE NULL END)

	-- Generate the ResponseXML using the standard method
	EXEC HIVE.uspGetStandardResponse
			@RequestXML = @RequestXML,
			@SendingAppName = 'CRC Cell',
			@SendingAppVersion = '1.6',
			@ReceivingAppName = 'i2b2_QueryTool',
			@ReceivingAppVersion = '1.6',
			@Operation = @Operation,
			@OperationProcedure = @opProc,
			@MessageTag = 'ns5:response',
			@MessageNamespaces = 'xmlns:ns2="http://www.i2b2.org/xsd/hive/pdo/1.1/" xmlns:ns4="http://www.i2b2.org/xsd/cell/crc/psm/1.1/" xmlns:ns3="http://www.i2b2.org/xsd/cell/crc/pdo/1.1/" xmlns:tns="http://axis2.crc.i2b2.harvard.edu" xmlns:ns9="http://www.i2b2.org/xsd/cell/ont/1.1/" xmlns:ns5="http://www.i2b2.org/xsd/hive/msg/1.1/" xmlns:ns6="http://www.i2b2.org/xsd/cell/crc/psm/querydefinition/1.1/" xmlns:ns7="http://www.i2b2.org/xsd/cell/crc/psm/analysisdefinition/1.1/" xmlns:ns10="http://www.i2b2.org/xsd/hive/msg/result/1.1/" xmlns:ns8="http://www.i2b2.org/xsd/cell/pm/1.1/"',
			@RequestType = @RequestType OUTPUT,
			@ResponseXML = @ResponseXML OUTPUT

END
GO
GO
CREATE PROCEDURE [CRC].[uspRunGetNameInfo]
	@Operation VARCHAR(100),
	@RequestXML XML,
	@RequestType VARCHAR(100) OUTPUT,
	@StatusType NVARCHAR(100) OUTPUT,
	@StatusText NVARCHAR(MAX) OUTPUT,
	@MessageBody NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Declare Variables
	-- ***************************************************************************
	-- ***************************************************************************

	-- Declare request variables
	DECLARE @DomainID VARCHAR(50)
	DECLARE @Username VARCHAR(50)
	DECLARE @ProjectID VARCHAR(50)
	DECLARE @ResultWaittimeMS BIGINT
	DECLARE @UserID VARCHAR(100)
	DECLARE @GroupID VARCHAR(100)
	DECLARE @FetchSize INT
	DECLARE @GetNameInfoCategory VARCHAR(100)
	DECLARE @GetNameInfoMax INT
	DECLARE @GetNameInfoStrategy VARCHAR(100)
	DECLARE @GetNameInfoMatchStr VARCHAR(MAX)
	DECLARE @GetNameInfoCreateDateStr VARCHAR(100)
	DECLARE @GetNameInfoCreateDate DATETIME
	DECLARE @GetNameInfoAscending VARCHAR(50)
	DECLARE @SortAsc INT
	
	-- Declare response variables
	DECLARE @Response VARCHAR(MAX)
	DECLARE @ConditionType VARCHAR(100)
	DECLARE @ConditionText VARCHAR(1000)
	
	-- Declare processing variables
	DECLARE @ProcName VARCHAR(100)
	DECLARE @HaltTime DATETIME
	DECLARE @DelayMS FLOAT
	DECLARE @DelayTime VARCHAR(20)


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Parse Request Message
	-- ***************************************************************************
	-- ***************************************************************************

	-- Extract variables from the request message
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns6,
		'http://www.i2b2.org/xsd/cell/crc/psm/1.1/' as ns4
	)
	SELECT	-- message_header
			@DomainID = x.value('message_header[1]/security[1]/domain[1]','varchar(50)'),
			@Username = x.value('message_header[1]/security[1]/username[1]','VARCHAR(50)'),
			@ProjectID = x.value('message_header[1]/project_id[1]','VARCHAR(50)'),
			-- request_header
			@ResultWaittimeMS = x.value('request_header[1]/result_waittime_ms[1]','INT'),
			-- message_body - psmheader
			@RequestType = x.value('message_body[1]/ns4:psmheader[1]/request_type[1]','VARCHAR(100)'),
			-- message_body - request
			@UserID = x.value('message_body[1]/ns4:request[1]/user_id[1]','VARCHAR(100)'),
			@GroupID = x.value('message_body[1]/ns4:request[1]/group_id[1]','VARCHAR(100)'),
			@FetchSize = x.value('message_body[1]/ns4:request[1]/fetch_size[1]','INT'),
			-- message_body - get_name_info
			@GetNameInfoCategory = x.value('message_body[1]/ns4:get_name_info[1]/@category[1]','VARCHAR(100)'),
			@GetNameInfoMax = x.value('message_body[1]/ns4:get_name_info[1]/@max[1]','INT'),
			@GetNameInfoStrategy = x.value('message_body[1]/ns4:get_name_info[1]/match_str[1]/@strategy[1]','VARCHAR(100)'),
			@GetNameInfoMatchStr = x.value('message_body[1]/ns4:get_name_info[1]/match_str[1]','VARCHAR(MAX)'),
			@GetNameInfoCreateDateStr = x.value('message_body[1]/ns4:get_name_info[1]/create_date[1]','VARCHAR(100)'),
			@GetNameInfoAscending = x.value('message_body[1]/ns4:get_name_info[1]/ascending[1]','VARCHAR(50)')
		FROM @RequestXML.nodes('ns6:request[1]') AS R(x)
			CROSS APPLY (SELECT x.value('message_body[1]/ns4:request[1]/query_master_id[1]','VARCHAR(100)') query_master_id) q

	-- Set default values
 	SELECT	@FetchSize = IsNull(@FetchSize,99999999),
  			@ResultWaittimeMS = IsNull(@ResultWaittimeMS,180000),
 			@HaltTime = DateAdd(ms,@ResultWaittimeMS,GetDate()),
 			@DelayMS = 100,
			@ConditionType = 'DONE',
 			@ConditionText = 'DONE',
 			@StatusType = 'DONE',
 			@StatusText = 'DONE'

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Security
	-- ***************************************************************************
	-- ***************************************************************************

	IF (IsNull(@Username,'') = '') OR (@Username <> @UserID)
	BEGIN
		RETURN;
	END

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Return Results
	-- ***************************************************************************
	-- ***************************************************************************

	SELECT @UserID = ISNULL(@UserID,@Username),
		 @FetchSize = ISNULL(@GetNameInfoMax, @FetchSize),
		 @SortAsc=(CASE WHEN @GetNameInfoAscending='true' THEN 1 ELSE -1 END),
		 @GetNameInfoCreateDate = (CASE WHEN ISNULL(@GetNameInfoCreateDateStr,'')='' THEN NULL ELSE CAST(LEFT(@GetNameInfoCreateDateStr,LEN(@GetNameInfoCreateDateStr)-6) AS DATETIME) END)

	DECLARE @HasManagerRole BIT
	SELECT @HasManagerRole = HIVE.fnHasUserRole(@ProjectID,@UserID,'MANAGER')

	SELECT @Response = CAST((
		SELECT	@ConditionType 'status/condition/@type',
 				@ConditionText 'status/condition',
				( -- Query Master
					SELECT
						m.QUERY_MASTER_ID 'query_master_id',
						REPLACE(REPLACE(REPLACE(m.NAME,'&','&amp;'),'<','&lt;'),'>','&gt;') 'name',
						m.USER_ID 'user_id',
						m.GROUP_ID 'group_id',
						m.MASTER_TYPE_CD 'master_type_cd',
						m.PLUGIN_ID 'plugin_id',
						HIVE.fnDate2Str(m.CREATE_DATE) 'create_date'
					FROM ..QT_QUERY_MASTER m
					WHERE m.QUERY_MASTER_ID IN (
						SELECT TOP(@FetchSize) m.QUERY_MASTER_ID
						FROM ..QT_QUERY_MASTER m
						WHERE ISNULL(m.DELETE_FLAG,'A') <> 'D'
							AND m.USER_ID = (CASE WHEN @HasManagerRole = 1 THEN m.USER_ID ELSE ISNULL(@UserID,m.USER_ID) END)
							AND m.GROUP_ID = ISNULL(@GroupID,m.GROUP_ID)
							AND m.NAME LIKE (CASE 
								WHEN ISNULL(@GetNameInfoMatchStr,'')='' THEN m.NAME
								WHEN @GetNameInfoStrategy='contains' THEN '%'+@GetNameInfoMatchStr+'%'
								WHEN @GetNameInfoStrategy='exact' THEN @GetNameInfoMatchStr
								WHEN @GetNameInfoStrategy='right' THEN '%'+@GetNameInfoMatchStr
								ELSE @GetNameInfoMatchStr+'%'
								END)
							AND DATEDIFF(ss,CREATE_DATE,ISNULL(@GetNameInfoCreateDate,CREATE_DATE))*@SortAsc <= 0
						ORDER BY QUERY_MASTER_ID*@SortAsc
					)
					ORDER BY m.QUERY_MASTER_ID DESC
					FOR XML PATH('query_master'), TYPE
				)
 			FROM (SELECT '' A) A
 			FOR XML PATH(''), TYPE
 		) AS NVARCHAR(MAX) )

	SELECT	@MessageBody = 
				'<message_body>'
				+ '<ns4:response xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="ns4:master_responseType">'
				+ @Response
				+ '</ns4:response>'
				+ '</message_body>'

END
GO
GO
CREATE PROCEDURE [CRC].[uspRunPDO]
	@Operation VARCHAR(100),
	@RequestXML XML,
	@RequestType VARCHAR(100) OUTPUT,
	@StatusType NVARCHAR(100) OUTPUT,
	@StatusText NVARCHAR(MAX) OUTPUT,
	@MessageBody NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Declare Variables
	-- ***************************************************************************
	-- ***************************************************************************

	-- Declare schema variables
	DECLARE @Schema VARCHAR(100)
	DECLARE @OntSchema VARCHAR(100)

	-- Declare request variables
	DECLARE @DomainID VARCHAR(50)
	DECLARE @Username VARCHAR(50)
	DECLARE @ProjectID VARCHAR(50)
	DECLARE @ResultWaittimeMS BIGINT

	DECLARE @EstimatedTime INT
	DECLARE @PatientSetLimit INT

	-- Request XML wrappers

	DECLARE @PDORequest XML
	DECLARE @InputList XML
	DECLARE @FilterList XML
	--DECLARE @OutputOption XML

	DECLARE @FactPrimaryKey XML
	DECLARE @FactOutputOption XML

	DECLARE @PatientPrimaryKey XML
	DECLARE @PatientOutputOption XML

	-- Input list variables

	DECLARE @InputPatientListMin INT
	DECLARE @InputPatientListMax INT
	DECLARE @InputPatientListSet INT
	DECLARE @InputPatientListAll BIT
	DECLARE @InputPidListMin INT
	DECLARE @InputPidListMax INT

	DECLARE @InputEncounterListMin INT
	DECLARE @InputEncounterListMax INT
	DECLARE @InputEncounterListSet INT
	DECLARE @InputEncounterListAll BIT
	DECLARE @InputEidListMin INT
	DECLARE @InputEidListMax INT

	DECLARE @InputPatientListSize INT
	DECLARE @InputPidListSize INT
	DECLARE @InputEncounterListSize INT
	DECLARE @InputEidListSize INT

	-- Output option variables

	DECLARE @OutputName VARCHAR(50)
	DECLARE @OutputObservationWithModifiers BIT
	DECLARE @OutputObservationFilter VARCHAR(50)
	DECLARE @OutputObservationFilterN INT

	-- Observation key variables

	DECLARE @PrimaryKeyPatientID VARCHAR(200)
	DECLARE @PrimaryKeyPatientNum INT
	DECLARE @PrimaryKeyEventID VARCHAR(200)
	DECLARE @PrimaryKeyEventNum INT

	-- Declare response variables
	DECLARE @Response VARCHAR(MAX)
	DECLARE @ConditionType VARCHAR(100)
	DECLARE @ConditionText VARCHAR(1000)
	
	-- Declare processing variables
	DECLARE @ProcName VARCHAR(100)
	DECLARE @HaltTime DATETIME
	DECLARE @DelayMS FLOAT
	DECLARE @DelayTime VARCHAR(20)

	-- User roles
	DECLARE @HasProtectedAccess BIT
	DECLARE @HasDeidAccess BIT

	-- Additional variables for loops
	DECLARE @p INT
	DECLARE @i INT
	DECLARE @MaxP INT
	DECLARE @MaxI INT

	DECLARE @SQL NVARCHAR(MAX)

	-- Temp tables for input lists

	CREATE TABLE #InputPatientList (
		patient_num INT NOT NULL,
		sort_index INT
	)
	
	CREATE TABLE #InputPidList (
		patient_ide VARCHAR(200) NOT NULL,
		patient_ide_source VARCHAR(50) NOT NULL,
		sort_index INT
	)

	CREATE TABLE #InputEncounterList (
		encounter_num INT NOT NULL,
		sort_index INT
	)

	CREATE TABLE #InputEidList (
		encounter_ide VARCHAR(200) NOT NULL,
		encounter_ide_source VARCHAR(50) NOT NULL,
		sort_index INT
	)

	-- Temp tables for output observation sets

	CREATE TABLE #PanelNames (
		PanelID INT IDENTITY(1,1) PRIMARY KEY,
		PanelName VARCHAR(255),
		PanelXML XML
	)

	CREATE TABLE #ObservationSet (
		PanelID INT NOT NULL,
		encounter_num INT NOT NULL,
		patient_num INT NOT NULL,
		concept_cd VARCHAR(50) NOT NULL,
		provider_id VARCHAR(50) NOT NULL,
		start_date DATETIME NOT NULL,
		modifier_cd VARCHAR(100) NOT NULL,
		instance_num INT NOT NULL
	)

	-- Temp tables for filters

	CREATE TABLE #Panels (
		panel_number INT PRIMARY KEY,
		panel_date_from DATETIME,
		panel_date_to DATETIME,
		panel_accuracy_scale INT,
		invert TINYINT,
		panel_timing VARCHAR(100),
		total_item_occurrences INT,
		items XML,
		estimated_count INT,
		has_multiple_occurrences TINYINT,
		has_date_constraint TINYINT,
		has_date_range_constraint TINYINT,
		has_modifier_constraint TINYINT,
		has_value_constraint TINYINT,
		has_complex_value_constraint TINYINT,
		all_concept_paths TINYINT,
		number_of_items INT,
		panel_table VARCHAR(200),
		process_order INT,
		panel_sql NVARCHAR(MAX),
		actual_count INT,
		run_time_ms INT
	)							

	CREATE TABLE #Items (
		item_id INT IDENTITY(1,1) PRIMARY KEY,
		panel_number INT,
		item_key VARCHAR(900),
		item_type VARCHAR(100),
		item_key_id INT,
		item_table VARCHAR(200),
		item_path VARCHAR(700),
		concept_path_id INT,
		modifier_key VARCHAR(900),
		modifier_path VARCHAR(700),
		value_constraint VARCHAR(MAX),
		value_operator VARCHAR(MAX),
		value_unit_of_measure VARCHAR(MAX),
		value_type VARCHAR(MAX),
		c_facttablecolumn VARCHAR(50),
		c_tablename VARCHAR(50),
		c_columnname VARCHAR(50),
		c_columndatatype VARCHAR(50),
		c_operator VARCHAR(10),
		c_dimcode VARCHAR(700),
		c_totalnum INT,
		valid TINYINT,
		ont_table VARCHAR(255)
	)

	-- Temp tables for output options

	CREATE TABLE #ColumnList (
		PDOSet VARCHAR(100) NOT NULL,
		ColumnName VARCHAR(100) NOT NULL,
		DataTable VARCHAR(100),
		DataColumn VARCHAR(100),
		DataType VARCHAR(50),
		UseExactXML INT,
		IsTechData INT,
		IsBlob INT,
		IsKey INT,
		IsParam INT,
		CodeNameColumn VARCHAR(100),
		SourceColumn VARCHAR(100),
		StatusColumn VARCHAR(100),
		ColumnDescriptor VARCHAR(200),
		SortOrder INT
	)
	ALTER TABLE #ColumnList ADD PRIMARY KEY (PDOSet, ColumnName)

	CREATE TABLE #OutputSetSQL (
		SetID INT IDENTITY(1,1) PRIMARY KEY,
		PDOSet VARCHAR(100),
		selecttype VARCHAR(50),
		onlykeys BIT,
		blob BIT,
		techdata BIT,
		withmodifiers BIT,
		ColumnListSQL NVARCHAR(MAX),
		DataTableSQL NVARCHAR(MAX),
		SetSQL NVARCHAR(MAX),
		SetStr VARCHAR(MAX),
	)

	-- Get the schema
	SELECT @Schema = OBJECT_SCHEMA_NAME(@@PROCID)


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Parse Request Message
	-- ***************************************************************************
	-- ***************************************************************************

	-- Extract variables from the request message
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns6,
		'http://www.i2b2.org/xsd/cell/crc/pdo/1.1/' as ns3
	), Wrappers AS (
		SELECT	
			x.query('message_header[1]/*') MessageHeader,
			x.query('request_header[1]/*') RequestHeader,
			x.query('message_body[1]/ns3:pdoheader[1]/*') PDOHeader,
			x.query('message_body[1]/ns3:request[1]/*') PDORequest,
			x.query('message_body[1]/ns3:request[1]/input_list[1]/*') InputList
		FROM @RequestXML.nodes('ns6:request[1]') AS R(x)
	)
	SELECT	-- message_header
			@DomainID = MessageHeader.value('security[1]/domain[1]','varchar(50)'),
			@Username = MessageHeader.value('security[1]/username[1]','VARCHAR(50)'),
			@ProjectID = MessageHeader.value('project_id[1]','VARCHAR(50)'),
			-- request_header
			@ResultWaittimeMS = RequestHeader.value('result_waittime_ms[1]','INT'),
			-- message_body - pdoheader
			@RequestType = PDOHeader.value('request_type[1]','VARCHAR(100)'),
			@EstimatedTime = PDOHeader.value('estimated_time[1]','INT'),
			@PatientSetLimit = PDOHeader.value('patient_set_limit[1]','INT'),
			-- message_body - request
			@PDORequest = PDORequest,
			@InputList = InputList,
			@FilterList = PDORequest.query('filter_list[1]'),
			-- Input List
			@InputPatientListMin = InputList.value('patient_list[1]/@min[1]','INT'),
			@InputPatientListMax = InputList.value('patient_list[1]/@max[1]','INT'),
			@InputPatientListSet = InputList.value('patient_list[1]/patient_set_coll_id[1]','INT'),
			@InputPatientListAll = HIVE.fnStr2Bit(InputList.value('patient_list[1]/entire_patient_set[1]','VARCHAR(10)')),
			@InputPidListMin = InputList.value('pid_list[1]/@min[1]','INT'),
			@InputPidListMax = InputList.value('pid_list[1]/@max[1]','INT'),
			@InputEncounterListMin = InputList.value('event_list[1]/@min[1]','INT'),
			@InputEncounterListMax = InputList.value('event_list[1]/@max[1]','INT'),
			@InputEncounterListSet = InputList.value('event_list[1]/patient_event_coll_id[1]','INT'),
			@InputEncounterListAll = HIVE.fnStr2Bit(InputList.value('input_list[1]/entire_encounter_set[1]','VARCHAR(10)')),
			@InputEidListMin = InputList.value('eid_list[1]/@min[1]','INT'),
			@InputEidListMax = InputList.value('eid_list[1]/@max[1]','INT'),
			-- Output List
			@OutputName = ISNULL(PDORequest.value('output_option[1]/@name[1]','VARCHAR(50)'),'asattributes'),
			@OutputObservationWithModifiers = HIVE.fnStr2BitDefault(PDORequest.value('output_option[1]/observation_set[1]/@withmodifiers[1]','VARCHAR(10)'),1),
			@OutputObservationFilter = PDORequest.value('output_option[1]/observation_set[1]/@selectionfilter[1]','VARCHAR(50)'),
			-- Primary Key
			@PrimaryKeyPatientID = (CASE WHEN @RequestType = 'get_patient_by_primary_key'
											THEN PDORequest.value('patient_primary_key[1]/patient_id[1]','VARCHAR(200)')
										ELSE PDORequest.value('fact_primary_key[1]/patient_id[1]','VARCHAR(200)')
										END),
			@PrimaryKeyEventID = PDORequest.value('fact_primary_key[1]/event_id[1]','VARCHAR(200)')
		FROM Wrappers

	IF @PrimaryKeyPatientID IS NOT NULL
	BEGIN
		SELECT @PrimaryKeyPatientNum = (
			SELECT TOP 1 patient_num
			FROM ..PATIENT_MAPPING
			WHERE patient_ide = @PrimaryKeyPatientID
				AND patient_ide_source = 'HIVE'
				AND project_id = @ProjectID
		)
	END

	IF @PrimaryKeyEventID IS NOT NULL
	BEGIN
		SELECT @PrimaryKeyEventNum = (
			SELECT TOP 1 encounter_num
			FROM ..ENCOUNTER_MAPPING
			WHERE encounter_ide = @PrimaryKeyEventID
				AND encounter_ide_source = 'HIVE'
				AND project_id = @ProjectID
		)
	END

	-- Set default values
 	SELECT	@ResultWaittimeMS = IsNull(@ResultWaittimeMS,180000),
 			@HaltTime = DateAdd(ms,@ResultWaittimeMS,GetDate()),
 			@DelayMS = 100,
			@ConditionType = 'DONE',
 			@ConditionText = 'DONE',
 			@StatusType = 'DONE',
 			@StatusText = 'DONE'


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Security
	-- ***************************************************************************
	-- ***************************************************************************

	IF (IsNull(@Username,'') = '')
	BEGIN
		RETURN;
	END
	
	-- Check for security
	IF HIVE.fnHasUserRole(@ProjectID,@Username,'DATA_LDS')=0
	BEGIN
		-- TODO: Add error handling
		RETURN
	END
	SELECT @HasProtectedAccess = HIVE.fnHasUserRole(@ProjectID,@Username,'DATA_PROT')
	SELECT @HasDeidAccess = HIVE.fnHasUserRole(@ProjectID,@Username,'DATA_DEID')


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Get Input Lists
	-- ***************************************************************************
	-- ***************************************************************************

	IF @RequestType = 'get_patient_by_primary_key'
	BEGIN
		INSERT INTO #InputPatientList (patient_num, sort_index)
			SELECT @PrimaryKeyPatientNum, 1
			WHERE @PrimaryKeyPatientNum IS NOT NULL
	END

	IF @RequestType = 'getPDO_fromInputList'
	BEGIN

		------------------------------------------------------------------------------
		-- Get lists from request message
		------------------------------------------------------------------------------

		-- patient_list
		INSERT INTO #InputPatientList (patient_num, sort_index)
			SELECT p.z.value('.','VARCHAR(200)'), p.z.value('@index[1]','INT')
			FROM @InputList.nodes('patient_list/patient_id') as p(z)
		SELECT @InputPatientListSize = @@ROWCOUNT

		-- pid_list
		INSERT INTO #InputPidList (patient_ide, patient_ide_source, sort_index)
			SELECT p.z.value('.','VARCHAR(200)'), p.z.value('@source[1]','VARCHAR(50)'), p.z.value('@index[1]','INT')
			FROM @InputList.nodes('pid_list/pid') as p(z)
		SELECT @InputPidListSize = @@ROWCOUNT
		ALTER TABLE #InputPidList ADD PRIMARY KEY (patient_ide, patient_ide_source)

		-- encounter_list
		INSERT INTO #InputEncounterList (encounter_num, sort_index)
			SELECT p.z.value('.','VARCHAR(200)'), p.z.value('@index[1]','INT')
			FROM @InputList.nodes('event_list/event_id') as p(z)
		SELECT @InputEncounterListSize = @@ROWCOUNT

		-- eid_list
		INSERT INTO #InputEidList (encounter_ide, encounter_ide_source, sort_index)
			SELECT p.z.value('.','VARCHAR(200)'), p.z.value('@source[1]','VARCHAR(50)'), p.z.value('@index[1]','INT')
			FROM @InputList.nodes('eid_list/eid') as p(z)
		SELECT @InputEidListSize = @@ROWCOUNT
		ALTER TABLE #InputEidList ADD PRIMARY KEY (encounter_ide, encounter_ide_source)

		------------------------------------------------------------------------------
		-- Get the final input patient list
		------------------------------------------------------------------------------

		IF (@InputPatientListSize = 0) AND (@InputPatientListSet IS NOT NULL)
		BEGIN
			INSERT INTO #InputPatientList (patient_num, sort_index)
				SELECT patient_num, ROW_NUMBER() OVER (ORDER BY set_index, patient_num) sort_index
				FROM ..QT_PATIENT_SET_COLLECTION
				WHERE result_instance_id = @InputPatientListSet
			SELECT @InputPatientListSize = @@ROWCOUNT
		END

		IF (@InputPatientListSize = 0) AND (@InputPatientListAll = 1)
		BEGIN
			INSERT INTO #InputPatientList (patient_num, sort_index)
				SELECT patient_num, sort_index
				FROM (
					SELECT patient_num, ROW_NUMBER() OVER (ORDER BY patient_num) sort_index
					FROM ..PATIENT_DIMENSION
				) t
			SELECT @InputPatientListSize = @@ROWCOUNT
		END
	
		IF @InputPatientListMin IS NOT NULL
			DELETE FROM #InputPatientList WHERE sort_index < @InputPatientListMin
		IF @InputPatientListMax IS NOT NULL
			DELETE FROM #InputPatientList WHERE sort_index > @InputPatientListMax

		IF (@InputPatientListSize = 0) AND (@InputPidListSize IS NOT NULL)
		BEGIN
			INSERT INTO #InputPatientList (patient_num, sort_index)
				SELECT patient_num, sort_index
				FROM (
					SELECT patient_num, ROW_NUMBER() OVER (ORDER BY sort_index) sort_index
					FROM (
						SELECT m.patient_num, MIN(i.sort_index) sort_index
						FROM ..PATIENT_MAPPING m
							INNER JOIN #InputPidList i
								ON m.patient_ide = i.patient_ide AND m.patient_ide_source = i.patient_ide_source
						GROUP BY m.patient_num
					) t
				) i
				WHERE i.sort_index >= ISNULL(@InputPidListMin,i.sort_index)
					AND i.sort_index <= ISNULL(@InputPidListMax,i.sort_index)
		END

		------------------------------------------------------------------------------
		-- Get the final input encounter list
		------------------------------------------------------------------------------

		IF (@InputEncounterListSize = 0) AND (@InputEncounterListSet IS NOT NULL)
		BEGIN
			INSERT INTO #InputEncounterList (encounter_num, sort_index)
				SELECT encounter_num, ROW_NUMBER() OVER (ORDER BY set_index, encounter_num) sort_index
				FROM ..QT_PATIENT_ENC_COLLECTION
				WHERE result_instance_id = @InputEncounterListSet
			SELECT @InputEncounterListSize = @@ROWCOUNT
		END

		IF (@InputEncounterListSize = 0) AND (@InputEncounterListAll = 1)
		BEGIN
			INSERT INTO #InputEncounterList (encounter_num, sort_index)
				SELECT encounter_num, sort_index
				FROM (
					SELECT encounter_num, ROW_NUMBER() OVER (ORDER BY encounter_num) sort_index
					FROM ..VISIT_DIMENSION
				) t
			SELECT @InputEncounterListSize = @@ROWCOUNT
		END
	
		IF @InputEncounterListMin IS NOT NULL
			DELETE FROM #InputEncounterList WHERE sort_index < @InputEncounterListMin
		IF @InputEncounterListMax IS NOT NULL
			DELETE FROM #InputEncounterList WHERE sort_index > @InputEncounterListMax

		IF (@InputEncounterListSize = 0) AND (@InputEidListSize IS NOT NULL)
		BEGIN
			INSERT INTO #InputEncounterList (encounter_num, sort_index)
				SELECT encounter_num, sort_index
				FROM (
					SELECT encounter_num, ROW_NUMBER() OVER (ORDER BY sort_index) sort_index
					FROM (
						SELECT m.encounter_num, MIN(i.sort_index) sort_index
						FROM ..ENCOUNTER_MAPPING m
							INNER JOIN #InputEidList i
								ON m.encounter_ide = i.encounter_ide AND m.encounter_ide_source = i.encounter_ide_source
						GROUP BY m.encounter_num
					) t
				) i
				WHERE i.sort_index >= ISNULL(@InputEidListMin,i.sort_index)
					AND i.sort_index <= ISNULL(@InputEidListMax,i.sort_index)
		END

	END -- @RequestType = 'getPDO_fromInputList'

	ALTER TABLE #InputPatientList ADD PRIMARY KEY (patient_num)
	SELECT @InputPatientListSize = (SELECT COUNT(*) FROM #InputPatientList)

	ALTER TABLE #InputEncounterList ADD PRIMARY KEY (encounter_num)
	SELECT @InputEncounterListSize = (SELECT COUNT(*) FROM #InputEncounterList)

	--insert into dbo.x(x) select 'IELSet = '+isnull(cast(@InputEncounterListSet as varchar(50)),'')
	--insert into dbo.x(x) select 'IELSize = '+isnull(cast(@InputEncounterListSize as varchar(50)),'')

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Get Observation Sets
	-- ***************************************************************************
	-- ***************************************************************************

	IF @RequestType = 'get_observationfact_by_primary_key'
	BEGIN
		INSERT INTO #PanelNames (PanelName)
			SELECT NULL PanelName

		SELECT @SQL = '
			INSERT INTO #ObservationSet (PanelID,encounter_num,patient_num,concept_cd,provider_id,start_date,modifier_cd,instance_num)
				SELECT TOP(1) 1 PanelID,encounter_num,patient_num,concept_cd,provider_id,start_date,modifier_cd,instance_num
				FROM '+@Schema+'.OBSERVATION_FACT
				WHERE 1=1
			'
			+ ISNULL(' AND encounter_num = '+CAST(@PrimaryKeyEventNum AS VARCHAR(50)), '')
			+ ISNULL(' AND patient_num = '+CAST(@PrimaryKeyPatientNum AS VARCHAR(50)), '')
			+ ISNULL(' AND concept_cd = '''+REPLACE(x.value('fact_primary_key[1]/concept_cd[1]','VARCHAR(50)'),'''','''''')+'''', '')
			+ ISNULL(' AND provider_id = '''+REPLACE(x.value('fact_primary_key[1]/observer_id[1]','VARCHAR(50)'),'''','''''')+'''', '')
			+ ISNULL(' AND start_date = '''+CAST(x.value('fact_primary_key[1]/start_date[1]','DATETIME') AS VARCHAR(50))+'''', '')
			+ ISNULL(' AND modifier_cd = '''+REPLACE(x.value('fact_primary_key[1]/modifier_cd[1]','VARCHAR(100)'),'''','''''')+'''', '')
			+ ISNULL(' AND instance_num = '+CAST(x.value('fact_primary_key[1]/instance_num[1]','INT') AS VARCHAR(50)), '')
			+ ' ORDER BY encounter_num, concept_cd, provider_id, start_date, instance_num, (CASE WHEN modifier_cd = ''@'' THEN 0 ELSE 1 END), modifier_cd'
			FROM (SELECT @PDORequest.query('patient_primary_key[1]') x) t

		EXEC sp_executesql @SQL
	END

	IF @RequestType = 'getPDO_fromInputList'
	BEGIN

		-- Get panels from filter list
		INSERT INTO #PanelNames (PanelName, PanelXML)
			SELECT P.x.value('@name','VARCHAR(255)') PanelName, P.x.query('.') PanelXML
			FROM @FilterList.nodes('filter_list[1]/panel') as P(x)

		-- Get panel-level information
		INSERT INTO #Panels (panel_number, panel_date_from, panel_date_to, panel_accuracy_scale, invert, panel_timing, total_item_occurrences, items,
								estimated_count, has_date_constraint, has_value_constraint)
			SELECT	P.PanelID,
					P.x.value('panel_date_from[1]','DATETIME'),
					P.x.value('panel_date_to[1]','DATETIME'),
					P.x.value('panel_accuracy_scale[1]','INT'),
					P.x.value('invert[1]','TINYINT'),
					P.x.value('panel_timing[1]','VARCHAR(100)'),
					P.x.value('total_item_occurrences[1]','INT'),
					P.x.query('item'),
					0, 0, 0
			FROM (SELECT PanelID, PanelXML.query('panel[1]/*') x FROM #PanelNames) P

		-- Get item-level information
		INSERT INTO #Items (panel_number, item_key, modifier_key, value_constraint, value_operator, value_unit_of_measure, value_type, valid)
			SELECT	p.panel_number,
					I.x.value('item_key[1]','VARCHAR(900)'),
					I.x.value('constrain_by_modifier[1]/modifier_key[1]','VARCHAR(900)'),
					IsNull(I.x.value('constrain_by_value[1]/value_constraint[1]','VARCHAR(MAX)'),
						I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_constraint[1]','VARCHAR(MAX)')),
					IsNull(I.x.value('constrain_by_value[1]/value_operator[1]','VARCHAR(MAX)'),
						I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_operator[1]','VARCHAR(MAX)')),
					IsNull(I.x.value('constrain_by_value[1]/value_unit_of_measure[1]','VARCHAR(MAX)'),
						I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_unit_of_measure[1]','VARCHAR(MAX)')),
					IsNull(I.x.value('constrain_by_value[1]/value_type[1]','VARCHAR(MAX)'),
						I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_type[1]','VARCHAR(MAX)')),
					0
			FROM #Panels p CROSS APPLY p.items.nodes('//item') as I(x)
		UPDATE #Items
			SET item_type = (CASE WHEN item_key LIKE '\\%\%' THEN 'concept'
								WHEN item_key LIKE 'masterid:%' THEN 'masterid'
								WHEN item_key LIKE 'patient_set_coll_id:%' THEN 'patient_set_coll_id'
								ELSE NULL END)
		UPDATE #Items
			SET item_key_id = SUBSTRING(item_key,LEN(item_type)+2,LEN(item_key))
			WHERE (item_type IS NOT NULL) AND (item_type <> 'concept')
		UPDATE #Items
			SET	item_table = SUBSTRING(item_key,3,CHARINDEX('\',item_key,3)-3),
				item_path = SUBSTRING(item_key,CHARINDEX('\',item_key,3),700),
				modifier_path = SUBSTRING(modifier_key,CHARINDEX('\',modifier_key,3),700)
			WHERE item_type = 'concept'

		-- Get the ontology cell schema
		EXEC [HIVE].[uspGetCellSchema]	@Service = 'OntologyService',
										@DomainID = @DomainID,
										@UserID = @Username,
										@ProjectID = @ProjectID,
										@CellSchema = @OntSchema OUTPUT

		-- Get item details from ontology tables
		SELECT @i = 1, @MaxI = IsNull((SELECT MAX(item_id) FROM #Items),0)
		WHILE @i <= @MaxI
		BEGIN
			IF EXISTS (SELECT * FROM #Items WHERE item_id = @i AND item_type = 'concept')
			BEGIN
				SELECT @sql = 'UPDATE i
								SET i.ont_table = '''+REPLACE(@OntSchema,'''','''''')+'.''+t.c_table_name
								FROM #Items i, '+@OntSchema+'.TABLE_ACCESS t
								WHERE i.item_id = '+CAST(@i AS VARCHAR(50))+' 
									AND i.item_table = t.c_table_cd
								'
								+(CASE WHEN @HasProtectedAccess=1 THEN '' ELSE 'AND ISNULL(C_PROTECTED_ACCESS,''N'') <> ''Y''' END)
				EXEC sp_executesql @sql
				SELECT @sql = 'UPDATE i
									SET	i.valid = 1,
										i.c_facttablecolumn = o.c_facttablecolumn,
										i.c_tablename = o.c_tablename,
										i.c_columnname = o.c_columnname,
										i.c_columndatatype = o.c_columndatatype,
										i.c_operator = o.c_operator,
										i.c_dimcode = o.c_dimcode,
										i.c_totalnum = o.c_totalnum
									FROM #Items i, '+i.ont_table+' o
									WHERE i.item_id = '+CAST(@i AS VARCHAR(50))+' AND i.item_path = o.c_fullname'
					FROM #Items i
					WHERE i.item_id = @i
				EXEC sp_executesql @sql
			END
			SELECT @i = @i + 1
		END

		-- Escape and validate item fields
		UPDATE #Items
			SET c_dimcode = ''''+replace(c_dimcode,'''','''''')+'%'''
			WHERE c_operator = 'LIKE'
		UPDATE #Items
			SET c_dimcode = '('+c_dimcode+')'
			WHERE c_operator = 'IN'
		UPDATE #Items
			SET c_dimcode = ''''+replace(c_dimcode,'''','''''')+''''
			WHERE c_columndatatype = 'T' AND c_operator NOT IN ('LIKE','IN')
		UPDATE #Items
			SET value_constraint = ''''+replace(value_constraint,'''','''''')+''''
			WHERE value_type IN ('TEXT','FLAG') AND value_operator <> 'IN'
		UPDATE #Items
			SET valid = 0
			WHERE value_type = 'NUMBER' AND value_operator <> 'BETWEEN' AND IsNumeric(value_constraint) = 0
		UPDATE #Items
			SET valid = 0
			WHERE item_id IN (
					SELECT item_id
					FROM (
						SELECT CHARINDEX(' AND ',value_constraint) x, *
						FROM #Items
						WHERE value_type = 'NUMBER' AND value_operator = 'BETWEEN'
					) t
					WHERE IsNumeric(CASE WHEN x > 0 THEN LEFT(value_constraint,x-1) ELSE NULL END) = 0
						OR IsNumeric(CASE WHEN x > 0 THEN SUBSTRING(value_constraint,x+5,LEN(value_constraint)) ELSE NULL END) = 0
				)
		UPDATE #Items
			SET value_type = NULL
			WHERE IsNull(value_type,'') NOT IN ('','TEXT','NUMBER','FLAG')
		UPDATE #Items
			SET value_operator = (CASE	WHEN value_operator IN ('EQ','E') THEN '='
										WHEN value_operator IN ('LT','L') THEN '<'
										WHEN value_operator IN ('GT','G') THEN '>'
										WHEN value_operator IN ('NE','N') THEN '<>'
										WHEN value_operator IN ('LTEQ','LE') THEN '<='
										WHEN value_operator IN ('GTEQ','GE') THEN '>='
										WHEN value_operator IN ('BETWEEN','IN') THEN value_operator
										ELSE NULL
										END)

		-- Only concepts are handled by a PDO query
		DELETE
			FROM #Items
			WHERE ISNULL(item_type,'')<>'concept'

		-- Confirm user has permissions to access items
		IF EXISTS (SELECT * FROM #Items WHERE IsNull(valid,0) = 0)
		BEGIN
			SELECT 'ERROR' Error, * FROM #Items WHERE IsNull(valid,0) = 0
			--ToDo: Set error status
			RETURN
		END

		-- Only concepts from the concept dimension are handled by a PDO query
		DELETE
			FROM #Items
			WHERE c_tablename<>'CONCEPT_DIMENSION'

		-- Run the panels in order
		UPDATE #Panels SET process_order = panel_number

		-- Parse the selection filter
		IF @OutputObservationFilter LIKE 'last_%_values'
		BEGIN
			SELECT @OutputObservationFilter = 'last_n_values', @OutputObservationFilterN = N
			FROM (
				SELECT CAST(N AS INT) N
				FROM (SELECT SUBSTRING(@OutputObservationFilter,6,LEN(@OutputObservationFilter)-12) N) t
				WHERE ISNUMERIC(N)=1
			) t
		END

		-- Run each panel
		SELECT @p = 1, @MaxP = IsNull((SELECT MAX(process_order) FROM #Panels),0)
		WHILE @p <= @MaxP
		BEGIN
			-- Initialize panel SQL
			SELECT @sql = ''
			-- Handle item constraints
			SELECT @sql = @sql 
				+' OR ('
				+'	f.'+i.c_facttablecolumn+' IN ('
				+'	SELECT '+i.c_facttablecolumn
				+'		FROM '+@Schema+'.'+i.c_tablename+' t'
				+'		WHERE t.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode
				+'	)'
				+(CASE	WHEN IsNull(i.modifier_path,'') <> ''
							THEN ' AND f.modifier_cd IN (
										SELECT modifier_cd 
										FROM '+@Schema+'.modifier_dimension 
										WHERE modifier_path LIKE '''+REPLACE(i.modifier_path,'''','''''')+'%''
									)'
						ELSE '' END)
				+(CASE	WHEN (i.value_operator IS NULL) OR (i.value_constraint IS NULL)
							THEN ''
						WHEN i.value_type='TEXT'
							THEN ' AND f.tval_char '+i.value_operator+' '+i.value_constraint
						WHEN i.value_type='NUMBER'
							THEN ' AND f.nval_num '+i.value_operator+' '+i.value_constraint
						WHEN i.value_type='FLAG'
							THEN ' AND IsNull(f.valueflag_cd,''@'') '+i.value_operator+' '+i.value_constraint
						ELSE '' END)
				+(CASE	WHEN p.panel_date_from IS NOT NULL
							THEN ' AND f.start_date >= ''' + CAST(p.panel_date_from AS VARCHAR(50)) + ''''
						ELSE '' END)
				+(CASE	WHEN p.panel_date_to IS NOT NULL
							THEN ' AND f.start_date <= ''' + CAST(p.panel_date_to AS VARCHAR(50)) + ''''
						ELSE '' END)
				+')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number
			-- Join to the input lists
			SELECT @sql =
				'SELECT f.*'
				+' FROM '+@Schema+'.OBSERVATION_FACT f'
				+(CASE WHEN @InputPatientListSize > 0 THEN ' INNER JOIN #InputPatientList i ON f.patient_num = i.patient_num' ELSE '' END)
				+(CASE WHEN @InputPatientListSize = 0 AND @InputEncounterListSize > 0 THEN ' INNER JOIN #InputEncounterList i ON f.encounter_num = i.encounter_num' ELSE '' END)
				+' WHERE 1=0'
				+@sql
			-- Restrict to observations with modifiers
			IF @OutputObservationWithModifiers = 0
				SELECT @sql = 'SELECT * FROM ('+@sql+') t WHERE modifier_cd = ''@'''
			-- Handle the selection filter
			SELECT @sql = (
				CASE @OutputObservationFilter
					WHEN 'min_value' THEN 'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num, concept_cd ORDER BY (CASE WHEN modifier_cd=''@'' THEN 0 ELSE 1 END), nval_num) k FROM ('+@sql+') t) t WHERE k = 1'
					WHEN 'max_value' THEN 'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num, concept_cd ORDER BY (CASE WHEN modifier_cd=''@'' THEN 0 ELSE 1 END), nval_num DESC) k FROM ('+@sql+') t) t WHERE k = 1'
					WHEN 'first_value' THEN 'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num, concept_cd ORDER BY (CASE WHEN modifier_cd=''@'' THEN 0 ELSE 1 END), start_date) k FROM ('+@sql+') t) t WHERE k = 1'
					WHEN 'last_value' THEN 'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num, concept_cd ORDER BY (CASE WHEN modifier_cd=''@'' THEN 0 ELSE 1 END), start_date DESC) k FROM ('+@sql+') t) t WHERE k = 1'
					WHEN 'single_observation' THEN 'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num, concept_cd ORDER BY (CASE WHEN modifier_cd=''@'' THEN 0 ELSE 1 END), start_date) k FROM ('+@sql+') t) t WHERE k = 1'
					WHEN 'last_n_values' THEN 'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num, concept_cd ORDER BY (CASE WHEN modifier_cd=''@'' THEN 0 ELSE 1 END), start_date DESC) k FROM ('+@sql+') t) t WHERE k <= ' + CAST(@OutputObservationFilterN AS VARCHAR(50))
					ELSE @sql END
				)
			-- Save the results to the observation set temp table
			SELECT @sql =
				'INSERT INTO #ObservationSet (PanelID,encounter_num,patient_num,concept_cd,provider_id,start_date,modifier_cd,instance_num)'
				+' SELECT '+CAST(@p AS VARCHAR(50))+', encounter_num,patient_num,concept_cd,provider_id,start_date,modifier_cd,instance_num'
				+' FROM ('+@sql+') t'

			-- Run the panel sql
			--insert into dbo.x(x) select 'SQL = '+@sql
			UPDATE #Panels SET panel_sql = @sql WHERE process_order = @p
			EXEC sp_executesql @sql

			-- Move to the next panel
			SELECT @p = @p + 1
		END

	END

	ALTER TABLE #ObservationSet ADD PRIMARY KEY (PanelID, encounter_num, concept_cd, provider_id, start_date, modifier_cd, instance_num)


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Generate Output XML Sets
	-- ***************************************************************************
	-- ***************************************************************************

	-- Get all the output options
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns6,
		'http://www.i2b2.org/xsd/cell/crc/pdo/1.1/' as ns3
	), Options AS (
		SELECT 'patient' PDOSet, 'using_patient_list' selecttype, 0 onlykeysdefault, x.query('.') x
			FROM @RequestXML.nodes('ns6:request[1]/message_body[1]/ns3:request[1]/patient_output_option[1]') AS R(x)
			WHERE @RequestType = 'get_patient_by_primary_key'
		UNION ALL
		SELECT 'observation' PDOSet, 'using_filter_list' selecttype, 0 onlykeysdefault, x.query('.') x
			FROM @RequestXML.nodes('ns6:request[1]/message_body[1]/ns3:request[1]/fact_output_option[1]') AS R(x)
			WHERE @RequestType = 'get_observationfact_by_primary_key'
		UNION ALL
		SELECT	LEFT(PDOTag,CHARINDEX('_set',PDOTag)-1) PDOSet,
				ISNULL(x.value('@select','varchar(50)'),'using_filter_list') selecttype,
				1 onlykeysdefault, 
				x.query('.') x
			FROM @RequestXML.nodes('ns6:request[1]/message_body[1]/ns3:request[1]/output_option[1]/*') AS R(x)
				CROSS APPLY (SELECT R.x.value('local-name(.[1])','varchar(100)') PDOTag) AS S
			WHERE @RequestType = 'getPDO_fromInputList'
	)
	INSERT INTO #OutputSetSQL (PDOSet, selecttype, onlykeys, blob, techdata, withmodifiers)
		SELECT PDOSet, selecttype,
			ISNULL(HIVE.fnStr2Bit(x.value('*[1]/@onlykeys','varchar(10)')),onlykeysdefault) onlykeys,
			(@HasDeidAccess & HIVE.fnStr2Bit(x.value('*[1]/@blob','varchar(10)'))) blob,
			(@HasDeidAccess & HIVE.fnStr2Bit(x.value('*[1]/@techdata','varchar(10)'))) techdata,
			HIVE.fnStr2Bit(x.value('*[1]/@withmodifiers','varchar(10)')) withmodifiers
		FROM Options

	-- Create a list of all output columns and attributes
	;WITH PDOSets AS (
		SELECT '' PDOSet, '' DataTable WHERE 1=0
		UNION ALL SELECT 'concept', 'CONCEPT_DIMENSION'
		UNION ALL SELECT 'eid', 'ENCOUNTER_MAPPING'
		UNION ALL SELECT 'event', 'VISIT_DIMENSION'
		UNION ALL SELECT 'modifier', 'MODIFIER_DIMENSION'
		UNION ALL SELECT 'observation', 'OBSERVATION_FACT'
		UNION ALL SELECT 'observer', 'PROVIDER_DIMENSION'
		UNION ALL SELECT 'patient', 'PATIENT_DIMENSION'
		UNION ALL SELECT 'pid', 'PATIENT_MAPPING'
	), ColumnNames AS (
		SELECT '' PDOSet, '' DataColumn, '' ColumnName WHERE 1=0
		UNION ALL SELECT 'eid','ENCOUNTER_IDE','event_id'
		UNION ALL SELECT 'event','ENCOUNTER_NUM','event_id'
		UNION ALL SELECT 'event','PATIENT_NUM','patient_id'
		UNION ALL SELECT 'observation','ENCOUNTER_NUM','event_id'
		UNION ALL SELECT 'observation','PATIENT_NUM','patient_id'
		UNION ALL SELECT 'observation','PROVIDER_ID','observer_cd'
		UNION ALL SELECT 'observer','PROVIDER_ID','observer_cd'
		UNION ALL SELECT 'observer','PROVIDER_PATH','observer_path'
		UNION ALL SELECT 'patient','PATIENT_NUM','patient_id'
		UNION ALL SELECT 'pid','PATIENT_IDE','patient_id'
	), ColumnDescriptors AS (
		SELECT '' PDOSet, '' ColumnName, '' ColumnDescriptor WHERE 1=0
		UNION ALL SELECT 'event','active_status_cd','Date accuracy code'
		UNION ALL SELECT 'event','start_date','Start Date'
		UNION ALL SELECT 'event','end_date','End Date'
		UNION ALL SELECT 'event','inout_cd','Inpatient/Outpatient code'
		UNION ALL SELECT 'event','location_cd','Location'
		UNION ALL SELECT 'event','location_path','Location hierarchy'
		UNION ALL SELECT 'event','length_of_stay','Length of Stay'
		UNION ALL SELECT 'event','visit_blob','Visit Blob'
		UNION ALL SELECT 'patient','vital_status_cd','Date Accuracy Code'
		UNION ALL SELECT 'patient','birth_date','Birth Date'
		UNION ALL SELECT 'patient','death_date','Death Date'
		UNION ALL SELECT 'patient','sex_cd','Gender'
		UNION ALL SELECT 'patient','age_in_years_num','Age'
		UNION ALL SELECT 'patient','language_cd','Language'
		UNION ALL SELECT 'patient','race_cd','Race'
		UNION ALL SELECT 'patient','marital_status_cd','Marital Status'
		UNION ALL SELECT 'patient','religion_cd','Religion'
		UNION ALL SELECT 'patient','zip_cd','Zip Code'
		UNION ALL SELECT 'patient','statecityzip_path','Zip Code Hierarchy'
		UNION ALL SELECT 'patient','income_cd','Income'
		UNION ALL SELECT 'patient','patient_blob','Patient Blob'
	), ColumnList1 AS (
		SELECT p.PDOSet, ISNULL(CAST(n.ColumnName AS VARCHAR(50)),LOWER(c.column_name)) ColumnName, 
			p.DataTable, c.column_name DataColumn, c.ordinal_position, c.data_type
		FROM INFORMATION_SCHEMA.COLUMNS c
			INNER JOIN PDOSets p
				ON c.TABLE_NAME = p.DataTable AND c.TABLE_SCHEMA = @Schema 
			LEFT OUTER JOIN ColumnNames n
				ON p.PDOSet = n.PDOSet AND c.column_Name = n.DataColumn
		-- exclude columns
		WHERE
			NOT (	(p.PDOSet = 'eid' AND c.column_name IN ('ENCOUNTER_NUM','ENCOUNTER_IDE_SOURCE','ENCOUNTER_IDE_STATUS','PATIENT_IDE','PATIENT_IDE_SOURCE','PROJECT_ID'))
				OR	(p.PDOSet = 'pid' AND c.column_name IN ('PATIENT_NUM','PATIENT_IDE_SOURCE','PATIENT_IDE_STATUS','PROJECT_ID'))
			)
		-- add columns
		UNION ALL SELECT 'eid', 'event_map_id', NULL, 'event_map_id', 100, 'varchar'
		UNION ALL SELECT 'pid', 'patient_map_id', NULL, 'patient_map_id', 100, 'varchar'
	), ColumnList2 AS (
		SELECT PDOSet, ColumnName, DataTable, DataColumn, ordinal_position,
			(CASE	WHEN data_type IN ('date','datetime') THEN 'dateTime'
					WHEN data_type IN ('int','bigint','tinyint') THEN 'int'
					WHEN data_type IN ('decimal','numeric','float','real') THEN 'decimal'
					ELSE 'string' END) DataType,
			(CASE	WHEN PDOSet = 'eid' AND ColumnName IN ('event_map_id') THEN 1
					WHEN PDOSet = 'pid' AND ColumnName IN ('patient_map_id') THEN 1
					ELSE 0 END) UseExactXML,
			(CASE	WHEN ColumnName IN ('download_date','import_date','sourcesystem_cd','update_date','upload_date','upload_id') THEN 1
					ELSE 0 END) IsTechData,
			(CASE	WHEN ColumnName LIKE '%BLOB' THEN 1 ELSE 0 END) IsBlob,
			(CASE	WHEN PDOSet = 'concept' AND ColumnName IN ('concept_cd','concept_path') THEN 1
					WHEN PDOSet = 'eid' AND ColumnName IN ('encounter_ide') THEN 1
					WHEN PDOSet = 'event' AND ColumnName IN ('event_id','patient_id') THEN 1
					WHEN PDOSet = 'modifier' AND ColumnName IN ('modifier_cd','modifier_path') THEN 1
					WHEN PDOSet = 'observation' AND ColumnName IN ('event_id','patient_id','concept_cd','observer_cd','start_date','modifier_cd','instance_num') THEN 1
					WHEN PDOSet = 'observer' AND ColumnName IN ('provider_id','provider_path') THEN 1
					WHEN PDOSet = 'patient' AND ColumnName IN ('patient_id') THEN 1
					WHEN PDOSet = 'pid' AND ColumnName IN ('patient_ide') THEN 1
					ELSE 0 END) IsKey,
			(CASE	WHEN PDOSet = 'observation' AND ColumnName = 'concept_cd' THEN 'concept_name_char'
					WHEN PDOSet = 'observation' AND ColumnName = 'modifier_cd' THEN 'modifier_name_char'
					WHEN PDOSet = 'observation' AND ColumnName = 'observer_cd' THEN 'provider_name_char'
					ELSE NULL END) CodeNameColumn
		FROM ColumnList1
	)
	INSERT INTO #ColumnList (PDOSet, ColumnName, DataTable, DataColumn, DataType, 
					UseExactXML, IsTechData, IsBlob, IsKey, IsParam, CodeNameColumn,
					ColumnDescriptor, SortOrder)
		SELECT c.PDOSet, c.ColumnName, DataTable, DataColumn, DataType, 
			UseExactXML, IsTechData, IsBlob, IsKey, IsParam, CodeNameColumn,
			ISNULL(l.name_char,d.ColumnDescriptor) ColumnDescriptor,
			ROW_NUMBER() OVER (PARTITION BY c.PDOSet ORDER BY (CASE WHEN IsParam=1 THEN 1 WHEN IsTechData=1 THEN 2 ELSE 0 END), ordinal_position) SortOrder
		FROM ColumnList2 c
			LEFT OUTER JOIN ColumnDescriptors d ON c.PDOSet = d.PDOSet AND c.ColumnName = d.ColumnName
			LEFT OUTER JOIN ..CODE_LOOKUP l
				ON c.DataTable = l.table_cd AND c.DataColumn = l.column_cd AND l.code_cd = 'crc_column_descriptor'
			CROSS APPLY (
				SELECT (CASE	WHEN (c.PDOSet = 'patient') AND (IsTechData+IsKey = 0) THEN 1
								WHEN (c.PDOSet = 'event') AND (IsTechData+IsKey = 0) AND (c.ColumnName NOT IN ('patient_id','start_date','end_date')) THEN 1
								ELSE 0 END) IsParam
				) p

	-- Testing
	-- SELECT * FROM #ColumnList

	-- Generate the SQL for each output set [Part 1]
	UPDATE o
		SET o.ColumnListSQL =
			(CASE WHEN (o.PDOSet NOT IN ('eid','pid')) AND (o.TechData=1) THEN 
					'update_date "@update_date", '
					+'download_date "@download_date", '
					+'import_date "@import_date", '
					+'sourcesystem_cd "@sourcesystem_cd", '
					+'upload_id "@upload_id", '
				ELSE '' END)
			+(SELECT (CASE WHEN (m.IsKey=1 OR o.OnlyKeys=0)
							AND (m.IsBlob=0 OR o.Blob=1)
							AND (m.IsTechData=0 OR o.TechData=1)
						THEN
							(CASE 
								WHEN m.UseExactXML = 1 THEN ''
									+m.DataColumn+'.query(''*''), '
								WHEN m.IsParam = 1 THEN ''
									+''''+m.DataType+''' "param/@type", '
									+ISNULL(''''+m.ColumnDescriptor+''' "param/@column_descriptor", ','')
									+ISNULL(''''+m.ColumnName+''' "param/@column", ','')
									+m.DataColumn+' "param", '
								WHEN m.ColumnName IN ('event_id','patient_id') THEN ''
									+(CASE m.PDOSet
										WHEN 'event' THEN '''i2b2'' "'+m.ColumnName+'/@source", '
										WHEN 'observation' THEN '''HIVE'' "'+m.ColumnName+'/@source", '
										WHEN 'patient' THEN '''i2b2'' "'+m.ColumnName+'/@source", '
										WHEN 'eid' THEN
											'patient_ide_source "event_id/@patient_id_source", '
											+'patient_ide "event_id/@patient_id", '
											+'encounter_ide_source "event_id/@source", '
										WHEN 'pid' THEN
											(CASE WHEN o.TechData=1 THEN 
												'upload_date "patient_id/@upload_date", '
												+'update_date "patient_id/@update_date", '
												+'download_date "patient_id/@download_date", '
												+'import_date "patient_id/@import_date", '
												+'sourcesystem_cd "patient_id/@sourcesystem_cd", '
												+'upload_id "patient_id/@upload_id", '
											ELSE '' END)
											+'patient_ide_status "patient_id/@status", '
											+'patient_ide_source "patient_id/@source", '
										ELSE '' END)
									+m.DataColumn+' "'+m.ColumnName+'", '
								ELSE '' 
									+(CASE WHEN @OutputName<>'none' THEN ISNULL(m.CodeNameColumn+' "'+m.ColumnName+'/@name", ','') ELSE '' END)
									+m.DataColumn+' "'+m.ColumnName+'", '
								END)
							+''''','
						ELSE '' END)
				FROM #ColumnList m
				WHERE m.PDOSet = o.PDOSet AND m.IsTechData = 0
				ORDER BY m.SortOrder
				FOR XML PATH(''), TYPE
			).value('.','VARCHAR(MAX)')+'''''',
		DataTableSQL = 
			(CASE selecttype
				WHEN 'using_input_list'
					THEN (CASE PDOSet
						WHEN 'patient' THEN 'SELECT patient_num, sort_index FROM #InputPatientList'
						WHEN 'event' THEN 'SELECT encounter_num, sort_index FROM #InputEncounterList'
						WHEN 'pid' THEN 'SELECT patient_num, sort_index FROM #InputPatientList'
						WHEN 'eid' THEN 'SELECT encounter_num, sort_index FROM #InputEncounterList'
						ELSE NULL END)
				WHEN 'using_filter_list'
					THEN (CASE PDOSet
						WHEN 'patient' THEN 'SELECT DISTINCT patient_num, NULL sort_index FROM #ObservationSet'
						WHEN 'event' THEN 'SELECT DISTINCT encounter_num, NULL sort_index FROM #ObservationSet'
						WHEN 'observer' THEN 'SELECT DISTINCT provider_id, NULL sort_index FROM #ObservationSet'
						WHEN 'concept' THEN 'SELECT DISTINCT concept_cd, NULL sort_index FROM #ObservationSet'
						WHEN 'modifier' THEN 'SELECT DISTINCT modifier_cd, NULL sort_index FROM #ObservationSet'
						WHEN 'pid' THEN 'SELECT DISTINCT patient_num, NULL sort_index FROM #ObservationSet'
						WHEN 'eid' THEN 'SELECT DISTINCT encounter_num, NULL sort_index FROM #ObservationSet'
						WHEN 'observation' THEN 'SELECT * FROM #ObservationSet'
						ELSE NULL END)
				ELSE NULL END)
		FROM #OutputSetSQL o

	-- Generate the SQL for each output set [Part 2]
	UPDATE o
		SET o.SetSQL =
			'UPDATE x '
			+'SET x.SetStr = '
			+(CASE WHEN PDOSet = 'observation' THEN
				'REPLACE(CAST(
				(SELECT PanelName "@panel_name",
					(SELECT '+ColumnListSQL+'
						FROM
							(SELECT f.*,
									c.name_char concept_name_char,
									v.name_char provider_name_char,
									m.name_char modifier_name_char
								FROM #ObservationSet o
									INNER JOIN '+@Schema+'.OBSERVATION_FACT f
										ON o.encounter_num = f.encounter_num
											AND o.concept_cd = f.concept_cd
											AND o.provider_id = f.provider_id
											AND o.start_date = f.start_date
											AND o.modifier_cd = f.modifier_cd
											AND o.instance_num = f.instance_num
									LEFT OUTER JOIN '+@Schema+'.CONCEPT_DIMENSION c
										ON f.concept_cd = c.concept_cd
									LEFT OUTER JOIN '+@Schema+'.PROVIDER_DIMENSION v
										ON f.provider_id = v.provider_id
									LEFT OUTER JOIN '+@Schema+'.MODIFIER_DIMENSION m
										ON f.modifier_cd = m.modifier_cd
								WHERE o.PanelID = n.PanelID
							) t						
						FOR XML PATH(''observation''), TYPE
					)
					FROM #PanelNames n
					ORDER BY n.PanelID
					FOR XML PATH(''ns2observation_set''), TYPE
				) AS VARCHAR(MAX)),''ns2observation_set'',''ns2:observation_set'')
				'
			ELSE
				'''<ns2:'+PDOSet+'_set>''+CAST(('
				+'SELECT '
				+ColumnListSQL
				+' FROM ('
				+(CASE PDOSet
					WHEN 'patient' THEN 
						'SELECT p.*, l.sort_index
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.PATIENT_DIMENSION p ON l.patient_num = p.patient_num'
					WHEN 'event' THEN 
						'SELECT e.*, l.sort_index
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.VISIT_DIMENSION e ON l.encounter_num = e.encounter_num'
					WHEN 'observer' THEN 
						'SELECT p.*
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.PROVIDER_DIMENSION p ON l.provider_id = p.provider_id'
					WHEN 'concept' THEN 
						'SELECT c.*
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.CONCEPT_DIMENSION c ON l.concept_cd = c.concept_cd'
					WHEN 'modifier' THEN 
						'SELECT m.*
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.MODIFIER_DIMENSION m ON l.modifier_cd = m.modifier_cd'
					WHEN 'pid' THEN 
						'SELECT m.*, l.sort_index,
								(SELECT
									'+(CASE WHEN o.TechData = 1 THEN
												'q.upload_date "patient_map_id/@upload_date", '
												+'q.update_date "patient_map_id/@update_date", '
												+'q.download_date "patient_map_id/@download_date", '
												+'q.import_date "patient_map_id/@import_date", '
												+'q.sourcesystem_cd "patient_map_id/@sourcesystem_cd", '
												+'q.upload_id "patient_map_id/@upload_id", '
											ELSE '' END)+'
									q.patient_ide_status "patient_map_id/@status",
									q.patient_ide_source "patient_map_id/@source",
									q.patient_ide "patient_map_id"
									FROM '+@Schema+'.PATIENT_MAPPING q
									WHERE q.patient_num = m.patient_num
										AND q.project_id = m.project_id
										AND (q.patient_ide <> m.patient_ide
											OR q.patient_ide_source <> m.patient_ide_source)
									ORDER BY q.patient_ide, q.patient_ide_source
									FOR XML PATH(''''), TYPE
								) patient_map_id
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.PATIENT_MAPPING m ON l.patient_num = m.patient_num 
									AND m.project_id = '''+REPLACE(@ProjectID,'''','''''')+'''
									AND m.patient_ide_source = ''HIVE'''
					WHEN 'eid' THEN 
						'SELECT m.*, l.sort_index,
								(SELECT
									q.encounter_ide_status "event_map_id/@status",
									q.encounter_ide_source "event_map_id/@source",
									q.encounter_ide "event_map_id"
									FROM '+@Schema+'.ENCOUNTER_MAPPING q
									WHERE q.encounter_num = m.encounter_num
										AND q.project_id = m.project_id
										AND (q.encounter_ide <> m.encounter_ide
											OR q.encounter_ide_source <> m.encounter_ide_source)
									ORDER BY q.encounter_ide, q.encounter_ide_source
									FOR XML PATH(''''), TYPE
								) event_map_id
							FROM ('+DataTableSQL+') l 
								INNER JOIN '+@Schema+'.ENCOUNTER_MAPPING m ON l.encounter_num = m.encounter_num 
									AND m.project_id = '''+REPLACE(@ProjectID,'''','''''')+'''
									AND m.encounter_ide_source = ''HIVE'''
					ELSE NULL END)
				+') T'
				+' ORDER BY '
				+(CASE PDOSet
					WHEN 'patient' THEN 'sort_index, patient_num'
					WHEN 'event' THEN 'sort_index, encounter_num'
					WHEN 'observer' THEN 'provider_id, provider_path'
					WHEN 'concept' THEN 'concept_cd, concept_path'
					WHEN 'modifier' THEN 'modifier_cd, modifier_path'
					WHEN 'pid' THEN 'sort_index, patient_ide, patient_ide_source'
					WHEN 'eid' THEN 'sort_index, encounter_ide, encounter_ide_source'
					ELSE NULL END)
				+' FOR XML PATH('''+PDOSet+'''), TYPE'
				+') AS VARCHAR(MAX))+''</ns2:'+PDOSet+'_set>'''
			END)
			+' FROM #OutputSetSQL x' 
			+' WHERE PDOSet = '''+PDOSet+''''
		FROM #OutputSetSQL o

	-- Run the SQL for each output set
	SELECT @i = 1, @MaxI = (SELECT ISNULL(MAX(SetID),0) FROM #OutputSetSQL)
	WHILE (@i <= @MaxI)
	BEGIN
		SELECT @sql = SetSQL
			FROM #OutputSetSQL
			WHERE SetID = @i
		SELECT @i = @i + 1
		EXEC sp_executesql @sql	
	END

	-- Testing
	--SELECT * FROM #OutputSetSQL


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Perform Actions
	-- ***************************************************************************
	-- ***************************************************************************

	-- Form MessageBody
	SELECT	@StatusType = 'DONE',
			@StatusText = 'DONE',
			@MessageBody = 
				'<message_body>'
				+ '<ns3:response xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="ns3:patient_data_responseType">'
				+ '<ns2:patient_data>'
				+ ISNULL(REPLACE(REPLACE(CAST((SELECT REPLACE(REPLACE(SetStr,'<','_TAGLT_'),'>','_TAGGT_')+'' 
					FROM #OutputSetSQL 
					WHERE SetStr IS NOT NULL 
					ORDER BY SetID 
					FOR XML PATH(''), TYPE
				) AS VARCHAR(MAX)),'_TAGLT_','<'),'_TAGGT_','>'),'')
				+ '</ns2:patient_data>'
				+ '</ns3:response>'
				+ '</message_body>'

END
GO
GO
CREATE PROCEDURE [CRC].[uspRunPSM]
	@Operation VARCHAR(100),
	@RequestXML XML,
	@RequestType VARCHAR(100) OUTPUT,
	@StatusType NVARCHAR(100) OUTPUT,
	@StatusText NVARCHAR(MAX) OUTPUT,
	@MessageBody NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Declare Variables
	-- ***************************************************************************
	-- ***************************************************************************

	-- Declare request variables
	DECLARE @DomainID VARCHAR(50)
	DECLARE @Username VARCHAR(50)
	DECLARE @ProjectID VARCHAR(50)
	DECLARE @ResultWaittimeMS BIGINT
	DECLARE @UserID VARCHAR(100)
	DECLARE @GroupID VARCHAR(100)
	DECLARE @FetchSize INT
	DECLARE @QueryMasterID INT
	DECLARE @QueryInstanceID INT
	DECLARE @QueryResultInstanceID INT
	DECLARE @QueryName	VARCHAR(250)
	DECLARE @QueryDefinition XML
	DECLARE @ResultOutputList XML
	
	-- Declare response variables
	DECLARE @Response VARCHAR(MAX)
	DECLARE @ConditionType VARCHAR(100)
	DECLARE @ConditionText VARCHAR(1000)
	
	-- Declare processing variables
	DECLARE @ProcName VARCHAR(100)
	DECLARE @HaltTime DATETIME
	DECLARE @DelayMS FLOAT
	DECLARE @DelayTime VARCHAR(20)
	
/*
	DECLARE @ResultStatus INT
	DECLARE @MessageHeader XML
	DECLARE @ResultCount INT
	DECLARE @PatientSet BIT
	DECLARE @PatientCountXML BIT
	DECLARE @ThresholdTime	DATETIME
	DECLARE @EstTime INT
	DECLARE @QueryInstanceStatus INT
*/

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Parse Request Message
	-- ***************************************************************************
	-- ***************************************************************************


	-- Extract variables from the request message
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns6,
		'http://www.i2b2.org/xsd/cell/crc/psm/1.1/' as ns4
	)
	SELECT	-- message_header
			@DomainID = x.value('message_header[1]/security[1]/domain[1]','varchar(50)'),
			@Username = x.value('message_header[1]/security[1]/username[1]','VARCHAR(50)'),
			@ProjectID = x.value('message_header[1]/project_id[1]','VARCHAR(50)'),
			-- request_header
			@ResultWaittimeMS = x.value('request_header[1]/result_waittime_ms[1]','INT'),
			-- message_body - psmheader
			@RequestType = x.value('message_body[1]/ns4:psmheader[1]/request_type[1]','VARCHAR(100)'),
			-- message_body - request
			@UserID = x.value('message_body[1]/ns4:request[1]/user_id[1]','VARCHAR(100)'),
			@GroupID = x.value('message_body[1]/ns4:request[1]/group_id[1]','VARCHAR(100)'),
			@FetchSize = x.value('message_body[1]/ns4:request[1]/fetch_size[1]','INT'),
			--@QueryMasterID = x.value('message_body[1]/ns4:request[1]/query_master_id[1]','VARCHAR(100)'),
			@QueryMasterID = (CASE WHEN query_master_id='false' THEN NULL WHEN left(query_master_id,9)='masterid:' THEN substring(query_master_id,10,99) ELSE query_master_id END),
			@QueryInstanceID = x.value('message_body[1]/ns4:request[1]/query_instance_id[1]','VARCHAR(100)'),
			@QueryResultInstanceID = x.value('message_body[1]/ns4:request[1]/query_result_instance_id[1]','VARCHAR(100)'),
			@QueryName = x.value('message_body[1]/ns4:request[1]/query_name[1]','VARCHAR(250)'),
			@QueryDefinition = x.query('message_body[1]/ns4:request[1]/query_definition[1]'),
			@ResultOutputList = x.query('message_body[1]/ns4:request[1]/result_output_list[1]')
		FROM @RequestXML.nodes('ns6:request[1]') AS R(x)
			CROSS APPLY (SELECT x.value('message_body[1]/ns4:request[1]/query_master_id[1]','VARCHAR(100)') query_master_id) q

	-- Set default values
 	SELECT	@FetchSize = IsNull(@FetchSize,99999999),
  			@ResultWaittimeMS = IsNull(@ResultWaittimeMS,180000),
 			@HaltTime = DateAdd(ms,@ResultWaittimeMS,GetDate()),
 			@DelayMS = 100,
			@ConditionType = 'DONE',
 			@ConditionText = 'DONE',
 			@StatusType = 'DONE',
 			@StatusText = 'DONE'

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Security
	-- ***************************************************************************
	-- ***************************************************************************

	IF (IsNull(@Username,'') = '') OR (@Username <> @UserID)
	BEGIN
		RETURN;
	END

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Perform Actions
	-- ***************************************************************************
	-- ***************************************************************************

	IF @RequestType = 'CRC_QRY_renameQueryMaster'
	BEGIN
		UPDATE ..QT_QUERY_MASTER
			SET NAME = @QueryName
			WHERE QUERY_MASTER_ID = @QueryMasterID
	END
	
	IF @RequestType = 'CRC_QRY_deleteQueryMaster'
	BEGIN
		UPDATE ..QT_QUERY_MASTER
			SET DELETE_FLAG = 'D', DELETE_DATE = GetDate() 
			WHERE QUERY_MASTER_ID = @QueryMasterID
	END
	
	IF @RequestType = 'CRC_QRY_runQueryInstance_fromQueryDefinition'
	BEGIN
		-- Create the Query Master
		SELECT @QueryName = @QueryDefinition.value('query_definition[1]/query_name[1]','VARCHAR(250)')
		INSERT INTO ..QT_QUERY_MASTER (NAME, USER_ID, GROUP_ID, CREATE_DATE, DELETE_FLAG, REQUEST_XML, I2B2_REQUEST_XML)
			SELECT @QueryName, @Username, @ProjectID, GetDate(), 'A', CAST(@QueryDefinition AS VARCHAR(MAX)), CAST(@RequestXML AS VARCHAR(MAX))
		SELECT @QueryMasterID = @@IDENTITY
		-- Create the Query Instance
		INSERT INTO ..QT_QUERY_INSTANCE (QUERY_MASTER_ID, USER_ID, GROUP_ID, START_DATE, DELETE_FLAG, STATUS_TYPE_ID)
			SELECT @QueryMasterID, @Username, @ProjectID, GetDate(), 'A', 1
		SELECT @QueryInstanceID = @@IDENTITY
		-- Run the Query Instance
		IF 1=1
		BEGIN
			-- Run sychronously
			SELECT @ProcName = OBJECT_SCHEMA_NAME(@@PROCID)+'.uspRunQueryInstance'
			EXEC @ProcName @QueryInstanceID = @QueryInstanceID, @DomainID = @DomainID, @UserID = @Username, @ProjectID = @ProjectID
		END
		ELSE
		BEGIN
			-- Run asychronously
			-- Add Query Instance to Service Broker
			-- Loop until done or timeout
			WHILE EXISTS (
				SELECT * 
				FROM ..QT_QUERY_INSTANCE 
				WHERE GetDate() < @HaltTime AND @DelayMS < 24*60*60*1000 -- (Delay less than 24 hours)
					AND QUERY_INSTANCE_ID = @QueryInstanceID AND STATUS_TYPE_ID IN (1,5) -- (QUEUED, INCOMPLETE)
			)
			BEGIN
				SELECT	@DelayTime = CONVERT(VARCHAR,DateAdd(ms,@DelayMS,GetDate()),114),
						@DelayMS = @DelayMS * 0.25
				WAITFOR TIME @DelayTime ;
			END
		END
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Return Results
	-- ***************************************************************************
	-- ***************************************************************************

	DECLARE @ResponseItems TABLE (
		RequestType VARCHAR(100),
		QueryMaster BIT,
		QueryInstance BIT,
		QueryResultInstance BIT,
		ResultType BIT,
		ResultDocument BIT,
		QmName BIT,
		QmUserID BIT,
		QmGroupID BIT,
		QmCreateDate BIT,
		QmRequestXML BIT,
		QmEncodedRequestXML BIT,
		ns4Type VARCHAR(1000)
	)
	INSERT INTO @ResponseItems (RequestType,
								QueryMaster, QueryInstance, QueryResultInstance, ResultType, ResultDocument,
								QmName, QmUserID, QmGroupID, QmCreateDate, QmRequestXML, QmEncodedRequestXML,
								ns4Type)
		SELECT				'CRC_QRY_getResultType',									0,0,0,1,0,	0,0,0,0,0,0,	'result_type_responseType'
		UNION ALL SELECT	'CRC_QRY_getRequestXml_fromQueryMasterId',					1,0,0,0,0,	1,1,0,0,1,0,	'master_responseType'
		UNION ALL SELECT	'CRC_QRY_getQueryMasterList_fromUserId',					1,0,0,0,0,	1,1,1,1,0,0,	'master_responseType'
		UNION ALL SELECT	'CRC_QRY_getQueryMasterList_fromGroupId',					1,0,0,0,0,	1,1,1,1,0,0,	'master_responseType'
		UNION ALL SELECT	'CRC_QRY_renameQueryMaster',								1,0,0,0,0,	1,1,0,0,0,0,	'master_responseType'
		UNION ALL SELECT	'CRC_QRY_deleteQueryMaster',								1,0,0,0,0,	0,0,0,0,0,0,	'master_responseType'
		UNION ALL SELECT	'CRC_QRY_runQueryInstance_fromQueryDefinition',				1,1,1,0,0,	1,1,1,1,0,1,	'master_instance_result_responseType'
		UNION ALL SELECT	'CRC_QRY_runQueryInstance_fromQueryMasterId',				1,1,1,0,0,	1,1,1,1,0,1,	'master_instance_result_responseType'
		UNION ALL SELECT	'CRC_QRY_getQueryInstanceList_fromQueryMasterId',			0,1,0,0,0,	0,0,0,0,0,0,	'instance_responseType'
		UNION ALL SELECT	'CRC_QRY_getQueryResultInstanceList_fromQueryInstanceId',	0,0,1,0,0,	0,0,0,0,0,0,	'result_responseType'
		UNION ALL SELECT	'CRC_QRY_getResultDocument_fromResultInstanceId',			0,0,1,0,1,	0,0,0,0,0,0,	'crc_xml_result_responseType'

	DECLARE @HasManagerRole BIT
	SELECT @HasManagerRole = HIVE.fnHasUserRole(@ProjectID,@UserID,'MANAGER')

	SELECT @Response = CAST((
		SELECT	@ConditionType 'status/condition/@type',
 				@ConditionText 'status/condition',
				( -- Query Master
					SELECT TOP (@FetchSize)
						m.QUERY_MASTER_ID 'query_master_id',
						CASE WHEN i.QmName = 1 THEN REPLACE(REPLACE(REPLACE(m.NAME,'&','&amp;'),'<','&lt;'),'>','&gt;') END 'name',
						CASE WHEN i.QmUserID = 1 THEN m.USER_ID END 'user_id',
						CASE WHEN i.QmGroupID = 1 THEN m.GROUP_ID END 'group_id',
						m.MASTER_TYPE_CD 'master_type_cd',
						m.PLUGIN_ID 'plugin_id',
						CASE WHEN i.QmCreateDate = 1 THEN HIVE.fnDate2Str(m.CREATE_DATE) END 'create_date',
						CASE WHEN i.QmRequestXML = 1 THEN CAST(REQUEST_XML AS NVARCHAR(MAX)) ELSE NULL END 'request_xml',
						CASE WHEN i.QmEncodedRequestXML = 1 THEN REPLACE(REPLACE(REPLACE(CAST(REQUEST_XML AS NVARCHAR(MAX)),'&','&amp;'),'<','&lt;'),'>','&gt;') ELSE NULL END 'request_xml'
					FROM ..QT_QUERY_MASTER m, @ResponseItems i	
					WHERE i.RequestType = @RequestType AND i.QueryMaster = 1
						AND ISNULL(m.DELETE_FLAG,'A') <> 'D'
						AND m.QUERY_MASTER_ID = ISNULL(@QueryMasterID,m.QUERY_MASTER_ID)
						AND m.USER_ID = (CASE WHEN @HasManagerRole = 1 THEN m.USER_ID ELSE ISNULL(@UserID,m.USER_ID) END)
						AND m.GROUP_ID = ISNULL(@GroupID,m.GROUP_ID)
					ORDER BY m.QUERY_MASTER_ID DESC
					FOR XML PATH('query_master'), TYPE
				),
				( -- Query Instance
					SELECT
						i.QUERY_INSTANCE_ID 'query_instance_id',
						i.QUERY_MASTER_ID 'query_master_id',
						i.USER_ID 'user_id',
						i.GROUP_ID 'group_id',
						HIVE.fnDate2Str(START_DATE) 'start_date',
						HIVE.fnDate2Str(END_DATE) 'end_date',
						s.STATUS_TYPE_ID 'query_status_type/status_type_id',
						s.NAME 'query_status_type/name',
						s.DESCRIPTION 'query_status_type/description' 
					FROM ..QT_QUERY_INSTANCE i WITH(NOLOCK)
						JOIN ..QT_QUERY_STATUS_TYPE s WITH(NOLOCK) ON s.STATUS_TYPE_ID = i.STATUS_TYPE_ID
					WHERE EXISTS (SELECT * FROM @ResponseItems WHERE RequestType = @RequestType AND QueryInstance = 1)
						AND i.QUERY_INSTANCE_ID = ISNULL(@QueryInstanceID,i.QUERY_INSTANCE_ID)
						AND i.QUERY_MASTER_ID = ISNULL(@QueryMasterID,i.QUERY_MASTER_ID)
					ORDER BY i.QUERY_INSTANCE_ID
					FOR XML PATH('query_instance'), TYPE
				),
				( -- Query Result Instance	 							 
					SELECT
						r.RESULT_INSTANCE_ID 'result_instance_id',
						r.QUERY_INSTANCE_ID 'query_instance_id',
						REPLACE(REPLACE(REPLACE(CAST(r.DESCRIPTION AS NVARCHAR(MAX)),'&','&amp;'),'<','&lt;'),'>','&gt;') 'description',
						--r.DESCRIPTION 'description',
						t.RESULT_TYPE_ID 'query_result_type/result_type_id', 
						t.NAME 'query_result_type/name',
						t.DISPLAY_TYPE_ID 'query_result_type/display_type',
						t.VISUAL_ATTRIBUTE_TYPE_ID 'query_result_type/visual_attribute_type',
						t.DESCRIPTION 'query_result_type/description',
						r.SET_SIZE 'set_size',
						HIVE.fnDate2Str(r.START_DATE) 'start_date',
						HIVE.fnDate2Str(r.END_DATE) 'end_date',
						s.STATUS_TYPE_ID 'query_status_type/status_type_id',	
						s.NAME 'query_status_type/name',
						s.DESCRIPTION  'query_status_type/description'
					FROM ..QT_QUERY_RESULT_INSTANCE r WITH(NOLOCK)
						JOIN ..QT_QUERY_STATUS_TYPE s WITH(NOLOCK) ON s.STATUS_TYPE_ID = r.STATUS_TYPE_ID
						JOIN ..QT_QUERY_RESULT_TYPE t WITH(NOLOCK) ON t.RESULT_TYPE_ID = r.RESULT_TYPE_ID
					WHERE EXISTS (SELECT * FROM @ResponseItems WHERE RequestType = @RequestType AND QueryResultInstance = 1)
						AND r.QUERY_INSTANCE_ID = ISNULL(@QueryInstanceID,r.QUERY_INSTANCE_ID)
						AND r.RESULT_INSTANCE_ID = ISNULL(@QueryResultInstanceID,r.RESULT_INSTANCE_ID)
					ORDER BY r.RESULT_INSTANCE_ID
					FOR XML PATH('query_result_instance'), TYPE	 
				),
				( -- Result Type
					SELECT
						t.RESULT_TYPE_ID 'result_type_id',
						t.NAME 'name',
						t.DISPLAY_TYPE_ID 'display_type',
						t.VISUAL_ATTRIBUTE_TYPE_ID 'visual_attribute_type',
						t.DESCRIPTION 'description'
					FROM ..QT_QUERY_RESULT_TYPE t, @ResponseItems i
					WHERE i.RequestType = @RequestType AND i.ResultType = 1
						--AND t.RESULT_TYPE_ID = 4 -- Patient_Count_XML only
					ORDER BY t.RESULT_TYPE_ID
					FOR XML PATH('query_result_type'), TYPE	 
				),
				( -- Result Document
					SELECT
						r.XML_RESULT_ID 'xml_result_id',
						r.RESULT_INSTANCE_ID 'result_instance_id',
						REPLACE(REPLACE(REPLACE(CAST(r.XML_VALUE AS NVARCHAR(MAX)),'&','&amp;'),'<','&lt;'),'>','&gt;') 'xml_value'
					FROM ..QT_XML_RESULT r, @ResponseItems i
					WHERE r.RESULT_INSTANCE_ID = @QueryResultInstanceID AND i.ResultDocument = 1
					ORDER BY r.XML_RESULT_ID
					FOR XML PATH('crc_xml_result'), TYPE
				)  
 			FROM (SELECT '' A) A
 			FOR XML PATH(''), TYPE
 		) AS NVARCHAR(MAX) )

	SELECT	@MessageBody = 
				'<message_body>'
				+ '<ns4:response xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="ns4:'
				+ IsNull((SELECT TOP 1 ns4Type FROM @ResponseItems WHERE RequestType = @RequestType),'master_responseType')
				+ '">'
				+ @Response
				+ '</ns4:response>'
				+ '</message_body>'


/*
	CRC_QRY_getResultType

	CRC_QRY_getQueryMasterList_fromGroupId
	CRC_QRY_getQueryMasterList_fromUserId
	CRC_QRY_getQueryInstanceList_fromQueryMasterId
	CRC_QRY_getQueryResultInstanceList_fromQueryInstanceId
	CRC_QRY_getResultDocument_fromResultInstanceId

	CRC_QRY_runQueryInstance_fromQueryDefinition

	CRC_QRY_getRequestXml_fromQueryMasterId

	CRC_QRY_renameQueryMaster
	CRC_QRY_deleteQueryMaster
	
*/



END
GO
GO
CREATE PROCEDURE [CRC].[uspRunQueryInstance]
	@QueryInstanceID INT,
	@DomainID VARCHAR(50),
	@UserID VARCHAR(50),
	@ProjectID VARCHAR(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Set the status to indicate the query has started
	-- ***************************************************************************
	-- ***************************************************************************

	-- Set the Query Instance status to Incomplete
	UPDATE ..QT_QUERY_INSTANCE
		SET STATUS_TYPE_ID = 5, -- Incomplete
			START_DATE = GetDate()
		WHERE QUERY_INSTANCE_ID = @QueryInstanceID
		
		
	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Declare variables
	-- ***************************************************************************
	-- ***************************************************************************

	--------------------------------------------------------------------
	-- These variables are used only by this procedure
	--------------------------------------------------------------------

	DECLARE @uspRunQueryInstanceQM VARCHAR(100)
	DECLARE @uspRunQueryInstanceSubquery VARCHAR(100)
	DECLARE @uspRunQueryInstanceBreakdown VARCHAR(100)

	DECLARE @QueryMasterID INT
	DECLARE @QueryDefinition XML
	DECLARE @I2B2_Request_XML XML

	DECLARE @i INT
	DECLARE @MaxI INT

	DECLARE	@ReturnPatientCount BIT
	DECLARE @ReturnPatientList BIT
	DECLARE @ReturnEncounterCount BIT
	DECLARE @ReturnEncounterList BIT

	DECLARE @QueryMethod VARCHAR(100)
	DECLARE @SketchError FLOAT

	DECLARE @set_size INT
	DECLARE @real_set_size INT
	DECLARE @obfusc_method VARCHAR(500)

	DECLARE @result_type_id INT
	DECLARE @result_instance_id INT
	DECLARE @result_name VARCHAR(100)

	DECLARE @ResultOutputList TABLE (
		name VARCHAR(100),
		priority INT,
		result_type_id INT,
		description varchar(200),
		process_order INT
	)

	/*
	CREATE TABLE #ResultCounts (
		result_type_id INT,
		c_name VARCHAR(2000),
		c_facttablecolumn VARCHAR(50),
		c_tablename VARCHAR(50),
		c_columnname VARCHAR(50),
		c_columndatatype VARCHAR(50),
		c_operator VARCHAR(10),
		c_dimcode VARCHAR(700),
		process_order INT,
		result_count INT,
		actual_count INT
	)
	*/

	--------------------------------------------------------------------
	-- These temp tables are populated by ..uspRunQueryInstanceQM
	--------------------------------------------------------------------

	CREATE TABLE #GlobalQueryCounts (
		query_master_id int primary key,
		num_patients int,
		num_encounters bigint,
		num_instances bigint,
		num_facts bigint,
		sketch_e int,
		sketch_n int,
		sketch_q int,
		sketch_m int
	)

	CREATE TABLE #GlobalPatientList (
		query_master_id INT NOT NULL,
		patient_num INT NOT NULL,
	)
	ALTER TABLE #GlobalPatientList ADD PRIMARY KEY (query_master_id, patient_num)
	
	CREATE TABLE #GlobalEncounterList (
		query_master_id INT NOT NULL,
		encounter_num BIGINT NOT NULL,
		patient_num INT NOT NULL
	)
	ALTER TABLE #GlobalEncounterList ADD PRIMARY KEY (query_master_id, encounter_num)

	CREATE TABLE #GlobalInstanceList (
		query_master_id INT NOT NULL,
		encounter_num BIGINT NOT NULL,
		patient_num INT NOT NULL,
		concept_cd VARCHAR(50) NOT NULL,
		provider_id VARCHAR(50) NOT NULL,
		start_date DATETIME NOT NULL,
		instance_num INT NOT NULL
	)
	ALTER TABLE #GlobalInstanceList ADD PRIMARY KEY (query_master_id, encounter_num, patient_num, concept_cd, provider_id, start_date, instance_num)

	CREATE TABLE #GlobalSubqueryList (
		subquery_id INT IDENTITY(-1,-1) PRIMARY KEY,
		query_type VARCHAR(50),
		query_id VARCHAR(255),
		query_definition XML,
		num_patients INT
	)

	CREATE TABLE #GlobalSubqueryConstraintList (
		constraint_id INT IDENTITY(1,1) PRIMARY KEY,
		subquery_id1 INT,
		join_column1 VARCHAR(50),
		aggregate_operator1 VARCHAR(50),
		operator VARCHAR(50),
		subquery_id2 INT,
		join_column2 VARCHAR(50),
		aggregate_operator2 VARCHAR(50),
		span_operator1 VARCHAR(50),
		span_value1 INT,
		span_units1 VARCHAR(50),
		span_operator2 VARCHAR(50),
		span_value2 INT,
		span_units2 VARCHAR(50),
		constraint_sql NVARCHAR(MAX),
		num_patients INT
	)

	CREATE TABLE #GlobalTemporalList (
		subquery_id INT NOT NULL,
		patient_num INT NOT NULL,
		is_start BIT NOT NULL,
		the_date DATETIME NOT NULL
	)
	ALTER TABLE #GlobalTemporalList ADD PRIMARY KEY (subquery_id, patient_num, is_start, the_date)

	CREATE TABLE #GlobalBreakdownCounts (
		breakdown_id INT IDENTITY(1,1) PRIMARY KEY,
		column_name VARCHAR(100),
		real_size INT,
		set_size INT
	)

	CREATE TABLE #GlobalResultPatientList (
		patient_num INT PRIMARY KEY
	)

	-- Get schema based procedure names
	SELECT @uspRunQueryInstanceQM = OBJECT_SCHEMA_NAME(@@PROCID)+'.uspRunQueryInstanceQM'
	SELECT @uspRunQueryInstanceSubquery = OBJECT_SCHEMA_NAME(@@PROCID)+'.uspRunQueryInstanceSubquery'
	SELECT @uspRunQueryInstanceBreakdown = OBJECT_SCHEMA_NAME(@@PROCID)+'.uspRunQueryInstanceBreakdown'


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Run the query
	-- ***************************************************************************
	-- ***************************************************************************

	-- Check for security
	IF HIVE.fnHasUserRole(@ProjectID,@UserID,'DATA_OBFSC') = 0
	BEGIN
		-- TODO: Add error handling
		RETURN
	END

	-- Get Query Master data
	SELECT	@QueryMasterID = m.QUERY_MASTER_ID,
			@QueryDefinition = m.REQUEST_XML,
			@I2B2_Request_XML = m.I2B2_REQUEST_XML
		FROM ..QT_QUERY_MASTER m, ..QT_QUERY_INSTANCE i
		WHERE m.QUERY_MASTER_ID = i.QUERY_MASTER_ID 
			AND i.QUERY_INSTANCE_ID = @QueryInstanceID

	-- Determine the query method
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns6,
		'http://www.i2b2.org/xsd/cell/crc/psm/1.1/' as ns4
	)
	SELECT @QueryMethod = @I2B2_Request_XML.value('ns6:request[1]/message_body[1]/ns4:psmheader[1]/query_method[1]','varchar(100)')

	-- Get any subquery constraints
	EXEC @uspRunQueryInstanceSubquery
		@QueryMasterID = @QueryMasterID,
		@DomainID = @DomainID,
		@UserID = @UserID,
		@ProjectID = @ProjectID,
		@GetConstraints = 1,
		@QueryDefinition = @QueryDefinition

	-- Change master_type_cd if needed
	IF EXISTS (SELECT * FROM #GlobalSubqueryConstraintList)
		UPDATE ..QT_QUERY_MASTER
			SET MASTER_TYPE_CD = 'TEMPORAL'
			WHERE QUERY_MASTER_ID = @QueryMasterID

	/*
	SELECT * FROM #GlobalSubqueryList
	SELECT * FROM #GlobalSubqueryConstraintList
	SELECT * FROM #GlobalTemporalList
	SELECT * FROM #GlobalQueryCounts
	*/

	-- Get the Result Output List
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns6,
		'http://www.i2b2.org/xsd/cell/crc/psm/1.1/' as ns4
	), RequestList as (
		SELECT x.value('@name','varchar(100)') name, x.value('@priority_index','int') priority
			FROM @I2B2_Request_XML.nodes('//ns6:request[1]/message_body[1]/ns4:request[1]/result_output_list[1]/result_output') AS R(x)
	), TypeList as (
		SELECT name, MIN(result_type_id) result_type_id
			FROM ..QT_QUERY_RESULT_TYPE
			GROUP BY name
	)
	INSERT INTO @ResultOutputList (name, priority, result_type_id, description, process_order)
		SELECT s.name, r.priority, s.result_type_id, s.description,
				ROW_NUMBER() OVER (ORDER BY r.priority, s.name)
			FROM RequestList r, TypeList t, ..QT_QUERY_RESULT_TYPE s
			WHERE r.name = t.name AND t.result_type_id = s.result_type_id

	IF NOT EXISTS (SELECT * FROM @ResultOutputList)
		INSERT INTO @ResultOutputList (name, priority, result_type_id, description, process_order)
			SELECT name, 15, result_type_id, description, 1
				FROM ..QT_QUERY_RESULT_TYPE
				WHERE name = 'PATIENT_COUNT_XML' -- result_type_id = 4

	-- Determine what type of data are needed
	SELECT 
		@ReturnPatientCount = 0,
		@ReturnPatientList = 0,
		@ReturnEncounterCount = 0,
		@ReturnEncounterList = 0
	IF EXISTS (SELECT * FROM @ResultOutputList WHERE name IN ('PATIENT_COUNT_XML')) --result_type_id in (4)
		SELECT @ReturnPatientCount = 1
	IF EXISTS (SELECT * FROM @ResultOutputList WHERE name NOT IN ('PATIENT_ENCOUNTER_SET','XML','PATIENT_COUNT_XML')) --result_type_id = 1 OR result_type_id > 4
		SELECT @ReturnPatientList = 1
	IF EXISTS (SELECT * FROM @ResultOutputList WHERE name IN ('PATIENT_ENCOUNTER_SET')) --result_type_id in (2)
		SELECT @ReturnEncounterCount = 1, @ReturnEncounterList = 1
	IF EXISTS (SELECT * FROM #GlobalSubqueryConstraintList)
		SELECT @ReturnPatientList = 1, @ReturnEncounterList = (CASE WHEN @ReturnEncounterCount = 1 OR @ReturnEncounterList = 1 THEN 1 ELSE 0 END)

	-- Run the query master
	EXEC @uspRunQueryInstanceQM
		@QueryMasterID = @QueryMasterID,
		@DomainID = @DomainID,
		@UserID = @UserID,
		@ProjectID = @ProjectID,
		@ReturnPatientCount = @ReturnPatientCount,
		@ReturnPatientList = @ReturnPatientList,
		@ReturnEncounterCount = @ReturnEncounterCount,
		@ReturnEncounterList = @ReturnEncounterList,
		@QueryMethod = @QueryMethod

	-- Apply any subquery constraints
	IF EXISTS (SELECT * FROM #GlobalSubqueryConstraintList WHERE 1=1)
		EXEC @uspRunQueryInstanceSubquery
			@QueryMasterID = @QueryMasterID,
			@DomainID = @DomainID,
			@UserID = @UserID,
			@ProjectID = @ProjectID
		
	/*
	SELECT * FROM #GlobalSubqueryList
	SELECT * FROM #GlobalSubqueryConstraintList
	SELECT * FROM #GlobalTemporalList
	SELECT * FROM #GlobalQueryCounts
	*/

	-- Get the real number of patients
	SELECT @real_set_size = num_patients
		FROM #GlobalQueryCounts
		WHERE query_master_id = @QueryMasterID

	-- Switch to EXACT query method if no sketch information was returned
	SELECT @QueryMethod = 'EXACT'
		FROM #GlobalQueryCounts
		WHERE query_master_id = @QueryMasterID AND sketch_n IS NULL
	--insert into x(d,s) select GetDate(), @QueryMethod

	-- Determine the obfuscation method
	SELECT @obfusc_method = 'OBSUBTOTAL'
	-- Not DATA_OBFSC
	IF HIVE.fnHasUserRole(@ProjectID,@UserID,'DATA_AGG') = 1
		SELECT @obfusc_method = NULL
		
	-- Determine the number of patients that will be reported (obfuscating if needed)	
	IF @obfusc_method IS NULL
		SELECT @set_size = @real_set_size
	ELSE
		SELECT @set_size = (CASE WHEN @real_set_size < 3 THEN 0 ELSE @real_set_size + FLOOR(RAND()*7) - 3 END)

	IF EXISTS (SELECT * FROM @ResultOutputList WHERE [name] IN (SELECT [NAME] FROM ..QT_BREAKDOWN_PATH))
	BEGIN
		INSERT INTO #GlobalResultPatientList WITH (TABLOCK)
			SELECT patient_num
			FROM #GlobalPatientList 
			WHERE query_master_id = @QueryMasterID
	END
	
	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Generate result sets
	-- ***************************************************************************
	-- ***************************************************************************

	-- Loop through result output list
	SELECT @i = 1, @MaxI = IsNull((SELECT MAX(process_order) FROM @ResultOutputList),0)
	WHILE @i <= @MaxI
	BEGIN
		-- Get the result_type_id
		SELECT @result_type_id = result_type_id, @result_name = name
			FROM @ResultOutputList
			WHERE process_order = @i
		-- Create the result instance, set status to processing
		INSERT INTO ..QT_QUERY_RESULT_INSTANCE (QUERY_INSTANCE_ID, RESULT_TYPE_ID, START_DATE, STATUS_TYPE_ID, DELETE_FLAG, DESCRIPTION)
			SELECT	i.QUERY_INSTANCE_ID,
					t.RESULT_TYPE_ID,
					GetDate(),
					2, -- Processing
					'A',
					t.DESCRIPTION + ' for "' + m.NAME + '"'
				FROM ..QT_QUERY_INSTANCE i, ..QT_QUERY_MASTER m, ..QT_QUERY_RESULT_TYPE t
				WHERE i.QUERY_INSTANCE_ID = @QueryInstanceID
					AND i.QUERY_MASTER_ID = m.QUERY_MASTER_ID
					AND t.RESULT_TYPE_ID = @result_type_id
		-- Get the new result_instance_id
		SELECT @result_instance_id = @@IDENTITY
		-- Process the Result Instance	
		IF @result_name in ('PATIENTSET')
		BEGIN
			INSERT INTO ..QT_PATIENT_SET_COLLECTION (RESULT_INSTANCE_ID, PATIENT_NUM)
				SELECT @result_instance_id, patient_num
					FROM #GlobalPatientList 
					WHERE query_master_id = @QueryMasterID
			--INSERT INTO AnotherDatabase.CRC.QT_PATIENT_SET_COLLECTION (RESULT_INSTANCE_ID, PATIENT_NUM)
			--	SELECT TOP 32768 @result_instance_id, patient_num
			--		FROM #GlobalPatientList 
			--		WHERE query_master_id = @QueryMasterID
		END
		IF @result_name in ('PATIENT_ENCOUNTER_SET')
		BEGIN
			INSERT INTO ..QT_PATIENT_ENC_COLLECTION (RESULT_INSTANCE_ID, PATIENT_NUM, ENCOUNTER_NUM)
				SELECT @result_instance_id, patient_num, encounter_num
					FROM #GlobalEncounterList 
					WHERE query_master_id = @QueryMasterID
			--INSERT INTO AnotherDatabase.CRC.QT_PATIENT_ENC_COLLECTION (RESULT_INSTANCE_ID, PATIENT_NUM, ENCOUNTER_NUM)
			--	SELECT TOP 32768 @result_instance_id, patient_num, encounter_num
			--		FROM #GlobalEncounterList 
			--		WHERE query_master_id = @QueryMasterID
		END
		IF (@result_name in ('PATIENT_COUNT_XML')) OR (EXISTS (SELECT * FROM ..QT_BREAKDOWN_PATH WHERE NAME = @result_name)) --BREAKDOWNS
		BEGIN
			TRUNCATE TABLE #GlobalBreakdownCounts
			SELECT @SketchError = 0
			IF @result_name in ('PATIENT_COUNT_XML')
			BEGIN
				INSERT INTO #GlobalBreakdownCounts(column_name,real_size,set_size)
					SELECT 'patient_count', @real_set_size, @set_size
				IF @QueryMethod IN ('MINHASH8','MINHASH15')
				BEGIN
					DELETE
						FROM CRC.QT_QUERY_RESULT_SKETCH
						WHERE RESULT_INSTANCE_ID = @result_instance_id
					INSERT INTO CRC.QT_QUERY_RESULT_SKETCH (RESULT_INSTANCE_ID, SKETCH_SIZE, ORIG_SIZE, FILTERED_SIZE, ORIG_ESTIMATE, FILTERED_ESTIMATE, ERROR_RELATIVE, ERROR_ABSOLUTE)
						SELECT @result_instance_id, sketch_m, sketch_n, sketch_q, sketch_e, num_patients, ERROR_RELATIVE, ERROR_ABSOLUTE
						FROM #GlobalQueryCounts g
							CROSS APPLY (SELECT CAST(sketch_n AS FLOAT) n, CAST(sketch_q AS FLOAT) q, CAST(sketch_e AS FLOAT) e, CAST(sketch_m AS FLOAT) m) f
							CROSS APPLY (
									SELECT (CASE WHEN n=0 THEN NULL ELSE 1/SQRT(n) END) Rc,
										(CASE WHEN q=0 or e=0 THEN NULL ELSE SQRT(n/(n-1))*SQRT((1/q)-(1/n))*SQRT(1-(n/m)) END) Rq
								) rx
							CROSS APPLY (
									SELECT (CASE WHEN Rc IS NULL OR Rq IS NULL THEN NULL ELSE 1.96*SQRT(Rc*Rc+Rq*Rq+Rc*Rc*Rq*Rq) END) R
								) r
							CROSS APPLY (
									SELECT (CASE WHEN n=0 or q=0 or e=0 or R IS NULL THEN 0 ELSE R END) ERROR_RELATIVE,
										(CASE WHEN n=0 THEN 0 WHEN q=0 or e=0 or R IS NULL THEN 3 ELSE R*num_patients END) ERROR_ABSOLUTE
								) e
						WHERE query_master_id = @QueryMasterID
					SELECT @SketchError = ERROR_RELATIVE
						FROM CRC.QT_QUERY_RESULT_SKETCH
						WHERE result_instance_id = @result_instance_id
				END
			END
			ELSE --BREAKDOWNS
			BEGIN
				-- Get the breakdown counts
				EXEC @uspRunQueryInstanceBreakdown
					@QueryMasterID = @QueryMasterID,
					@DomainID = @DomainID,
					@UserID = @UserID,
					@ProjectID = @ProjectID,
					@BreakdownName = @result_name
				-- Estimate
				IF @QueryMethod IN ('MINHASH8','MINHASH15')
				BEGIN
					DECLARE @SampledPatients INT
					SELECT @SampledPatients = COUNT(*) FROM #GlobalPatientList WHERE query_master_id=@QueryMasterID
					IF @SampledPatients>0
						UPDATE #GlobalBreakdownCounts
							SET real_size = FLOOR(@real_set_size * (real_size/CAST(@SampledPatients as float)) + 0.5)
				END
				-- Obfuscate the result if needed
				UPDATE #GlobalBreakdownCounts
					SET set_size = 
						(CASE WHEN @obfusc_method IS NULL THEN real_size
							ELSE real_size + FLOOR(ABS(BINARY_CHECKSUM(NEWID())/2147483648.0)*7) - 3
							END)
				UPDATE #GlobalBreakdownCounts
					SET set_size = 0
					WHERE (real_size < 3 or set_size < 3)
						AND @obfusc_method IS NOT NULL
			END
			-- Create the XML Result
			INSERT INTO ..QT_XML_RESULT (RESULT_INSTANCE_ID, XML_VALUE)
				SELECT @result_instance_id,
					'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
					+'<ns10:i2b2_result_envelope xmlns:ns2="http://www.i2b2.org/xsd/hive/pdo/1.1/" xmlns:ns4="http://www.i2b2.org/xsd/cell/crc/psm/1.1/" xmlns:ns3="http://www.i2b2.org/xsd/cell/crc/pdo/1.1/" xmlns:ns9="http://www.i2b2.org/xsd/cell/ont/1.1/" xmlns:ns5="http://www.i2b2.org/xsd/hive/msg/1.1/" xmlns:ns6="http://www.i2b2.org/xsd/cell/crc/psm/querydefinition/1.1/" xmlns:ns10="http://www.i2b2.org/xsd/hive/msg/result/1.1/" xmlns:ns7="http://www.i2b2.org/xsd/cell/crc/psm/analysisdefinition/1.1/" xmlns:ns8="http://www.i2b2.org/xsd/cell/pm/1.1/">'
					+'<body>'
					+'<ns10:result name="'+REPLACE(@result_name,'''','''''')+'">'
					+CAST((
						SELECT 'int' "data/@type",
							column_name "data/@column",
							format(set_size,'N0')+(case when @SketchError>0 then ' &plusmn; '+format(@SketchError*100,'N2')+'%' else '' end) "data/@display",
							(CASE @QueryMethod
								WHEN 'MINHASH15' THEN 'Accurate Estimate'
								WHEN 'MINHASH8' THEN 'Fast Estimate'
								ELSE NULL END) "data/@comment",
							set_size "data"
						FROM #GlobalBreakdownCounts
						FOR XML PATH(''), TYPE
						) AS VARCHAR(MAX))
					+'</ns10:result>'
					+'</body>'
					+'</ns10:i2b2_result_envelope>'
		END
		-- Set the Result Instance status to finished
		UPDATE ..QT_QUERY_RESULT_INSTANCE
			SET	SET_SIZE = @set_size,
				REAL_SET_SIZE = @real_set_size,
				OBFUSC_METHOD = (case when @QueryMethod IN ('MINHASH8','MINHASH15') then 'SAMPLING' else @obfusc_method end),
				END_DATE = GetDate(),
				STATUS_TYPE_ID = 3 -- Finished
			WHERE RESULT_INSTANCE_ID = @result_instance_id
		-- Move to the next result output
		SELECT @i = @i + 1
	END

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Change status of Query Instance
	-- ***************************************************************************
	-- ***************************************************************************

	UPDATE ..QT_QUERY_INSTANCE
		SET	END_DATE = GetDate(),
			STATUS_TYPE_ID = 6 -- Completed
		WHERE QUERY_INSTANCE_ID = @QueryInstanceID

END
GO
GO
CREATE PROCEDURE [CRC].[uspRunQueryInstanceBreakdown]
	@QueryMasterID INT,
	@DomainID VARCHAR(50),
	@UserID VARCHAR(50),
	@ProjectID VARCHAR(50),
	@BreakdownName VARCHAR(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--*********************************************************************
	--*********************************************************************
	--**** Hard-coded breakdowns
	--*********************************************************************
	--*********************************************************************

	-- This is a fake example of a custom breakdown by SEX_CD
	IF @BreakdownName = 'CUSTOM_PATIENT_GENDER_COUNT_XML'
	BEGIN
		-- Generate the counts
		INSERT INTO #GlobalBreakdownCounts(column_name,real_size)
			SELECT (CASE WHEN SEX_CD='F' THEN 'Female' ELSE 'Male' END), COUNT(*) n
			FROM #GlobalResultPatientList p
				INNER JOIN ..PATIENT_DIMENSION b
					ON p.patient_num = b.patient_num
			WHERE SEX_CD IN ('F','M')
			GROUP BY SEX_CD
			ORDER BY 1
		-- Exit the procedure
		RETURN;
	END

	--*********************************************************************
	--*********************************************************************
	--**** Regular breakdowns
	--*********************************************************************
	--*********************************************************************

	-----------------------------------------------------------------------
	-- Declare variables and temp tables
	-----------------------------------------------------------------------

	DECLARE @Schema VARCHAR(100)
	DECLARE @OntSchema VARCHAR(100)

	DECLARE @Key VARCHAR(900)
	DECLARE @Table VARCHAR(200)
	DECLARE @Path VARCHAR(700)
	DECLARE @TableName VARCHAR(100)

	DECLARE @UseCQ2Tables BIT
	DECLARE @i INT
	DECLARE @maxi INT

	DECLARE @sql NVARCHAR(MAX)

	CREATE TABLE #Items (
		item_id INT IDENTITY(1,1) PRIMARY KEY,
		item_table VARCHAR(200),
		c_hlevel INT,
		c_fullname VARCHAR(700),
		c_name VARCHAR(2000),
		c_facttablecolumn VARCHAR(50),
		c_tablename VARCHAR(50),
		c_columnname VARCHAR(50),
		c_columndatatype VARCHAR(50),
		c_operator VARCHAR(10),
		c_dimcode VARCHAR(700),
		concept_path_id INT,
		concept_cd VARCHAR(50),
		set_size INT
	)

	-----------------------------------------------------------------------
	-- Set variables and validate
	-----------------------------------------------------------------------

	-- Get the schema
	SELECT @Schema = OBJECT_SCHEMA_NAME(@@PROCID)

	-- Get the ontology cell schema
	EXEC [HIVE].[uspGetCellSchema]	@Service = 'OntologyService',
									@DomainID = @DomainID,
									@UserID = @UserID,
									@ProjectID = @ProjectID,
									@CellSchema = @OntSchema OUTPUT

	SELECT @Key = VALUE
		FROM ..QT_BREAKDOWN_PATH
		WHERE NAME = @BreakdownName

	IF @Key IS NULL
		RETURN -- Unknown path

	SELECT @Table = SUBSTRING(@Key,3,CHARINDEX('\',@Key,3)-3),
			@Path = SUBSTRING(@Key,CHARINDEX('\',@Key,3),700)

	IF (@Table IS NULL) OR (@Path IS NULL)
		RETURN -- Invalid path

	-----------------------------------------------------------------------
	-- Get the breakdown paths from the ontology
	-----------------------------------------------------------------------

	-- Get the ontology table name
	SELECT @sql = 'SELECT @TableNameOUT = c_table_name
					FROM '+@OntSchema+'.TABLE_ACCESS
					WHERE c_table_cd = @Table'
					+(CASE WHEN HIVE.fnHasUserRole(@ProjectID,@UserID,'DATA_PROT')=1 THEN '' ELSE ' AND ISNULL(C_PROTECTED_ACCESS,''N'') <> ''Y''' END)
	EXEC sp_executesql @sql,
			N'@Table VARCHAR(200), @TableNameOUT VARCHAR(100) OUTPUT',
			@Table = @Table,
			@TableNameOUT = @TableName OUTPUT

	-- Get the breakdown items
	SELECT @sql = 'SELECT 
			'''+@OntSchema+'.'+@TableName+''' item_table, 
			c_hlevel, c_fullname, c_name, c_facttablecolumn, c_tablename, c_columnname, c_columndatatype, c_operator, c_dimcode, NULL concept_path_id, NULL concept_cd, 0 set_size
		FROM '+@OntSchema+'.'+@TableName+'
		WHERE C_FULLNAME LIKE '''+REPLACE(@Path,'''','''''')+'%''
			AND C_HLEVEL = 1 +
				(SELECT C_HLEVEL
				FROM '+@OntSchema+'.'+@TableName+'
				WHERE C_FULLNAME = '''+REPLACE(@Path,'''','''''')+''')'
	INSERT INTO #Items (item_table, c_hlevel, c_fullname, c_name, c_facttablecolumn, c_tablename, c_columnname, c_columndatatype, c_operator, c_dimcode, concept_path_id, concept_cd, set_size)
		EXEC sp_executesql @sql

	-- Escape item fields
	UPDATE #Items
		SET c_dimcode = ''''+replace(c_dimcode,'''','''''')+'%'''
		WHERE c_operator = 'LIKE'
	UPDATE #Items
		SET c_dimcode = '('+c_dimcode+')'
		WHERE c_operator = 'IN'
	UPDATE #Items
		SET c_dimcode = ''''+replace(c_dimcode,'''','''''')+''''
		WHERE c_columndatatype = 'T' AND c_operator NOT IN ('LIKE','IN')

	-----------------------------------------------------------------------
	-- Use CQ2 tables if possible to get breakdown counts
	-----------------------------------------------------------------------

	-- Determine if CQ2 tables can be used
	SELECT @UseCQ2Tables = 0
	SELECT @UseCQ2Tables = 1
		FROM ..CQ2_PARAMS
		WHERE PARAM_NAME_CD = 'USE_CQ2_TABLES' AND VALUE = 'Y'

	-- Use CQ2 tables to get breakdowns
	IF (@UseCQ2Tables = 1)
	BEGIN
		-- Convert paths to IDs and concepts
		SELECT @sql = '
			UPDATE i
				SET i.concept_path_id = p.CONCEPT_PATH_ID, i.concept_cd = p.CONCEPT_CD
				FROM #Items i INNER JOIN '+@Schema+'.CQ2_CONCEPT_PATH p ON i.c_fullname = p.C_FULLNAME'
		EXEC sp_executesql @sql

		-- Get counts for concepts
		SELECT @sql = '
			UPDATE i
				SET set_size = n
				FROM #Items i
					INNER JOIN (
						SELECT i.item_id, COUNT(*) n
						FROM #Items i
							INNER JOIN '+@Schema+'.CQ2_FACT_COUNTS_CONCEPT_PATIENT t
								ON i.concept_cd = t.CONCEPT_CD
							INNER JOIN #GlobalResultPatientList p
								ON t.PATIENT_NUM = p.PATIENT_NUM '--AND p.query_master_id = '+CAST(@QueryMasterID AS VARCHAR(50))+'
						+'WHERE i.concept_path_id IS NOT NULL AND i.concept_cd IS NOT NULL
						GROUP BY i.item_id
					) t ON t.item_id = i.item_id 
				OPTION(RECOMPILE)'
		EXEC sp_executesql @sql

		-- Get counts for paths
		SELECT @sql = '
			UPDATE i
				SET set_size = n
				FROM #Items i
					INNER JOIN (
						SELECT i.item_id, COUNT(*) n
						FROM #Items i
							INNER JOIN '+@Schema+'.CQ2_FACT_COUNTS_PATH_PATIENT t
								ON i.concept_path_id = t.CONCEPT_PATH_ID
							INNER JOIN #GlobalResultPatientList p
								ON t.PATIENT_NUM = p.PATIENT_NUM '--AND p.query_master_id = '+CAST(@QueryMasterID AS VARCHAR(50))+'
						+'WHERE i.concept_path_id IS NOT NULL AND i.concept_cd IS NULL
						GROUP BY i.item_id
					) t ON t.item_id = i.item_id 
				OPTION(RECOMPILE)'
		EXEC sp_executesql @sql

	END

	-----------------------------------------------------------------------
	-- Use non-CQ2 tables get the rest of the breakdown counts
	-----------------------------------------------------------------------

	-- Use non-CQ2 tables to get breakdowns
	SELECT @i = IsNull((SELECT MIN(item_id) FROM #items WHERE concept_path_id IS NULL),1), 
		@maxi = IsNull((SELECT MAX(item_id) FROM #items WHERE concept_path_id IS NULL),0)
	WHILE (@i <= @maxi) AND (1=1)
	BEGIN
		SELECT @sql = '
			UPDATE #items
				SET set_size = (
					SELECT COUNT(DISTINCT p.PATIENT_NUM)
					'+(CASE 
					WHEN i.concept_path_id IS NOT NULL AND i.CONCEPT_CD IS NOT NULL THEN '
						FROM '+@Schema+'.CQ2_FACT_COUNTS_CONCEPT_PATIENT t, #GlobalResultPatientList p
						WHERE t.CONCEPT_CD = '''+REPLACE(i.concept_cd,'''','''''')+'''
							AND t.PATIENT_NUM = p.PATIENT_NUM '--AND p.query_master_id = '+CAST(@QueryMasterID AS VARCHAR(50))
					WHEN i.concept_path_id IS NOT NULL THEN '
						FROM '+@Schema+'.CQ2_FACT_COUNTS_PATH_PATIENT t, #GlobalResultPatientList p
						WHERE t.CONCEPT_PATH_ID = '+CAST(i.concept_path_id AS VARCHAR(50))+'
							AND t.PATIENT_NUM = p.PATIENT_NUM '--AND p.query_master_id = '+CAST(@QueryMasterID AS VARCHAR(50))
					WHEN i.c_tablename IN ('patient_dimension','visit_dimension') THEN '
						FROM '+@Schema+'.'+i.c_tablename+' t, #GlobalResultPatientList p
						WHERE t.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode+'
							AND t.PATIENT_NUM = p.PATIENT_NUM '--AND p.query_master_id = '+CAST(@QueryMasterID AS VARCHAR(50))
					ELSE '
						FROM '+@Schema+'.OBSERVATION_FACT f, #GlobalResultPatientList p
						WHERE f.'+i.c_facttablecolumn+' IN (
								SELECT '+i.c_facttablecolumn+'
								FROM '+@Schema+'.'+i.c_tablename+' t
								WHERE t.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode+'
							)
							AND f.PATIENT_NUM = p.PATIENT_NUM '--AND p.query_master_id = '+CAST(@QueryMasterID AS VARCHAR(50))
					END)+'
				)
				WHERE item_id = '+CAST(@i AS VARCHAR(50))
				+' OPTION(RECOMPILE)'
			FROM #items i
			WHERE item_id = @i
		EXEC sp_executesql @sql
		SELECT @i = IsNull((SELECT MIN(item_id) FROM #items WHERE item_id > @i AND concept_path_id IS NULL),@maxi+1)
	END

	-----------------------------------------------------------------------
	-- Save the breakdowns to the #GlobalBreakdownCounts table
	-----------------------------------------------------------------------

	IF @BreakdownName IN ('FAKE_BREAKDOWN_SORT_BY_SIZE_XML')
	BEGIN
		INSERT INTO #GlobalBreakdownCounts(column_name,real_size)
			SELECT TOP(10) c_name, set_size
				FROM #items
				WHERE set_size>0
				ORDER BY set_size DESC
	END
	ELSE
	BEGIN
		INSERT INTO #GlobalBreakdownCounts(column_name,real_size)
			SELECT c_name, set_size
				FROM #items
				WHERE set_size>0
				ORDER BY c_name
	END

END
GO
GO
CREATE PROCEDURE [CRC].[uspRunQueryInstanceQM]
	@QueryMasterID INT,
	@DomainID VARCHAR(50),
	@UserID VARCHAR(50),
	@ProjectID VARCHAR(50),
	@ReturnPatientCount BIT = 0,
	@ReturnPatientList BIT = 0,
	@ReturnEncounterCount BIT = 0,
	@ReturnEncounterList BIT = 0,
	@ReturnTemporalListStart VARCHAR(50) = NULL,
	@ReturnTemporalListEnd VARCHAR(50) = NULL,
	@QueryMethod VARCHAR(100) = 'EXACT'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Declare variables
	-- ***************************************************************************
	-- ***************************************************************************

	DECLARE @QueryStartTime DATETIME
	SELECT @QueryStartTime = GETDATE()

	DECLARE @Schema VARCHAR(100)
	DECLARE @OntSchema VARCHAR(255)

	-- Debug options
	DECLARE @DebugEnableCQ2Tables BIT
	DECLARE @DebugEnableCQ2SketchTables BIT
	DECLARE @DebugEnableCQ2PathTables BIT
	DECLARE @DebugEnablePanelReorder BIT
	DECLARE @DebugEnableAvoidTempListTables BIT
	DECLARE @DebugEnableEstimatedCountAsActual BIT
	DECLARE @DebugShowDetails BIT
	SELECT	@DebugEnableCQ2Tables = 1,
			@DebugEnableCQ2SketchTables = 1,
			@DebugEnableCQ2PathTables = 1,
			@DebugEnablePanelReorder = 1,
			@DebugEnableAvoidTempListTables = 1,
			@DebugEnableEstimatedCountAsActual = 1,
			@DebugShowDetails = 0

	-- Execution options
	DECLARE @UseCQ2Tables BIT
	DECLARE @UseCQ2SketchTables BIT
	SELECT	@UseCQ2Tables = @DebugEnableCQ2Tables,
			@UseCQ2SketchTables = @DebugEnableCQ2SketchTables
	IF (@UseCQ2Tables=1)
		SELECT @UseCQ2Tables=0 FROM CRC.CQ2_PARAMS WHERE PARAM_NAME_CD='USE_CQ2_TABLES' AND VALUE='N'
	IF (@UseCQ2Tables=1) AND (@UseCQ2SketchTables=1)
		SELECT @UseCQ2SketchTables=0 FROM CRC.CQ2_PARAMS WHERE PARAM_NAME_CD='USE_CQ2_SKETCH_TABLES' AND VALUE='N'
	ELSE
		SELECT @UseCQ2SketchTables=0

	DECLARE @QueryDefinition XML
	
	DECLARE @query_name VARCHAR(250)
	DECLARE @query_timing VARCHAR(100)	--ANY, SAMEVISIT, SAMEINSTANCENUM
	DECLARE @specificity_scale INT
	
	DECLARE @p INT
	DECLARE @i INT
	DECLARE @MaxP INT
	DECLARE @MaxI INT

	DECLARE @k INT
	DECLARE @ProcessStartTime DATETIME
	DECLARE @sql NVARCHAR(MAX)
	DECLARE @sqlTemp1 NVARCHAR(MAX)
	DECLARE @sqlTemp2 NVARCHAR(MAX)
	
	DECLARE @ItemType VARCHAR(100)
	DECLARE @ItemKeyID INT

	DECLARE @panel_date_from DATETIME
	DECLARE @panel_date_to DATETIME
	DECLARE @panel_accuracy_scale INT
	DECLARE @invert TINYINT
	DECLARE @panel_timing VARCHAR(100)
	DECLARE @total_item_occurrences INT
	DECLARE @has_date_constraint TINYINT
	DECLARE @has_date_range_constraint TINYINT
	DECLARE @has_modifier_constraint TINYINT
	DECLARE @has_value_constraint TINYINT
	DECLARE @number_of_items INT
	DECLARE @previous_panel_timing VARCHAR(100)
	DECLARE @panel_table VARCHAR(200)
	DECLARE @join_to_temp NVARCHAR(MAX)
	DECLARE @previous_panel_temp_table NVARCHAR(MAX)
	DECLARE @panel_temp_table NVARCHAR(MAX)
	DECLARE @panel_temp_table_columns NVARCHAR(MAX)
	
	DECLARE @UseTempListTables BIT
	DECLARE @UseEstimatedCountAsActual BIT

	DECLARE @PanelMaxdop VARCHAR(50)

	DECLARE @SketchPanel INT
	DECLARE @SketchPanelE INT
	DECLARE @SketchPanelN INT
	DECLARE @SketchPanelQ INT
	DECLARE @SketchPanelM INT

	DECLARE @result_type_id INT
	DECLARE @result_instance_id INT

	DECLARE @HasProtectedAccess BIT

	CREATE TABLE #Panels (
		panel_number INT PRIMARY KEY,
		panel_date_from DATETIME,
		panel_date_to DATETIME,
		panel_accuracy_scale INT,
		invert TINYINT,
		panel_timing VARCHAR(100),
		total_item_occurrences INT,
		items XML,
		estimated_count INT,
		has_multiple_occurrences TINYINT,
		has_date_constraint TINYINT,
		has_date_range_constraint TINYINT,
		has_modifier_constraint TINYINT,
		has_value_constraint TINYINT,
		has_complex_value_constraint TINYINT,
		number_of_constraints TINYINT,
		all_concept_paths TINYINT,
		number_of_items INT,
		panel_table VARCHAR(200),
		process_order INT,
		previous_panel_timing VARCHAR(100),
		panel_sql NVARCHAR(MAX),
		actual_count INT,
		run_time_ms INT
	)							

	CREATE TABLE #Items (
		item_id INT IDENTITY(1,1) PRIMARY KEY,
		panel_number INT,
		item_key VARCHAR(900),
		item_type VARCHAR(100),
		item_key_id INT,
		item_table VARCHAR(200),
		item_path VARCHAR(700),
		concept_path_id INT,
		concept_cd VARCHAR(50),
		modifier_key VARCHAR(900),
		modifier_path VARCHAR(700),
		date_from DATETIME,
		date_to DATETIME,
		value_constraint VARCHAR(MAX),
		value_operator VARCHAR(MAX),
		value_unit_of_measure VARCHAR(MAX),
		value_type VARCHAR(MAX),
		c_facttablecolumn VARCHAR(50),
		c_tablename VARCHAR(50),
		c_columnname VARCHAR(50),
		c_columndatatype VARCHAR(50),
		c_operator VARCHAR(10),
		c_dimcode VARCHAR(700),
		m_facttablecolumn VARCHAR(50),
		m_tablename VARCHAR(50),
		m_columnname VARCHAR(50),
		m_columndatatype VARCHAR(50),
		m_operator VARCHAR(10),
		m_dimcode VARCHAR(700),
		c_totalnum INT,
		valid TINYINT,
		ont_table VARCHAR(255)
	)
	
	CREATE TABLE #Concepts (
		panel_number INT NOT NULL,
		concept_cd VARCHAR(50) NOT NULL,
		date_from DATETIME,
		date_to DATETIME,
		value_constraint VARCHAR(MAX),
		value_operator VARCHAR(MAX),
		value_unit_of_measure VARCHAR(MAX),
		value_type VARCHAR(MAX),
		estimated_count INT
	)

	CREATE TABLE #QueryCounts (
		num_patients int,
		num_encounters bigint,
		num_instances bigint,
		num_facts bigint
	)

	CREATE TABLE #PatientList (
		panels INT NOT NULL,
		patient_num INT NOT NULL,
	)
	
	CREATE TABLE #EncounterList (
		panels INT NOT NULL,
		encounter_num BIGINT NOT NULL,
		patient_num INT NOT NULL
	)

	CREATE TABLE #InstanceList (
		panels INT NOT NULL,
		encounter_num BIGINT NOT NULL,
		patient_num INT NOT NULL,
		concept_cd VARCHAR(50) NOT NULL,
		provider_id VARCHAR(50) NOT NULL,
		start_date DATETIME NOT NULL,
		instance_num INT NOT NULL
	)

	-- Get the schema
	SELECT @Schema = OBJECT_SCHEMA_NAME(@@PROCID)
	DECLARE @uspRunQueryInstanceQM VARCHAR(100)
	SELECT @uspRunQueryInstanceQM = @Schema+'.uspRunQueryInstanceQM'

	-- Get the ontology cell schema
	EXEC [HIVE].[uspGetCellSchema]	@Service = 'OntologyService',
									@DomainID = @DomainID,
									@UserID = @UserID,
									@ProjectID = @ProjectID,
									@CellSchema = @OntSchema OUTPUT

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Parse the Query Definition
	-- ***************************************************************************
	-- ***************************************************************************

	------------------------------------------------------------------------------
	-- Get the query definition and confirm that the user can run the query
	------------------------------------------------------------------------------

	-- Get Query Master data
	IF @QueryMasterID >= 0
	BEGIN
		SELECT	@QueryDefinition = m.REQUEST_XML,
				@ProjectID = ISNULL(@ProjectID,m.[GROUP_ID])
			FROM ..QT_QUERY_MASTER m
			WHERE m.QUERY_MASTER_ID = @QueryMasterID
	END
	ELSE
	BEGIN
		SELECT	@QueryDefinition = query_definition
			FROM #GlobalSubqueryList
			WHERE subquery_id = @QueryMasterID
	END
	
	-- Check for security
	IF HIVE.fnHasUserRole(@ProjectID,@UserID,'DATA_OBFSC') = 0
	BEGIN
		-- TODO: Add error handling
		RETURN
	END
	SELECT @HasProtectedAccess = HIVE.fnHasUserRole(@ProjectID,@UserID,'DATA_PROT')

	------------------------------------------------------------------------------
	-- Parse the query definition
	------------------------------------------------------------------------------

	-- Get query-level information from Query Definition
	SELECT	@query_name = @QueryDefinition.value('query_definition[1]/query_name[1]','VARCHAR(250)'),
			@query_timing = @QueryDefinition.value('query_definition[1]/query_timing[1]','VARCHAR(100)'),
			@specificity_scale = @QueryDefinition.value('query_definition[1]/specificity_scale[1]','INT')
	
	-- Get panel-level information from Query Definition
	INSERT INTO #Panels (panel_number, panel_date_from, panel_date_to, panel_accuracy_scale, invert, panel_timing, total_item_occurrences, items,
							estimated_count, has_date_constraint, has_value_constraint)
		SELECT	P.x.value('panel_number[1]','INT'),
				--P.x.value('panel_date_from[1]','DATETIME'),
				--P.x.value('panel_date_to[1]','DATETIME'),
				(case when IsDate(date_from_string)=1
						then cast(date_from_string as datetime)
					when right(date_from_string,6) like '-__:__' and IsDate(left(date_from_string,len(date_from_string)-6))=1
						then cast(left(date_from_string,len(date_from_string)-6) as datetime)
					else null end),
				(case when IsDate(date_to_string)=1
						then cast(date_to_string as datetime)
					when right(date_to_string,6) like '-__:__' and IsDate(left(date_to_string,len(date_to_string)-6))=1
						then cast(left(date_to_string,len(date_to_string)-6) as datetime)
					else null end),
				P.x.value('panel_accuracy_scale[1]','INT'),
				P.x.value('invert[1]','TINYINT'),
				P.x.value('panel_timing[1]','VARCHAR(100)'),
				P.x.value('total_item_occurrences[1]','INT'),
				P.x.query('item'),
				0, 0, 0
		FROM @QueryDefinition.nodes('query_definition[1]/panel') as P(x)
			CROSS APPLY (
				SELECT P.x.value('panel_date_from[1]','VARCHAR(100)') date_from_string,
					P.x.value('panel_date_to[1]','VARCHAR(100)') date_to_string
			) d

	-- Get item-level information from Query Definition
	INSERT INTO #Items (panel_number, item_key, modifier_key, date_from, date_to, value_constraint, value_operator, value_unit_of_measure, value_type, valid)
		SELECT	p.panel_number,
				I.x.value('item_key[1]','VARCHAR(900)'),
				I.x.value('constrain_by_modifier[1]/modifier_key[1]','VARCHAR(900)'),
				(case when IsDate(date_from_string)=1
						then cast(date_from_string as datetime)
					when right(date_from_string,6) like '-__:__' and IsDate(left(date_from_string,len(date_from_string)-6))=1
						then cast(left(date_from_string,len(date_from_string)-6) as datetime)
					else null end),
				(case when IsDate(date_to_string)=1
						then cast(date_to_string as datetime)
					when right(date_to_string,6) like '-__:__' and IsDate(left(date_to_string,len(date_to_string)-6))=1
						then cast(left(date_to_string,len(date_to_string)-6) as datetime)
					else null end),
				IsNull(I.x.value('constrain_by_value[1]/value_constraint[1]','VARCHAR(MAX)'),
					I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_constraint[1]','VARCHAR(MAX)')),
				IsNull(I.x.value('constrain_by_value[1]/value_operator[1]','VARCHAR(MAX)'),
					I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_operator[1]','VARCHAR(MAX)')),
				IsNull(I.x.value('constrain_by_value[1]/value_unit_of_measure[1]','VARCHAR(MAX)'),
					I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_unit_of_measure[1]','VARCHAR(MAX)')),
				IsNull(I.x.value('constrain_by_value[1]/value_type[1]','VARCHAR(MAX)'),
					I.x.value('constrain_by_modifier[1]/constrain_by_value[1]/value_type[1]','VARCHAR(MAX)')),
				0
		FROM #Panels p CROSS APPLY p.items.nodes('//item') as I(x)
			CROSS APPLY (
				SELECT I.x.value('constrain_by_date[1]/date_from[1]','VARCHAR(100)') date_from_string,
					I.x.value('constrain_by_date[1]/date_to[1]','VARCHAR(100)') date_to_string
			) d
	UPDATE #Items
		SET item_type = (CASE WHEN item_key LIKE '\\%\%' THEN 'concept'
							WHEN item_key LIKE 'masterid:%' THEN 'masterid'
							WHEN item_key LIKE 'patient_set_coll_id:%' THEN 'patient_set_coll_id'
							WHEN item_key LIKE 'patient_set_enc_id:%' THEN 'patient_set_enc_id'
							ELSE NULL END)
	UPDATE #Items
		SET item_key_id = SUBSTRING(item_key,LEN(item_type)+2,LEN(item_key))
		WHERE (item_type IS NOT NULL) AND (item_type <> 'concept')
	UPDATE #Items
		SET	item_table = SUBSTRING(item_key,3,CHARINDEX('\',item_key,3)-3),
			item_path = SUBSTRING(item_key,CHARINDEX('\',item_key,3),700),
			modifier_path = SUBSTRING(modifier_key,CHARINDEX('\',modifier_key,3),700)
		WHERE item_type = 'concept'

	------------------------------------------------------------------------------
	-- Get information about each item in the query
	------------------------------------------------------------------------------

	-- Get item details from ontology tables
	-- Process each item as needed
	SELECT @i = 1, @MaxI = IsNull((SELECT MAX(item_id) FROM #Items),0)
	WHILE @i <= @MaxI
	BEGIN
		SELECT @ItemType = item_type, @ItemKeyID = item_key_id
			FROM #Items
			WHERE item_id = @i
		IF @ItemType = 'concept'
		BEGIN
			-- Lookup table_name
			SELECT @sql = 'UPDATE i
							SET i.ont_table = '''+REPLACE(@OntSchema,'''','''''')+'.''+t.c_table_name
							FROM #Items i, '+@OntSchema+'.TABLE_ACCESS t
							WHERE i.item_id = '+CAST(@i AS VARCHAR(50))+' 
								AND i.item_table = t.c_table_cd
							'
							+(CASE WHEN @HasProtectedAccess=1 THEN '' ELSE 'AND ISNULL(C_PROTECTED_ACCESS,''N'') <> ''Y''' END)
			EXEC sp_executesql @sql
			-- Get item details
			SELECT @sql = 'UPDATE i
								SET	i.valid = 1,
									i.c_facttablecolumn = o.c_facttablecolumn,
									i.c_tablename = o.c_tablename,
									i.c_columnname = o.c_columnname,
									i.c_columndatatype = o.c_columndatatype,
									i.c_operator = o.c_operator,
									i.c_dimcode = o.c_dimcode,
									i.c_totalnum = o.c_totalnum
								FROM #Items i, '+i.ont_table+' o
								WHERE i.item_id = '+CAST(@i AS VARCHAR(50))+' AND i.item_path = o.c_fullname'
				FROM #Items i
				WHERE i.item_id = @i
			EXEC sp_executesql @sql
			-- Get modifier details
			SELECT @sql = 'UPDATE i
								SET	i.m_facttablecolumn = o.c_facttablecolumn,
									i.m_tablename = o.c_tablename,
									i.m_columnname = o.c_columnname,
									i.m_columndatatype = o.c_columndatatype,
									i.m_operator = o.c_operator,
									i.m_dimcode = o.c_dimcode
								FROM #Items i, '+i.ont_table+' o
								WHERE i.item_id = '+CAST(@i AS VARCHAR(50))+' AND i.modifier_path = o.c_fullname
									AND i.item_path LIKE o.m_applied_path AND ISNULL(o.m_exclusion_cd,'''') <> ''X'' '
				FROM #Items i
				WHERE i.item_id = @i AND i.modifier_path<>''
			EXEC sp_executesql @sql
		END
		IF @ItemType = 'masterid'
		BEGIN
			--IF NOT EXISTS (SELECT * FROM #GlobalPatientList WHERE query_master_id = @ItemKeyID)
			IF NOT EXISTS (SELECT * FROM #GlobalQueryCounts WHERE query_master_id = @ItemKeyID)
			BEGIN
				EXEC @uspRunQueryInstanceQM
					@QueryMasterID = @ItemKeyID,
					@DomainID = @DomainID,
					@UserID = @UserID,
					@ProjectID = @ProjectID,
					@ReturnPatientCount = 1,
					@ReturnPatientList = 1
			END
			UPDATE #Items
				SET	valid = 1,
					c_facttablecolumn = 'patient_num',
					c_tablename = 'patient_dimension',
					c_columnname = 'patient_num',
					c_columndatatype = 'N',
					c_operator = 'IN',
					c_dimcode = 'SELECT patient_num FROM #GlobalPatientList WHERE query_master_id = '+cast(@ItemKeyID AS VARCHAR(50)),
					c_totalnum = (SELECT num_patients FROM #GlobalQueryCounts WHERE query_master_id = @ItemKeyID)
				WHERE item_id = @i
		END
		IF @ItemType = 'patient_set_coll_id'
		BEGIN
			UPDATE #Items
				SET	valid = 1,
					c_facttablecolumn = 'patient_num',
					c_tablename = 'patient_dimension',
					c_columnname = 'patient_num',
					c_columndatatype = 'N',
					c_operator = 'IN',
					c_dimcode = 'SELECT patient_num FROM '+@Schema+'.QT_PATIENT_SET_COLLECTION WHERE result_instance_id = '+cast(@ItemKeyID AS VARCHAR(50)),
					c_totalnum = (SELECT real_set_size FROM ..QT_QUERY_RESULT_INSTANCE WHERE result_instance_id = @ItemKeyID)
				WHERE item_id = @i
		END
		IF @ItemType = 'patient_set_enc_id'
		BEGIN
			UPDATE #Items
				SET	valid = 1,
					c_facttablecolumn = 'encounter_num',
					c_tablename = 'visit_dimension',
					c_columnname = 'encounter_num',
					c_columndatatype = 'N',
					c_operator = 'IN',
					c_dimcode = 'SELECT encounter_num FROM '+@Schema+'.QT_PATIENT_ENC_COLLECTION WHERE result_instance_id = '+cast(@ItemKeyID AS VARCHAR(50)),
					c_totalnum = (SELECT real_set_size FROM ..QT_QUERY_RESULT_INSTANCE WHERE result_instance_id = @ItemKeyID)
				WHERE item_id = @i
		END
		SELECT @i = @i + 1
	END

	------------------------------------------------------------------------------
	-- Validate query
	------------------------------------------------------------------------------

	-- Escape and validate item fields
	UPDATE #Items
		SET c_dimcode = ''''+replace(c_dimcode,'''','''''')+'%'''
		WHERE c_operator = 'LIKE'
	UPDATE #Items
		SET c_dimcode = '('+c_dimcode+')'
		WHERE c_operator = 'IN'
	UPDATE #Items
		SET c_dimcode = ''''+replace(c_dimcode,'''','''''')+''''
		WHERE c_columndatatype = 'T' AND c_operator NOT IN ('LIKE','IN')
	UPDATE #Items
		SET value_constraint = ''''+replace(value_constraint,'''','''''')+''''
		WHERE value_type IN ('TEXT','FLAG') AND value_operator <> 'IN'
	UPDATE #Items
		SET valid = 0
		WHERE value_type = 'NUMBER' AND value_operator <> 'BETWEEN' AND IsNumeric(value_constraint) = 0
	UPDATE #Items
		SET valid = 0
		WHERE item_id IN (
				SELECT item_id
				FROM (
					SELECT CHARINDEX(' AND ',value_constraint) x, *
					FROM #Items
					WHERE value_type = 'NUMBER' AND value_operator = 'BETWEEN'
				) t
				WHERE IsNumeric(CASE WHEN x > 0 THEN LEFT(value_constraint,x-1) ELSE NULL END) = 0
					OR IsNumeric(CASE WHEN x > 0 THEN SUBSTRING(value_constraint,x+5,LEN(value_constraint)) ELSE NULL END) = 0
			)
	UPDATE #Items
		SET value_type = NULL
		WHERE IsNull(value_type,'') NOT IN ('','TEXT','NUMBER','FLAG')
	UPDATE #Items
		SET value_operator = (CASE	WHEN value_operator IN ('EQ','E') THEN '='
									WHEN value_operator IN ('LT','L') THEN '<'
									WHEN value_operator IN ('GT','G') THEN '>'
									WHEN value_operator IN ('NE','N') THEN '<>'
									WHEN value_operator IN ('LTEQ','LE') THEN '<='
									WHEN value_operator IN ('GTEQ','GE') THEN '>='
									WHEN value_operator IN ('BETWEEN','IN') THEN value_operator
									ELSE NULL
									END)

	-- Escape and validate modifier fields
	UPDATE #Items
		SET m_dimcode = ''''+replace(m_dimcode,'''','''''')+'%'''
		WHERE m_operator = 'LIKE'
	UPDATE #Items
		SET m_dimcode = '('+m_dimcode+')'
		WHERE m_operator = 'IN'
	UPDATE #Items
		SET m_dimcode = ''''+replace(m_dimcode,'''','''''')+''''
		WHERE m_columndatatype = 'T' AND m_operator NOT IN ('LIKE','IN')

	-- Validate query timing
	-- Make sure the overall query timing is not null
	SELECT @query_timing = ISNULL(@query_timing,'ANY')
	-- Make sure the panel timing is not more specific than the query timing
	UPDATE #Panels
		SET panel_timing = @query_timing
		WHERE (panel_timing IS NULL)
			OR (@query_timing = 'SAMEVISIT' AND panel_timing = 'SAMEINSTANCENUM')
			OR (@query_timing = 'ANY')
	-- Make sure the panel timing is not more specific than the table
	UPDATE p
		SET p.panel_timing = 'SAMEVISIT'
		FROM #Panels p
		WHERE panel_timing = 'SAMEINSTANCENUM' AND NOT EXISTS (SELECT * FROM #Items i WHERE i.panel_number = p.panel_number AND i.c_facttablecolumn NOT IN ('patient_num','encounter_num'))
	UPDATE p
		SET p.panel_timing = 'ANY'
		FROM #Panels p
		WHERE panel_timing = 'SAMEVISIT' AND NOT EXISTS (SELECT * FROM #Items i WHERE i.panel_number = p.panel_number AND i.c_facttablecolumn NOT IN ('patient_num'))
	-- Make sure there are at least two panels to combine at each timing level
	UPDATE #Panels
		SET panel_timing = 'SAMEVISIT'
		WHERE panel_timing = 'SAMEINSTANCENUM'
			AND NOT EXISTS (SELECT 1 p FROM #Panels WHERE panel_timing = 'SAMEINSTANCENUM' HAVING (COUNT(*) >= 1) AND (SUM(1-invert) > 0))
	UPDATE #Panels
		SET panel_timing = 'ANY'
		WHERE panel_timing = 'SAMEVISIT'
			AND NOT EXISTS (SELECT 1 p FROM #Panels WHERE panel_timing IN ('SAMEVISIT','SAMEINSTANCENUM') HAVING (COUNT(*) >= 1) AND (SUM(1-invert) > 0))

	-- Confirm user has permissions to access items
	IF EXISTS (SELECT * FROM #Items WHERE IsNull(valid,0) = 0)
	BEGIN
		SELECT 'ERROR' Error, * FROM #Items WHERE IsNull(valid,0) = 0
		--ToDo: Set error status
		RETURN
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Analyze the query to determine execution plan
	-- ***************************************************************************
	-- ***************************************************************************

	------------------------------------------------------------------------------
	-- Combine invert panels if possible
	------------------------------------------------------------------------------

	DECLARE @PanelMerge TABLE (
		panel_number INT,
		new_panel_number INT
	)
	INSERT INTO @PanelMerge (panel_number, new_panel_number)
		SELECT p.panel_number, m.new_panel_number
			FROM #Panels p, (
					SELECT MIN(panel_number) new_panel_number, panel_date_from, panel_date_to, panel_accuracy_scale, panel_timing, total_item_occurrences
						FROM #Panels
						WHERE Invert = 1
						GROUP BY panel_date_from, panel_date_to, panel_accuracy_scale, panel_timing, total_item_occurrences
						HAVING COUNT(*)>10
				) m
			WHERE p.invert = 1 AND p.panel_number > m.new_panel_number
				AND ( (p.panel_date_from IS NULL AND m.panel_date_from IS NULL) OR (p.panel_date_from = m.panel_date_from) )
				AND ( (p.panel_date_to IS NULL AND m.panel_date_to IS NULL) OR (p.panel_date_to = m.panel_date_to) )
				AND ( (p.panel_accuracy_scale IS NULL AND m.panel_accuracy_scale IS NULL) OR (p.panel_accuracy_scale = m.panel_accuracy_scale) )
				AND ( (p.panel_timing IS NULL AND m.panel_timing IS NULL) OR (p.panel_timing = m.panel_timing) )
				AND ( (p.total_item_occurrences IS NULL AND m.total_item_occurrences IS NULL) OR (p.total_item_occurrences = m.total_item_occurrences) )
	DELETE
		FROM #Panels
		WHERE panel_number IN (SELECT panel_number FROM @PanelMerge)
	UPDATE i
		SET i.panel_number = m.new_panel_number
		FROM #Items i, @PanelMerge m
		WHERE i.panel_number = m.panel_number

	------------------------------------------------------------------------------
	-- Get item and panel information
	------------------------------------------------------------------------------

	IF @UseCQ2Tables = 1
	BEGIN
		-- Get item path information
		UPDATE i
			SET i.concept_path_id = p.concept_path_id, i.concept_cd = p.concept_cd, i.c_totalnum = coalesce(c.num_patients,d.num_patients,0)
			FROM #Items i
				INNER JOIN ..CQ2_CONCEPT_PATH p
					ON i.item_path = p.c_fullname
				LEFT OUTER JOIN ..CQ2_FACT_COUNTS_PATH c
					ON p.concept_path_id = c.concept_path_id
				LEFT OUTER JOIN ..CQ2_FACT_COUNTS_CONCEPT d
					ON p.concept_cd <> '' and p.concept_cd = d.concept_cd
			WHERE i.item_type = 'concept'

		-- Get estimated item counts when there is no count from the ontology or the path
		IF EXISTS (SELECT * FROM #Items WHERE c_totalnum IS NULL)
		BEGIN
			UPDATE j
				SET j.c_totalnum = t.n
				FROM #Items j, (
					SELECT i.item_id, i.panel_number, SUM(c.num_patients) n
						FROM #Items i, ..CQ2_FACT_COUNTS_CONCEPT c, ..CONCEPT_DIMENSION d
						WHERE i.c_totalnum IS NULL
							AND i.c_facttablecolumn = 'concept_cd' 
							AND i.c_tablename = 'concept_dimension' 
							AND i.c_columnname = 'concept_path'
							AND i.c_operator = 'LIKE'
							AND c.concept_cd = d.concept_cd 
							AND d.concept_path LIKE SUBSTRING(i.c_dimcode,2,LEN(i.c_dimcode)-2)
							AND i.item_type = 'concept'
						GROUP BY i.item_id, i.panel_number
				) t
				WHERE j.item_id = t.item_id AND j.panel_number = t.panel_number
		END
	END

	-- Calculate stats about panels
	UPDATE p
		SET p.has_multiple_occurrences = (CASE WHEN p.total_item_occurrences > 1 THEN 1 ELSE 0 END),
			p.has_date_constraint = (
				CASE WHEN (p.panel_date_from IS NOT NULL) OR (p.panel_date_to IS NOT NULL) THEN 1
					WHEN (i.has_item_date_from = 1) OR (i.has_item_date_to = 1) THEN 1 
					ELSE 0 END),
			p.has_date_range_constraint = (
				CASE WHEN (p.panel_date_from IS NOT NULL) AND (p.panel_date_to IS NOT NULL) THEN 1 
					WHEN i.has_item_date_range = 1 THEN 1
					WHEN (p.panel_date_from IS NOT NULL) AND (has_item_date_to = 1) THEN 1
					WHEN (p.panel_date_to IS NOT NULL) AND (has_item_date_from = 1) THEN 1
					ELSE 0 END),
			p.has_modifier_constraint = i.has_modifier_constraint,
			p.has_value_constraint = i.has_value_contraint,
			p.has_complex_value_constraint = i.has_complex_value_constraint,
			p.panel_table = i.panel_table,
			p.all_concept_paths = i.all_concept_paths,
			p.estimated_count = i.estimated_count,
			p.number_of_items = i.number_of_items
		FROM #Panels p, (
				SELECT panel_number,
					MAX(CASE WHEN modifier_path IS NOT NULL THEN 1 ELSE 0 END) has_modifier_constraint,
					MAX(CASE WHEN date_from IS NOT NULL THEN 1 ELSE 0 END) has_item_date_from,
					MAX(CASE WHEN date_to IS NOT NULL THEN 1 ELSE 0 END) has_item_date_to,
					MAX(CASE WHEN (date_from IS NOT NULL) AND (date_to IS NOT NULL) THEN 1 ELSE 0 END) has_item_date_range,
					MAX(CASE WHEN (value_constraint IS NOT NULL) 
									OR (value_operator IS NOT NULL) 
									OR (value_unit_of_measure IS NOT NULL) 
									OR (value_type IS NOT NULL) 
							THEN 1 ELSE 0 END) has_value_contraint,
					MAX(CASE WHEN (IsNull(value_operator,'') IN ('BETWEEN','IN','=','<>')) 
									OR (IsNull(value_type,'') IN ('TEXT','FLAG')) 
							THEN 1 ELSE 0 END) has_complex_value_constraint,
					(CASE WHEN MAX(c_tablename)=MIN(c_tablename) THEN MAX(c_tablename) ELSE NULL END) panel_table,
					MIN(CASE WHEN concept_path_id IS NOT NULL THEN 1 ELSE 0 END) all_concept_paths,
					SUM(IsNull(c_totalnum,1000000)) estimated_count,
					COUNT(*) number_of_items
				FROM #Items
				GROUP BY panel_number
			) i
		WHERE p.panel_number = i.panel_number
	UPDATE #Panels
		SET number_of_constraints = has_modifier_constraint + has_date_constraint + has_multiple_occurrences + has_value_constraint

	------------------------------------------------------------------------------
	-- Return a fast exact count if possible
	------------------------------------------------------------------------------

	IF (@UseCQ2Tables = 1) AND (@DebugEnableEstimatedCountAsActual = 1)
	BEGIN
		SELECT @UseEstimatedCountAsActual = 0
		SELECT @UseEstimatedCountAsActual = 1
			FROM #Panels
			WHERE all_concept_paths = 1 AND number_of_constraints = 0 AND invert = 0
				AND number_of_items=1
				AND (SELECT COUNT(*) FROM #Panels) = 1
				AND (@ReturnPatientList = 0 AND @ReturnEncounterList = 0)
		IF (@UseEstimatedCountAsActual = 1)
		BEGIN
			INSERT INTO #GlobalQueryCounts (query_master_id, num_patients, num_encounters, num_instances, num_facts, sketch_e, sketch_n, sketch_q)
				SELECT @QueryMasterID, estimated_count, null, null, null, null, null, null
				FROM #Panels t
			RETURN;
		END
	END

	------------------------------------------------------------------------------
	-- Return a fast sketch estimate if possible
	------------------------------------------------------------------------------

	IF (@UseCQ2SketchTables = 1) AND (@QueryMethod IN ('MINHASH8','MINHASH15')) AND (@DebugEnableEstimatedCountAsActual = 1)
	BEGIN
		SELECT @UseEstimatedCountAsActual = 0
		-- Make sure this is a Boolean-only query (no constraints)
		SELECT @UseEstimatedCountAsActual =	MIN(CASE WHEN all_concept_paths = 1 AND number_of_constraints = 0 AND invert = 0 THEN 1 ELSE 0 END)
			FROM #Panels
			WHERE (@ReturnPatientList = 0 AND @ReturnEncounterList = 0)
		-- Don't use this method with MINHASH15 if more than one panel (just ORs, no ANDs)
		SELECT @UseEstimatedCountAsActual = 0
			WHERE @QueryMethod='MINHASH15'
				AND (SELECT COUNT(*) FROM #Panels)>1
		-- Run the estimate
		IF (@UseEstimatedCountAsActual = 1)
		BEGIN
			-- Calculate a 15x256 sketch estimate
			select @SketchPanelE = HIVE.fnSketchEstimate(sV15, N15, J15, 32768, 1), @SketchPanelN = N15, @SketchPanelQ = J15
				from (
					select sum(sV15) sV15, sum(N15) N15, sum(J15) J15
					from (
						select B,
							cast(0 as float)+isnull(V0,0)+isnull(V1,0)+isnull(V2,0)+isnull(V3,0)+isnull(V4,0)+isnull(V5,0)+isnull(V6,0)+isnull(V7,0)+isnull(V8,0)+isnull(V9,0)+isnull(V10,0)+isnull(V11,0)+isnull(V12,0)+isnull(V13,0)+isnull(V14,0)+isnull(V15,0)+isnull(V16,0)+isnull(V17,0)+isnull(V18,0)+isnull(V19,0)+isnull(V20,0)+isnull(V21,0)+isnull(V22,0)+isnull(V23,0)+isnull(V24,0)+isnull(V25,0)+isnull(V26,0)+isnull(V27,0)+isnull(V28,0)+isnull(V29,0)+isnull(V30,0)+isnull(V31,0)+isnull(V32,0)+isnull(V33,0)+isnull(V34,0)+isnull(V35,0)+isnull(V36,0)+isnull(V37,0)+isnull(V38,0)+isnull(V39,0)+isnull(V40,0)+isnull(V41,0)+isnull(V42,0)+isnull(V43,0)+isnull(V44,0)+isnull(V45,0)+isnull(V46,0)+isnull(V47,0)+isnull(V48,0)+isnull(V49,0)+isnull(V50,0)+isnull(V51,0)+isnull(V52,0)+isnull(V53,0)+isnull(V54,0)+isnull(V55,0)+isnull(V56,0)+isnull(V57,0)+isnull(V58,0)+isnull(V59,0)+isnull(V60,0)+isnull(V61,0)+isnull(V62,0)+isnull(V63,0)+isnull(V64,0)+isnull(V65,0)+isnull(V66,0)+isnull(V67,0)+isnull(V68,0)+isnull(V69,0)+isnull(V70,0)+isnull(V71,0)+isnull(V72,0)+isnull(V73,0)+isnull(V74,0)+isnull(V75,0)+isnull(V76,0)+isnull(V77,0)+isnull(V78,0)+isnull(V79,0)+isnull(V80,0)+isnull(V81,0)+isnull(V82,0)+isnull(V83,0)+isnull(V84,0)+isnull(V85,0)+isnull(V86,0)+isnull(V87,0)+isnull(V88,0)+isnull(V89,0)+isnull(V90,0)+isnull(V91,0)+isnull(V92,0)+isnull(V93,0)+isnull(V94,0)+isnull(V95,0)+isnull(V96,0)+isnull(V97,0)+isnull(V98,0)+isnull(V99,0)+isnull(V100,0)+isnull(V101,0)+isnull(V102,0)+isnull(V103,0)+isnull(V104,0)+isnull(V105,0)+isnull(V106,0)+isnull(V107,0)+isnull(V108,0)+isnull(V109,0)+isnull(V110,0)+isnull(V111,0)+isnull(V112,0)+isnull(V113,0)+isnull(V114,0)+isnull(V115,0)+isnull(V116,0)+isnull(V117,0)+isnull(V118,0)+isnull(V119,0)+isnull(V120,0)+isnull(V121,0)+isnull(V122,0)+isnull(V123,0)+isnull(V124,0)+isnull(V125,0)+isnull(V126,0)+isnull(V127,0)+isnull(V128,0)+isnull(V129,0)+isnull(V130,0)+isnull(V131,0)+isnull(V132,0)+isnull(V133,0)+isnull(V134,0)+isnull(V135,0)+isnull(V136,0)+isnull(V137,0)+isnull(V138,0)+isnull(V139,0)+isnull(V140,0)+isnull(V141,0)+isnull(V142,0)+isnull(V143,0)+isnull(V144,0)+isnull(V145,0)+isnull(V146,0)+isnull(V147,0)+isnull(V148,0)+isnull(V149,0)+isnull(V150,0)+isnull(V151,0)+isnull(V152,0)+isnull(V153,0)+isnull(V154,0)+isnull(V155,0)+isnull(V156,0)+isnull(V157,0)+isnull(V158,0)+isnull(V159,0)+isnull(V160,0)+isnull(V161,0)+isnull(V162,0)+isnull(V163,0)+isnull(V164,0)+isnull(V165,0)+isnull(V166,0)+isnull(V167,0)+isnull(V168,0)+isnull(V169,0)+isnull(V170,0)+isnull(V171,0)+isnull(V172,0)+isnull(V173,0)+isnull(V174,0)+isnull(V175,0)+isnull(V176,0)+isnull(V177,0)+isnull(V178,0)+isnull(V179,0)+isnull(V180,0)+isnull(V181,0)+isnull(V182,0)+isnull(V183,0)+isnull(V184,0)+isnull(V185,0)+isnull(V186,0)+isnull(V187,0)+isnull(V188,0)+isnull(V189,0)+isnull(V190,0)+isnull(V191,0)+isnull(V192,0)+isnull(V193,0)+isnull(V194,0)+isnull(V195,0)+isnull(V196,0)+isnull(V197,0)+isnull(V198,0)+isnull(V199,0)+isnull(V200,0)+isnull(V201,0)+isnull(V202,0)+isnull(V203,0)+isnull(V204,0)+isnull(V205,0)+isnull(V206,0)+isnull(V207,0)+isnull(V208,0)+isnull(V209,0)+isnull(V210,0)+isnull(V211,0)+isnull(V212,0)+isnull(V213,0)+isnull(V214,0)+isnull(V215,0)+isnull(V216,0)+isnull(V217,0)+isnull(V218,0)+isnull(V219,0)+isnull(V220,0)+isnull(V221,0)+isnull(V222,0)+isnull(V223,0)+isnull(V224,0)+isnull(V225,0)+isnull(V226,0)+isnull(V227,0)+isnull(V228,0)+isnull(V229,0)+isnull(V230,0)+isnull(V231,0)+isnull(V232,0)+isnull(V233,0)+isnull(V234,0)+isnull(V235,0)+isnull(V236,0)+isnull(V237,0)+isnull(V238,0)+isnull(V239,0)+isnull(V240,0)+isnull(V241,0)+isnull(V242,0)+isnull(V243,0)+isnull(V244,0)+isnull(V245,0)+isnull(V246,0)+isnull(V247,0)+isnull(V248,0)+isnull(V249,0)+isnull(V250,0)+isnull(V251,0)+isnull(V252,0)+isnull(V253,0)+isnull(V254,0)+isnull(V255,0) sV15,
							(case when V0 is null then 0 else 1 end)+(case when V1 is null then 0 else 1 end)+(case when V2 is null then 0 else 1 end)+(case when V3 is null then 0 else 1 end)+(case when V4 is null then 0 else 1 end)+(case when V5 is null then 0 else 1 end)+(case when V6 is null then 0 else 1 end)+(case when V7 is null then 0 else 1 end)+(case when V8 is null then 0 else 1 end)+(case when V9 is null then 0 else 1 end)+(case when V10 is null then 0 else 1 end)+(case when V11 is null then 0 else 1 end)+(case when V12 is null then 0 else 1 end)+(case when V13 is null then 0 else 1 end)+(case when V14 is null then 0 else 1 end)+(case when V15 is null then 0 else 1 end)+(case when V16 is null then 0 else 1 end)+(case when V17 is null then 0 else 1 end)+(case when V18 is null then 0 else 1 end)+(case when V19 is null then 0 else 1 end)+(case when V20 is null then 0 else 1 end)+(case when V21 is null then 0 else 1 end)+(case when V22 is null then 0 else 1 end)+(case when V23 is null then 0 else 1 end)+(case when V24 is null then 0 else 1 end)+(case when V25 is null then 0 else 1 end)+(case when V26 is null then 0 else 1 end)+(case when V27 is null then 0 else 1 end)+(case when V28 is null then 0 else 1 end)+(case when V29 is null then 0 else 1 end)+(case when V30 is null then 0 else 1 end)+(case when V31 is null then 0 else 1 end)+(case when V32 is null then 0 else 1 end)+(case when V33 is null then 0 else 1 end)+(case when V34 is null then 0 else 1 end)+(case when V35 is null then 0 else 1 end)+(case when V36 is null then 0 else 1 end)+(case when V37 is null then 0 else 1 end)+(case when V38 is null then 0 else 1 end)+(case when V39 is null then 0 else 1 end)+(case when V40 is null then 0 else 1 end)+(case when V41 is null then 0 else 1 end)+(case when V42 is null then 0 else 1 end)+(case when V43 is null then 0 else 1 end)+(case when V44 is null then 0 else 1 end)+(case when V45 is null then 0 else 1 end)+(case when V46 is null then 0 else 1 end)+(case when V47 is null then 0 else 1 end)+(case when V48 is null then 0 else 1 end)+(case when V49 is null then 0 else 1 end)+(case when V50 is null then 0 else 1 end)+(case when V51 is null then 0 else 1 end)+(case when V52 is null then 0 else 1 end)+(case when V53 is null then 0 else 1 end)+(case when V54 is null then 0 else 1 end)+(case when V55 is null then 0 else 1 end)+(case when V56 is null then 0 else 1 end)+(case when V57 is null then 0 else 1 end)+(case when V58 is null then 0 else 1 end)+(case when V59 is null then 0 else 1 end)+(case when V60 is null then 0 else 1 end)+(case when V61 is null then 0 else 1 end)+(case when V62 is null then 0 else 1 end)+(case when V63 is null then 0 else 1 end)+(case when V64 is null then 0 else 1 end)+(case when V65 is null then 0 else 1 end)+(case when V66 is null then 0 else 1 end)+(case when V67 is null then 0 else 1 end)+(case when V68 is null then 0 else 1 end)+(case when V69 is null then 0 else 1 end)+(case when V70 is null then 0 else 1 end)+(case when V71 is null then 0 else 1 end)+(case when V72 is null then 0 else 1 end)+(case when V73 is null then 0 else 1 end)+(case when V74 is null then 0 else 1 end)+(case when V75 is null then 0 else 1 end)+(case when V76 is null then 0 else 1 end)+(case when V77 is null then 0 else 1 end)+(case when V78 is null then 0 else 1 end)+(case when V79 is null then 0 else 1 end)+(case when V80 is null then 0 else 1 end)+(case when V81 is null then 0 else 1 end)+(case when V82 is null then 0 else 1 end)+(case when V83 is null then 0 else 1 end)+(case when V84 is null then 0 else 1 end)+(case when V85 is null then 0 else 1 end)+(case when V86 is null then 0 else 1 end)+(case when V87 is null then 0 else 1 end)+(case when V88 is null then 0 else 1 end)+(case when V89 is null then 0 else 1 end)+(case when V90 is null then 0 else 1 end)+(case when V91 is null then 0 else 1 end)+(case when V92 is null then 0 else 1 end)+(case when V93 is null then 0 else 1 end)+(case when V94 is null then 0 else 1 end)+(case when V95 is null then 0 else 1 end)+(case when V96 is null then 0 else 1 end)+(case when V97 is null then 0 else 1 end)+(case when V98 is null then 0 else 1 end)+(case when V99 is null then 0 else 1 end)+(case when V100 is null then 0 else 1 end)+(case when V101 is null then 0 else 1 end)+(case when V102 is null then 0 else 1 end)+(case when V103 is null then 0 else 1 end)+(case when V104 is null then 0 else 1 end)+(case when V105 is null then 0 else 1 end)+(case when V106 is null then 0 else 1 end)+(case when V107 is null then 0 else 1 end)+(case when V108 is null then 0 else 1 end)+(case when V109 is null then 0 else 1 end)+(case when V110 is null then 0 else 1 end)+(case when V111 is null then 0 else 1 end)+(case when V112 is null then 0 else 1 end)+(case when V113 is null then 0 else 1 end)+(case when V114 is null then 0 else 1 end)+(case when V115 is null then 0 else 1 end)+(case when V116 is null then 0 else 1 end)+(case when V117 is null then 0 else 1 end)+(case when V118 is null then 0 else 1 end)+(case when V119 is null then 0 else 1 end)+(case when V120 is null then 0 else 1 end)+(case when V121 is null then 0 else 1 end)+(case when V122 is null then 0 else 1 end)+(case when V123 is null then 0 else 1 end)+(case when V124 is null then 0 else 1 end)+(case when V125 is null then 0 else 1 end)+(case when V126 is null then 0 else 1 end)+(case when V127 is null then 0 else 1 end)+(case when V128 is null then 0 else 1 end)+(case when V129 is null then 0 else 1 end)+(case when V130 is null then 0 else 1 end)+(case when V131 is null then 0 else 1 end)+(case when V132 is null then 0 else 1 end)+(case when V133 is null then 0 else 1 end)+(case when V134 is null then 0 else 1 end)+(case when V135 is null then 0 else 1 end)+(case when V136 is null then 0 else 1 end)+(case when V137 is null then 0 else 1 end)+(case when V138 is null then 0 else 1 end)+(case when V139 is null then 0 else 1 end)+(case when V140 is null then 0 else 1 end)+(case when V141 is null then 0 else 1 end)+(case when V142 is null then 0 else 1 end)+(case when V143 is null then 0 else 1 end)+(case when V144 is null then 0 else 1 end)+(case when V145 is null then 0 else 1 end)+(case when V146 is null then 0 else 1 end)+(case when V147 is null then 0 else 1 end)+(case when V148 is null then 0 else 1 end)+(case when V149 is null then 0 else 1 end)+(case when V150 is null then 0 else 1 end)+(case when V151 is null then 0 else 1 end)+(case when V152 is null then 0 else 1 end)+(case when V153 is null then 0 else 1 end)+(case when V154 is null then 0 else 1 end)+(case when V155 is null then 0 else 1 end)+(case when V156 is null then 0 else 1 end)+(case when V157 is null then 0 else 1 end)+(case when V158 is null then 0 else 1 end)+(case when V159 is null then 0 else 1 end)+(case when V160 is null then 0 else 1 end)+(case when V161 is null then 0 else 1 end)+(case when V162 is null then 0 else 1 end)+(case when V163 is null then 0 else 1 end)+(case when V164 is null then 0 else 1 end)+(case when V165 is null then 0 else 1 end)+(case when V166 is null then 0 else 1 end)+(case when V167 is null then 0 else 1 end)+(case when V168 is null then 0 else 1 end)+(case when V169 is null then 0 else 1 end)+(case when V170 is null then 0 else 1 end)+(case when V171 is null then 0 else 1 end)+(case when V172 is null then 0 else 1 end)+(case when V173 is null then 0 else 1 end)+(case when V174 is null then 0 else 1 end)+(case when V175 is null then 0 else 1 end)+(case when V176 is null then 0 else 1 end)+(case when V177 is null then 0 else 1 end)+(case when V178 is null then 0 else 1 end)+(case when V179 is null then 0 else 1 end)+(case when V180 is null then 0 else 1 end)+(case when V181 is null then 0 else 1 end)+(case when V182 is null then 0 else 1 end)+(case when V183 is null then 0 else 1 end)+(case when V184 is null then 0 else 1 end)+(case when V185 is null then 0 else 1 end)+(case when V186 is null then 0 else 1 end)+(case when V187 is null then 0 else 1 end)+(case when V188 is null then 0 else 1 end)+(case when V189 is null then 0 else 1 end)+(case when V190 is null then 0 else 1 end)+(case when V191 is null then 0 else 1 end)+(case when V192 is null then 0 else 1 end)+(case when V193 is null then 0 else 1 end)+(case when V194 is null then 0 else 1 end)+(case when V195 is null then 0 else 1 end)+(case when V196 is null then 0 else 1 end)+(case when V197 is null then 0 else 1 end)+(case when V198 is null then 0 else 1 end)+(case when V199 is null then 0 else 1 end)+(case when V200 is null then 0 else 1 end)+(case when V201 is null then 0 else 1 end)+(case when V202 is null then 0 else 1 end)+(case when V203 is null then 0 else 1 end)+(case when V204 is null then 0 else 1 end)+(case when V205 is null then 0 else 1 end)+(case when V206 is null then 0 else 1 end)+(case when V207 is null then 0 else 1 end)+(case when V208 is null then 0 else 1 end)+(case when V209 is null then 0 else 1 end)+(case when V210 is null then 0 else 1 end)+(case when V211 is null then 0 else 1 end)+(case when V212 is null then 0 else 1 end)+(case when V213 is null then 0 else 1 end)+(case when V214 is null then 0 else 1 end)+(case when V215 is null then 0 else 1 end)+(case when V216 is null then 0 else 1 end)+(case when V217 is null then 0 else 1 end)+(case when V218 is null then 0 else 1 end)+(case when V219 is null then 0 else 1 end)+(case when V220 is null then 0 else 1 end)+(case when V221 is null then 0 else 1 end)+(case when V222 is null then 0 else 1 end)+(case when V223 is null then 0 else 1 end)+(case when V224 is null then 0 else 1 end)+(case when V225 is null then 0 else 1 end)+(case when V226 is null then 0 else 1 end)+(case when V227 is null then 0 else 1 end)+(case when V228 is null then 0 else 1 end)+(case when V229 is null then 0 else 1 end)+(case when V230 is null then 0 else 1 end)+(case when V231 is null then 0 else 1 end)+(case when V232 is null then 0 else 1 end)+(case when V233 is null then 0 else 1 end)+(case when V234 is null then 0 else 1 end)+(case when V235 is null then 0 else 1 end)+(case when V236 is null then 0 else 1 end)+(case when V237 is null then 0 else 1 end)+(case when V238 is null then 0 else 1 end)+(case when V239 is null then 0 else 1 end)+(case when V240 is null then 0 else 1 end)+(case when V241 is null then 0 else 1 end)+(case when V242 is null then 0 else 1 end)+(case when V243 is null then 0 else 1 end)+(case when V244 is null then 0 else 1 end)+(case when V245 is null then 0 else 1 end)+(case when V246 is null then 0 else 1 end)+(case when V247 is null then 0 else 1 end)+(case when V248 is null then 0 else 1 end)+(case when V249 is null then 0 else 1 end)+(case when V250 is null then 0 else 1 end)+(case when V251 is null then 0 else 1 end)+(case when V252 is null then 0 else 1 end)+(case when V253 is null then 0 else 1 end)+(case when V254 is null then 0 else 1 end)+(case when V255 is null then 0 else 1 end) N15,
							(case when V0=W0 and N0=n then 1 else 0 end)+(case when V1=W1 and N1=n then 1 else 0 end)+(case when V2=W2 and N2=n then 1 else 0 end)+(case when V3=W3 and N3=n then 1 else 0 end)+(case when V4=W4 and N4=n then 1 else 0 end)+(case when V5=W5 and N5=n then 1 else 0 end)+(case when V6=W6 and N6=n then 1 else 0 end)+(case when V7=W7 and N7=n then 1 else 0 end)+(case when V8=W8 and N8=n then 1 else 0 end)+(case when V9=W9 and N9=n then 1 else 0 end)+(case when V10=W10 and N10=n then 1 else 0 end)+(case when V11=W11 and N11=n then 1 else 0 end)+(case when V12=W12 and N12=n then 1 else 0 end)+(case when V13=W13 and N13=n then 1 else 0 end)+(case when V14=W14 and N14=n then 1 else 0 end)+(case when V15=W15 and N15=n then 1 else 0 end)+(case when V16=W16 and N16=n then 1 else 0 end)+(case when V17=W17 and N17=n then 1 else 0 end)+(case when V18=W18 and N18=n then 1 else 0 end)+(case when V19=W19 and N19=n then 1 else 0 end)+(case when V20=W20 and N20=n then 1 else 0 end)+(case when V21=W21 and N21=n then 1 else 0 end)+(case when V22=W22 and N22=n then 1 else 0 end)+(case when V23=W23 and N23=n then 1 else 0 end)+(case when V24=W24 and N24=n then 1 else 0 end)+(case when V25=W25 and N25=n then 1 else 0 end)+(case when V26=W26 and N26=n then 1 else 0 end)+(case when V27=W27 and N27=n then 1 else 0 end)+(case when V28=W28 and N28=n then 1 else 0 end)+(case when V29=W29 and N29=n then 1 else 0 end)+(case when V30=W30 and N30=n then 1 else 0 end)+(case when V31=W31 and N31=n then 1 else 0 end)+(case when V32=W32 and N32=n then 1 else 0 end)+(case when V33=W33 and N33=n then 1 else 0 end)+(case when V34=W34 and N34=n then 1 else 0 end)+(case when V35=W35 and N35=n then 1 else 0 end)+(case when V36=W36 and N36=n then 1 else 0 end)+(case when V37=W37 and N37=n then 1 else 0 end)+(case when V38=W38 and N38=n then 1 else 0 end)+(case when V39=W39 and N39=n then 1 else 0 end)+(case when V40=W40 and N40=n then 1 else 0 end)+(case when V41=W41 and N41=n then 1 else 0 end)+(case when V42=W42 and N42=n then 1 else 0 end)+(case when V43=W43 and N43=n then 1 else 0 end)+(case when V44=W44 and N44=n then 1 else 0 end)+(case when V45=W45 and N45=n then 1 else 0 end)+(case when V46=W46 and N46=n then 1 else 0 end)+(case when V47=W47 and N47=n then 1 else 0 end)+(case when V48=W48 and N48=n then 1 else 0 end)+(case when V49=W49 and N49=n then 1 else 0 end)+(case when V50=W50 and N50=n then 1 else 0 end)+(case when V51=W51 and N51=n then 1 else 0 end)+(case when V52=W52 and N52=n then 1 else 0 end)+(case when V53=W53 and N53=n then 1 else 0 end)+(case when V54=W54 and N54=n then 1 else 0 end)+(case when V55=W55 and N55=n then 1 else 0 end)+(case when V56=W56 and N56=n then 1 else 0 end)+(case when V57=W57 and N57=n then 1 else 0 end)+(case when V58=W58 and N58=n then 1 else 0 end)+(case when V59=W59 and N59=n then 1 else 0 end)+(case when V60=W60 and N60=n then 1 else 0 end)+(case when V61=W61 and N61=n then 1 else 0 end)+(case when V62=W62 and N62=n then 1 else 0 end)+(case when V63=W63 and N63=n then 1 else 0 end)+(case when V64=W64 and N64=n then 1 else 0 end)+(case when V65=W65 and N65=n then 1 else 0 end)+(case when V66=W66 and N66=n then 1 else 0 end)+(case when V67=W67 and N67=n then 1 else 0 end)+(case when V68=W68 and N68=n then 1 else 0 end)+(case when V69=W69 and N69=n then 1 else 0 end)+(case when V70=W70 and N70=n then 1 else 0 end)+(case when V71=W71 and N71=n then 1 else 0 end)+(case when V72=W72 and N72=n then 1 else 0 end)+(case when V73=W73 and N73=n then 1 else 0 end)+(case when V74=W74 and N74=n then 1 else 0 end)+(case when V75=W75 and N75=n then 1 else 0 end)+(case when V76=W76 and N76=n then 1 else 0 end)+(case when V77=W77 and N77=n then 1 else 0 end)+(case when V78=W78 and N78=n then 1 else 0 end)+(case when V79=W79 and N79=n then 1 else 0 end)+(case when V80=W80 and N80=n then 1 else 0 end)+(case when V81=W81 and N81=n then 1 else 0 end)+(case when V82=W82 and N82=n then 1 else 0 end)+(case when V83=W83 and N83=n then 1 else 0 end)+(case when V84=W84 and N84=n then 1 else 0 end)+(case when V85=W85 and N85=n then 1 else 0 end)+(case when V86=W86 and N86=n then 1 else 0 end)+(case when V87=W87 and N87=n then 1 else 0 end)+(case when V88=W88 and N88=n then 1 else 0 end)+(case when V89=W89 and N89=n then 1 else 0 end)+(case when V90=W90 and N90=n then 1 else 0 end)+(case when V91=W91 and N91=n then 1 else 0 end)+(case when V92=W92 and N92=n then 1 else 0 end)+(case when V93=W93 and N93=n then 1 else 0 end)+(case when V94=W94 and N94=n then 1 else 0 end)+(case when V95=W95 and N95=n then 1 else 0 end)+(case when V96=W96 and N96=n then 1 else 0 end)+(case when V97=W97 and N97=n then 1 else 0 end)+(case when V98=W98 and N98=n then 1 else 0 end)+(case when V99=W99 and N99=n then 1 else 0 end)+(case when V100=W100 and N100=n then 1 else 0 end)+(case when V101=W101 and N101=n then 1 else 0 end)+(case when V102=W102 and N102=n then 1 else 0 end)+(case when V103=W103 and N103=n then 1 else 0 end)+(case when V104=W104 and N104=n then 1 else 0 end)+(case when V105=W105 and N105=n then 1 else 0 end)+(case when V106=W106 and N106=n then 1 else 0 end)+(case when V107=W107 and N107=n then 1 else 0 end)+(case when V108=W108 and N108=n then 1 else 0 end)+(case when V109=W109 and N109=n then 1 else 0 end)+(case when V110=W110 and N110=n then 1 else 0 end)+(case when V111=W111 and N111=n then 1 else 0 end)+(case when V112=W112 and N112=n then 1 else 0 end)+(case when V113=W113 and N113=n then 1 else 0 end)+(case when V114=W114 and N114=n then 1 else 0 end)+(case when V115=W115 and N115=n then 1 else 0 end)+(case when V116=W116 and N116=n then 1 else 0 end)+(case when V117=W117 and N117=n then 1 else 0 end)+(case when V118=W118 and N118=n then 1 else 0 end)+(case when V119=W119 and N119=n then 1 else 0 end)+(case when V120=W120 and N120=n then 1 else 0 end)+(case when V121=W121 and N121=n then 1 else 0 end)+(case when V122=W122 and N122=n then 1 else 0 end)+(case when V123=W123 and N123=n then 1 else 0 end)+(case when V124=W124 and N124=n then 1 else 0 end)+(case when V125=W125 and N125=n then 1 else 0 end)+(case when V126=W126 and N126=n then 1 else 0 end)+(case when V127=W127 and N127=n then 1 else 0 end)+(case when V128=W128 and N128=n then 1 else 0 end)+(case when V129=W129 and N129=n then 1 else 0 end)+(case when V130=W130 and N130=n then 1 else 0 end)+(case when V131=W131 and N131=n then 1 else 0 end)+(case when V132=W132 and N132=n then 1 else 0 end)+(case when V133=W133 and N133=n then 1 else 0 end)+(case when V134=W134 and N134=n then 1 else 0 end)+(case when V135=W135 and N135=n then 1 else 0 end)+(case when V136=W136 and N136=n then 1 else 0 end)+(case when V137=W137 and N137=n then 1 else 0 end)+(case when V138=W138 and N138=n then 1 else 0 end)+(case when V139=W139 and N139=n then 1 else 0 end)+(case when V140=W140 and N140=n then 1 else 0 end)+(case when V141=W141 and N141=n then 1 else 0 end)+(case when V142=W142 and N142=n then 1 else 0 end)+(case when V143=W143 and N143=n then 1 else 0 end)+(case when V144=W144 and N144=n then 1 else 0 end)+(case when V145=W145 and N145=n then 1 else 0 end)+(case when V146=W146 and N146=n then 1 else 0 end)+(case when V147=W147 and N147=n then 1 else 0 end)+(case when V148=W148 and N148=n then 1 else 0 end)+(case when V149=W149 and N149=n then 1 else 0 end)+(case when V150=W150 and N150=n then 1 else 0 end)+(case when V151=W151 and N151=n then 1 else 0 end)+(case when V152=W152 and N152=n then 1 else 0 end)+(case when V153=W153 and N153=n then 1 else 0 end)+(case when V154=W154 and N154=n then 1 else 0 end)+(case when V155=W155 and N155=n then 1 else 0 end)+(case when V156=W156 and N156=n then 1 else 0 end)+(case when V157=W157 and N157=n then 1 else 0 end)+(case when V158=W158 and N158=n then 1 else 0 end)+(case when V159=W159 and N159=n then 1 else 0 end)+(case when V160=W160 and N160=n then 1 else 0 end)+(case when V161=W161 and N161=n then 1 else 0 end)+(case when V162=W162 and N162=n then 1 else 0 end)+(case when V163=W163 and N163=n then 1 else 0 end)+(case when V164=W164 and N164=n then 1 else 0 end)+(case when V165=W165 and N165=n then 1 else 0 end)+(case when V166=W166 and N166=n then 1 else 0 end)+(case when V167=W167 and N167=n then 1 else 0 end)+(case when V168=W168 and N168=n then 1 else 0 end)+(case when V169=W169 and N169=n then 1 else 0 end)+(case when V170=W170 and N170=n then 1 else 0 end)+(case when V171=W171 and N171=n then 1 else 0 end)+(case when V172=W172 and N172=n then 1 else 0 end)+(case when V173=W173 and N173=n then 1 else 0 end)+(case when V174=W174 and N174=n then 1 else 0 end)+(case when V175=W175 and N175=n then 1 else 0 end)+(case when V176=W176 and N176=n then 1 else 0 end)+(case when V177=W177 and N177=n then 1 else 0 end)+(case when V178=W178 and N178=n then 1 else 0 end)+(case when V179=W179 and N179=n then 1 else 0 end)+(case when V180=W180 and N180=n then 1 else 0 end)+(case when V181=W181 and N181=n then 1 else 0 end)+(case when V182=W182 and N182=n then 1 else 0 end)+(case when V183=W183 and N183=n then 1 else 0 end)+(case when V184=W184 and N184=n then 1 else 0 end)+(case when V185=W185 and N185=n then 1 else 0 end)+(case when V186=W186 and N186=n then 1 else 0 end)+(case when V187=W187 and N187=n then 1 else 0 end)+(case when V188=W188 and N188=n then 1 else 0 end)+(case when V189=W189 and N189=n then 1 else 0 end)+(case when V190=W190 and N190=n then 1 else 0 end)+(case when V191=W191 and N191=n then 1 else 0 end)+(case when V192=W192 and N192=n then 1 else 0 end)+(case when V193=W193 and N193=n then 1 else 0 end)+(case when V194=W194 and N194=n then 1 else 0 end)+(case when V195=W195 and N195=n then 1 else 0 end)+(case when V196=W196 and N196=n then 1 else 0 end)+(case when V197=W197 and N197=n then 1 else 0 end)+(case when V198=W198 and N198=n then 1 else 0 end)+(case when V199=W199 and N199=n then 1 else 0 end)+(case when V200=W200 and N200=n then 1 else 0 end)+(case when V201=W201 and N201=n then 1 else 0 end)+(case when V202=W202 and N202=n then 1 else 0 end)+(case when V203=W203 and N203=n then 1 else 0 end)+(case when V204=W204 and N204=n then 1 else 0 end)+(case when V205=W205 and N205=n then 1 else 0 end)+(case when V206=W206 and N206=n then 1 else 0 end)+(case when V207=W207 and N207=n then 1 else 0 end)+(case when V208=W208 and N208=n then 1 else 0 end)+(case when V209=W209 and N209=n then 1 else 0 end)+(case when V210=W210 and N210=n then 1 else 0 end)+(case when V211=W211 and N211=n then 1 else 0 end)+(case when V212=W212 and N212=n then 1 else 0 end)+(case when V213=W213 and N213=n then 1 else 0 end)+(case when V214=W214 and N214=n then 1 else 0 end)+(case when V215=W215 and N215=n then 1 else 0 end)+(case when V216=W216 and N216=n then 1 else 0 end)+(case when V217=W217 and N217=n then 1 else 0 end)+(case when V218=W218 and N218=n then 1 else 0 end)+(case when V219=W219 and N219=n then 1 else 0 end)+(case when V220=W220 and N220=n then 1 else 0 end)+(case when V221=W221 and N221=n then 1 else 0 end)+(case when V222=W222 and N222=n then 1 else 0 end)+(case when V223=W223 and N223=n then 1 else 0 end)+(case when V224=W224 and N224=n then 1 else 0 end)+(case when V225=W225 and N225=n then 1 else 0 end)+(case when V226=W226 and N226=n then 1 else 0 end)+(case when V227=W227 and N227=n then 1 else 0 end)+(case when V228=W228 and N228=n then 1 else 0 end)+(case when V229=W229 and N229=n then 1 else 0 end)+(case when V230=W230 and N230=n then 1 else 0 end)+(case when V231=W231 and N231=n then 1 else 0 end)+(case when V232=W232 and N232=n then 1 else 0 end)+(case when V233=W233 and N233=n then 1 else 0 end)+(case when V234=W234 and N234=n then 1 else 0 end)+(case when V235=W235 and N235=n then 1 else 0 end)+(case when V236=W236 and N236=n then 1 else 0 end)+(case when V237=W237 and N237=n then 1 else 0 end)+(case when V238=W238 and N238=n then 1 else 0 end)+(case when V239=W239 and N239=n then 1 else 0 end)+(case when V240=W240 and N240=n then 1 else 0 end)+(case when V241=W241 and N241=n then 1 else 0 end)+(case when V242=W242 and N242=n then 1 else 0 end)+(case when V243=W243 and N243=n then 1 else 0 end)+(case when V244=W244 and N244=n then 1 else 0 end)+(case when V245=W245 and N245=n then 1 else 0 end)+(case when V246=W246 and N246=n then 1 else 0 end)+(case when V247=W247 and N247=n then 1 else 0 end)+(case when V248=W248 and N248=n then 1 else 0 end)+(case when V249=W249 and N249=n then 1 else 0 end)+(case when V250=W250 and N250=n then 1 else 0 end)+(case when V251=W251 and N251=n then 1 else 0 end)+(case when V252=W252 and N252=n then 1 else 0 end)+(case when V253=W253 and N253=n then 1 else 0 end)+(case when V254=W254 and N254=n then 1 else 0 end)+(case when V255=W255 and N255=n then 1 else 0 end) J15
						from (
							select B,
								min(V0) V0, min(V1) V1, min(V2) V2, min(V3) V3, min(V4) V4, min(V5) V5, min(V6) V6, min(V7) V7, min(V8) V8, min(V9) V9, min(V10) V10, min(V11) V11, min(V12) V12, min(V13) V13, min(V14) V14, min(V15) V15, min(V16) V16, min(V17) V17, min(V18) V18, min(V19) V19, min(V20) V20, min(V21) V21, min(V22) V22, min(V23) V23, min(V24) V24, min(V25) V25, min(V26) V26, min(V27) V27, min(V28) V28, min(V29) V29, min(V30) V30, min(V31) V31, min(V32) V32, min(V33) V33, min(V34) V34, min(V35) V35, min(V36) V36, min(V37) V37, min(V38) V38, min(V39) V39, min(V40) V40, min(V41) V41, min(V42) V42, min(V43) V43, min(V44) V44, min(V45) V45, min(V46) V46, min(V47) V47, min(V48) V48, min(V49) V49, min(V50) V50, min(V51) V51, min(V52) V52, min(V53) V53, min(V54) V54, min(V55) V55, min(V56) V56, min(V57) V57, min(V58) V58, min(V59) V59, min(V60) V60, min(V61) V61, min(V62) V62, min(V63) V63, min(V64) V64, min(V65) V65, min(V66) V66, min(V67) V67, min(V68) V68, min(V69) V69, min(V70) V70, min(V71) V71, min(V72) V72, min(V73) V73, min(V74) V74, min(V75) V75, min(V76) V76, min(V77) V77, min(V78) V78, min(V79) V79, min(V80) V80, min(V81) V81, min(V82) V82, min(V83) V83, min(V84) V84, min(V85) V85, min(V86) V86, min(V87) V87, min(V88) V88, min(V89) V89, min(V90) V90, min(V91) V91, min(V92) V92, min(V93) V93, min(V94) V94, min(V95) V95, min(V96) V96, min(V97) V97, min(V98) V98, min(V99) V99, min(V100) V100, min(V101) V101, min(V102) V102, min(V103) V103, min(V104) V104, min(V105) V105, min(V106) V106, min(V107) V107, min(V108) V108, min(V109) V109, min(V110) V110, min(V111) V111, min(V112) V112, min(V113) V113, min(V114) V114, min(V115) V115, min(V116) V116, min(V117) V117, min(V118) V118, min(V119) V119, min(V120) V120, min(V121) V121, min(V122) V122, min(V123) V123, min(V124) V124, min(V125) V125, min(V126) V126, min(V127) V127, min(V128) V128, min(V129) V129, min(V130) V130, min(V131) V131, min(V132) V132, min(V133) V133, min(V134) V134, min(V135) V135, min(V136) V136, min(V137) V137, min(V138) V138, min(V139) V139, min(V140) V140, min(V141) V141, min(V142) V142, min(V143) V143, min(V144) V144, min(V145) V145, min(V146) V146, min(V147) V147, min(V148) V148, min(V149) V149, min(V150) V150, min(V151) V151, min(V152) V152, min(V153) V153, min(V154) V154, min(V155) V155, min(V156) V156, min(V157) V157, min(V158) V158, min(V159) V159, min(V160) V160, min(V161) V161, min(V162) V162, min(V163) V163, min(V164) V164, min(V165) V165, min(V166) V166, min(V167) V167, min(V168) V168, min(V169) V169, min(V170) V170, min(V171) V171, min(V172) V172, min(V173) V173, min(V174) V174, min(V175) V175, min(V176) V176, min(V177) V177, min(V178) V178, min(V179) V179, min(V180) V180, min(V181) V181, min(V182) V182, min(V183) V183, min(V184) V184, min(V185) V185, min(V186) V186, min(V187) V187, min(V188) V188, min(V189) V189, min(V190) V190, min(V191) V191, min(V192) V192, min(V193) V193, min(V194) V194, min(V195) V195, min(V196) V196, min(V197) V197, min(V198) V198, min(V199) V199, min(V200) V200, min(V201) V201, min(V202) V202, min(V203) V203, min(V204) V204, min(V205) V205, min(V206) V206, min(V207) V207, min(V208) V208, min(V209) V209, min(V210) V210, min(V211) V211, min(V212) V212, min(V213) V213, min(V214) V214, min(V215) V215, min(V216) V216, min(V217) V217, min(V218) V218, min(V219) V219, min(V220) V220, min(V221) V221, min(V222) V222, min(V223) V223, min(V224) V224, min(V225) V225, min(V226) V226, min(V227) V227, min(V228) V228, min(V229) V229, min(V230) V230, min(V231) V231, min(V232) V232, min(V233) V233, min(V234) V234, min(V235) V235, min(V236) V236, min(V237) V237, min(V238) V238, min(V239) V239, min(V240) V240, min(V241) V241, min(V242) V242, min(V243) V243, min(V244) V244, min(V245) V245, min(V246) V246, min(V247) V247, min(V248) V248, min(V249) V249, min(V250) V250, min(V251) V251, min(V252) V252, min(V253) V253, min(V254) V254, min(V255) V255,
								max(V0) W0, max(V1) W1, max(V2) W2, max(V3) W3, max(V4) W4, max(V5) W5, max(V6) W6, max(V7) W7, max(V8) W8, max(V9) W9, max(V10) W10, max(V11) W11, max(V12) W12, max(V13) W13, max(V14) W14, max(V15) W15, max(V16) W16, max(V17) W17, max(V18) W18, max(V19) W19, max(V20) W20, max(V21) W21, max(V22) W22, max(V23) W23, max(V24) W24, max(V25) W25, max(V26) W26, max(V27) W27, max(V28) W28, max(V29) W29, max(V30) W30, max(V31) W31, max(V32) W32, max(V33) W33, max(V34) W34, max(V35) W35, max(V36) W36, max(V37) W37, max(V38) W38, max(V39) W39, max(V40) W40, max(V41) W41, max(V42) W42, max(V43) W43, max(V44) W44, max(V45) W45, max(V46) W46, max(V47) W47, max(V48) W48, max(V49) W49, max(V50) W50, max(V51) W51, max(V52) W52, max(V53) W53, max(V54) W54, max(V55) W55, max(V56) W56, max(V57) W57, max(V58) W58, max(V59) W59, max(V60) W60, max(V61) W61, max(V62) W62, max(V63) W63, max(V64) W64, max(V65) W65, max(V66) W66, max(V67) W67, max(V68) W68, max(V69) W69, max(V70) W70, max(V71) W71, max(V72) W72, max(V73) W73, max(V74) W74, max(V75) W75, max(V76) W76, max(V77) W77, max(V78) W78, max(V79) W79, max(V80) W80, max(V81) W81, max(V82) W82, max(V83) W83, max(V84) W84, max(V85) W85, max(V86) W86, max(V87) W87, max(V88) W88, max(V89) W89, max(V90) W90, max(V91) W91, max(V92) W92, max(V93) W93, max(V94) W94, max(V95) W95, max(V96) W96, max(V97) W97, max(V98) W98, max(V99) W99, max(V100) W100, max(V101) W101, max(V102) W102, max(V103) W103, max(V104) W104, max(V105) W105, max(V106) W106, max(V107) W107, max(V108) W108, max(V109) W109, max(V110) W110, max(V111) W111, max(V112) W112, max(V113) W113, max(V114) W114, max(V115) W115, max(V116) W116, max(V117) W117, max(V118) W118, max(V119) W119, max(V120) W120, max(V121) W121, max(V122) W122, max(V123) W123, max(V124) W124, max(V125) W125, max(V126) W126, max(V127) W127, max(V128) W128, max(V129) W129, max(V130) W130, max(V131) W131, max(V132) W132, max(V133) W133, max(V134) W134, max(V135) W135, max(V136) W136, max(V137) W137, max(V138) W138, max(V139) W139, max(V140) W140, max(V141) W141, max(V142) W142, max(V143) W143, max(V144) W144, max(V145) W145, max(V146) W146, max(V147) W147, max(V148) W148, max(V149) W149, max(V150) W150, max(V151) W151, max(V152) W152, max(V153) W153, max(V154) W154, max(V155) W155, max(V156) W156, max(V157) W157, max(V158) W158, max(V159) W159, max(V160) W160, max(V161) W161, max(V162) W162, max(V163) W163, max(V164) W164, max(V165) W165, max(V166) W166, max(V167) W167, max(V168) W168, max(V169) W169, max(V170) W170, max(V171) W171, max(V172) W172, max(V173) W173, max(V174) W174, max(V175) W175, max(V176) W176, max(V177) W177, max(V178) W178, max(V179) W179, max(V180) W180, max(V181) W181, max(V182) W182, max(V183) W183, max(V184) W184, max(V185) W185, max(V186) W186, max(V187) W187, max(V188) W188, max(V189) W189, max(V190) W190, max(V191) W191, max(V192) W192, max(V193) W193, max(V194) W194, max(V195) W195, max(V196) W196, max(V197) W197, max(V198) W198, max(V199) W199, max(V200) W200, max(V201) W201, max(V202) W202, max(V203) W203, max(V204) W204, max(V205) W205, max(V206) W206, max(V207) W207, max(V208) W208, max(V209) W209, max(V210) W210, max(V211) W211, max(V212) W212, max(V213) W213, max(V214) W214, max(V215) W215, max(V216) W216, max(V217) W217, max(V218) W218, max(V219) W219, max(V220) W220, max(V221) W221, max(V222) W222, max(V223) W223, max(V224) W224, max(V225) W225, max(V226) W226, max(V227) W227, max(V228) W228, max(V229) W229, max(V230) W230, max(V231) W231, max(V232) W232, max(V233) W233, max(V234) W234, max(V235) W235, max(V236) W236, max(V237) W237, max(V238) W238, max(V239) W239, max(V240) W240, max(V241) W241, max(V242) W242, max(V243) W243, max(V244) W244, max(V245) W245, max(V246) W246, max(V247) W247, max(V248) W248, max(V249) W249, max(V250) W250, max(V251) W251, max(V252) W252, max(V253) W253, max(V254) W254, max(V255) W255,
								count(V0) N0, count(V1) N1, count(V2) N2, count(V3) N3, count(V4) N4, count(V5) N5, count(V6) N6, count(V7) N7, count(V8) N8, count(V9) N9, count(V10) N10, count(V11) N11, count(V12) N12, count(V13) N13, count(V14) N14, count(V15) N15, count(V16) N16, count(V17) N17, count(V18) N18, count(V19) N19, count(V20) N20, count(V21) N21, count(V22) N22, count(V23) N23, count(V24) N24, count(V25) N25, count(V26) N26, count(V27) N27, count(V28) N28, count(V29) N29, count(V30) N30, count(V31) N31, count(V32) N32, count(V33) N33, count(V34) N34, count(V35) N35, count(V36) N36, count(V37) N37, count(V38) N38, count(V39) N39, count(V40) N40, count(V41) N41, count(V42) N42, count(V43) N43, count(V44) N44, count(V45) N45, count(V46) N46, count(V47) N47, count(V48) N48, count(V49) N49, count(V50) N50, count(V51) N51, count(V52) N52, count(V53) N53, count(V54) N54, count(V55) N55, count(V56) N56, count(V57) N57, count(V58) N58, count(V59) N59, count(V60) N60, count(V61) N61, count(V62) N62, count(V63) N63, count(V64) N64, count(V65) N65, count(V66) N66, count(V67) N67, count(V68) N68, count(V69) N69, count(V70) N70, count(V71) N71, count(V72) N72, count(V73) N73, count(V74) N74, count(V75) N75, count(V76) N76, count(V77) N77, count(V78) N78, count(V79) N79, count(V80) N80, count(V81) N81, count(V82) N82, count(V83) N83, count(V84) N84, count(V85) N85, count(V86) N86, count(V87) N87, count(V88) N88, count(V89) N89, count(V90) N90, count(V91) N91, count(V92) N92, count(V93) N93, count(V94) N94, count(V95) N95, count(V96) N96, count(V97) N97, count(V98) N98, count(V99) N99, count(V100) N100, count(V101) N101, count(V102) N102, count(V103) N103, count(V104) N104, count(V105) N105, count(V106) N106, count(V107) N107, count(V108) N108, count(V109) N109, count(V110) N110, count(V111) N111, count(V112) N112, count(V113) N113, count(V114) N114, count(V115) N115, count(V116) N116, count(V117) N117, count(V118) N118, count(V119) N119, count(V120) N120, count(V121) N121, count(V122) N122, count(V123) N123, count(V124) N124, count(V125) N125, count(V126) N126, count(V127) N127, count(V128) N128, count(V129) N129, count(V130) N130, count(V131) N131, count(V132) N132, count(V133) N133, count(V134) N134, count(V135) N135, count(V136) N136, count(V137) N137, count(V138) N138, count(V139) N139, count(V140) N140, count(V141) N141, count(V142) N142, count(V143) N143, count(V144) N144, count(V145) N145, count(V146) N146, count(V147) N147, count(V148) N148, count(V149) N149, count(V150) N150, count(V151) N151, count(V152) N152, count(V153) N153, count(V154) N154, count(V155) N155, count(V156) N156, count(V157) N157, count(V158) N158, count(V159) N159, count(V160) N160, count(V161) N161, count(V162) N162, count(V163) N163, count(V164) N164, count(V165) N165, count(V166) N166, count(V167) N167, count(V168) N168, count(V169) N169, count(V170) N170, count(V171) N171, count(V172) N172, count(V173) N173, count(V174) N174, count(V175) N175, count(V176) N176, count(V177) N177, count(V178) N178, count(V179) N179, count(V180) N180, count(V181) N181, count(V182) N182, count(V183) N183, count(V184) N184, count(V185) N185, count(V186) N186, count(V187) N187, count(V188) N188, count(V189) N189, count(V190) N190, count(V191) N191, count(V192) N192, count(V193) N193, count(V194) N194, count(V195) N195, count(V196) N196, count(V197) N197, count(V198) N198, count(V199) N199, count(V200) N200, count(V201) N201, count(V202) N202, count(V203) N203, count(V204) N204, count(V205) N205, count(V206) N206, count(V207) N207, count(V208) N208, count(V209) N209, count(V210) N210, count(V211) N211, count(V212) N212, count(V213) N213, count(V214) N214, count(V215) N215, count(V216) N216, count(V217) N217, count(V218) N218, count(V219) N219, count(V220) N220, count(V221) N221, count(V222) N222, count(V223) N223, count(V224) N224, count(V225) N225, count(V226) N226, count(V227) N227, count(V228) N228, count(V229) N229, count(V230) N230, count(V231) N231, count(V232) N232, count(V233) N233, count(V234) N234, count(V235) N235, count(V236) N236, count(V237) N237, count(V238) N238, count(V239) N239, count(V240) N240, count(V241) N241, count(V242) N242, count(V243) N243, count(V244) N244, count(V245) N245, count(V246) N246, count(V247) N247, count(V248) N248, count(V249) N249, count(V250) N250, count(V251) N251, count(V252) N252, count(V253) N253, count(V254) N254, count(V255) N255
							from (						
								select q.panel_number, s.B,
									min(V0) V0, min(V1) V1, min(V2) V2, min(V3) V3, min(V4) V4, min(V5) V5, min(V6) V6, min(V7) V7, min(V8) V8, min(V9) V9, min(V10) V10, min(V11) V11, min(V12) V12, min(V13) V13, min(V14) V14, min(V15) V15, min(V16) V16, min(V17) V17, min(V18) V18, min(V19) V19, min(V20) V20, min(V21) V21, min(V22) V22, min(V23) V23, min(V24) V24, min(V25) V25, min(V26) V26, min(V27) V27, min(V28) V28, min(V29) V29, min(V30) V30, min(V31) V31, min(V32) V32, min(V33) V33, min(V34) V34, min(V35) V35, min(V36) V36, min(V37) V37, min(V38) V38, min(V39) V39, min(V40) V40, min(V41) V41, min(V42) V42, min(V43) V43, min(V44) V44, min(V45) V45, min(V46) V46, min(V47) V47, min(V48) V48, min(V49) V49, min(V50) V50, min(V51) V51, min(V52) V52, min(V53) V53, min(V54) V54, min(V55) V55, min(V56) V56, min(V57) V57, min(V58) V58, min(V59) V59, min(V60) V60, min(V61) V61, min(V62) V62, min(V63) V63, min(V64) V64, min(V65) V65, min(V66) V66, min(V67) V67, min(V68) V68, min(V69) V69, min(V70) V70, min(V71) V71, min(V72) V72, min(V73) V73, min(V74) V74, min(V75) V75, min(V76) V76, min(V77) V77, min(V78) V78, min(V79) V79, min(V80) V80, min(V81) V81, min(V82) V82, min(V83) V83, min(V84) V84, min(V85) V85, min(V86) V86, min(V87) V87, min(V88) V88, min(V89) V89, min(V90) V90, min(V91) V91, min(V92) V92, min(V93) V93, min(V94) V94, min(V95) V95, min(V96) V96, min(V97) V97, min(V98) V98, min(V99) V99, min(V100) V100, min(V101) V101, min(V102) V102, min(V103) V103, min(V104) V104, min(V105) V105, min(V106) V106, min(V107) V107, min(V108) V108, min(V109) V109, min(V110) V110, min(V111) V111, min(V112) V112, min(V113) V113, min(V114) V114, min(V115) V115, min(V116) V116, min(V117) V117, min(V118) V118, min(V119) V119, min(V120) V120, min(V121) V121, min(V122) V122, min(V123) V123, min(V124) V124, min(V125) V125, min(V126) V126, min(V127) V127, min(V128) V128, min(V129) V129, min(V130) V130, min(V131) V131, min(V132) V132, min(V133) V133, min(V134) V134, min(V135) V135, min(V136) V136, min(V137) V137, min(V138) V138, min(V139) V139, min(V140) V140, min(V141) V141, min(V142) V142, min(V143) V143, min(V144) V144, min(V145) V145, min(V146) V146, min(V147) V147, min(V148) V148, min(V149) V149, min(V150) V150, min(V151) V151, min(V152) V152, min(V153) V153, min(V154) V154, min(V155) V155, min(V156) V156, min(V157) V157, min(V158) V158, min(V159) V159, min(V160) V160, min(V161) V161, min(V162) V162, min(V163) V163, min(V164) V164, min(V165) V165, min(V166) V166, min(V167) V167, min(V168) V168, min(V169) V169, min(V170) V170, min(V171) V171, min(V172) V172, min(V173) V173, min(V174) V174, min(V175) V175, min(V176) V176, min(V177) V177, min(V178) V178, min(V179) V179, min(V180) V180, min(V181) V181, min(V182) V182, min(V183) V183, min(V184) V184, min(V185) V185, min(V186) V186, min(V187) V187, min(V188) V188, min(V189) V189, min(V190) V190, min(V191) V191, min(V192) V192, min(V193) V193, min(V194) V194, min(V195) V195, min(V196) V196, min(V197) V197, min(V198) V198, min(V199) V199, min(V200) V200, min(V201) V201, min(V202) V202, min(V203) V203, min(V204) V204, min(V205) V205, min(V206) V206, min(V207) V207, min(V208) V208, min(V209) V209, min(V210) V210, min(V211) V211, min(V212) V212, min(V213) V213, min(V214) V214, min(V215) V215, min(V216) V216, min(V217) V217, min(V218) V218, min(V219) V219, min(V220) V220, min(V221) V221, min(V222) V222, min(V223) V223, min(V224) V224, min(V225) V225, min(V226) V226, min(V227) V227, min(V228) V228, min(V229) V229, min(V230) V230, min(V231) V231, min(V232) V232, min(V233) V233, min(V234) V234, min(V235) V235, min(V236) V236, min(V237) V237, min(V238) V238, min(V239) V239, min(V240) V240, min(V241) V241, min(V242) V242, min(V243) V243, min(V244) V244, min(V245) V245, min(V246) V246, min(V247) V247, min(V248) V248, min(V249) V249, min(V250) V250, min(V251) V251, min(V252) V252, min(V253) V253, min(V254) V254, min(V255) V255
								from #items q inner join CRC.CQ2_SKETCH_PATH15x256 s
									on q.concept_path_id = s.concept_path_id
								group by q.panel_number, s.B				
							) t
							group by B
						) t cross join (select count(distinct panel_number) n from #items) panel_count
					) t
				) t
			-- Set NULLs to zero
			select @SketchPanelE = isnull(@SketchPanelE,0), @SketchPanelN = isnull(@SketchPanelN,0), @SketchPanelQ = isnull(@SketchPanelQ,0)
			-- Store the results
			INSERT INTO #GlobalQueryCounts (query_master_id, num_patients, num_encounters, num_instances, num_facts, sketch_e, sketch_n, sketch_q, sketch_m)
				SELECT @QueryMasterID, @SketchPanelE, null, null, null, @SketchPanelE, @SketchPanelN, @SketchPanelQ, 32768
			RETURN;
		END
	END

	------------------------------------------------------------------------------
	-- Get a 8x256 sketch size estimate for each panel and the total query
	------------------------------------------------------------------------------

	IF (@UseCQ2SketchTables = 1)
	BEGIN
		-- Get the sketch estimate for each panel
		select panel_number, 0 B, HIVE.fnSketchEstimate(sV15, N15, N15, 256, 1) SketchPanelE, N15 SketchPanelN,
				V0, V1, V2, V3, V4, V5, V6, V7, V8, V9, V10, V11, V12, V13, V14, V15, V16, V17, V18, V19, V20, V21, V22, V23, V24, V25, V26, V27, V28, V29, V30, V31, V32, V33, V34, V35, V36, V37, V38, V39, V40, V41, V42, V43, V44, V45, V46, V47, V48, V49, V50, V51, V52, V53, V54, V55, V56, V57, V58, V59, V60, V61, V62, V63, V64, V65, V66, V67, V68, V69, V70, V71, V72, V73, V74, V75, V76, V77, V78, V79, V80, V81, V82, V83, V84, V85, V86, V87, V88, V89, V90, V91, V92, V93, V94, V95, V96, V97, V98, V99, V100, V101, V102, V103, V104, V105, V106, V107, V108, V109, V110, V111, V112, V113, V114, V115, V116, V117, V118, V119, V120, V121, V122, V123, V124, V125, V126, V127, V128, V129, V130, V131, V132, V133, V134, V135, V136, V137, V138, V139, V140, V141, V142, V143, V144, V145, V146, V147, V148, V149, V150, V151, V152, V153, V154, V155, V156, V157, V158, V159, V160, V161, V162, V163, V164, V165, V166, V167, V168, V169, V170, V171, V172, V173, V174, V175, V176, V177, V178, V179, V180, V181, V182, V183, V184, V185, V186, V187, V188, V189, V190, V191, V192, V193, V194, V195, V196, V197, V198, V199, V200, V201, V202, V203, V204, V205, V206, V207, V208, V209, V210, V211, V212, V213, V214, V215, V216, V217, V218, V219, V220, V221, V222, V223, V224, V225, V226, V227, V228, V229, V230, V231, V232, V233, V234, V235, V236, V237, V238, V239, V240, V241, V242, V243, V244, V245, V246, V247, V248, V249, V250, V251, V252, V253, V254, V255
			into #PanelSketch
			from (
				select *,
					cast(0 as float)+isnull(V0,0)+isnull(V1,0)+isnull(V2,0)+isnull(V3,0)+isnull(V4,0)+isnull(V5,0)+isnull(V6,0)+isnull(V7,0)+isnull(V8,0)+isnull(V9,0)+isnull(V10,0)+isnull(V11,0)+isnull(V12,0)+isnull(V13,0)+isnull(V14,0)+isnull(V15,0)+isnull(V16,0)+isnull(V17,0)+isnull(V18,0)+isnull(V19,0)+isnull(V20,0)+isnull(V21,0)+isnull(V22,0)+isnull(V23,0)+isnull(V24,0)+isnull(V25,0)+isnull(V26,0)+isnull(V27,0)+isnull(V28,0)+isnull(V29,0)+isnull(V30,0)+isnull(V31,0)+isnull(V32,0)+isnull(V33,0)+isnull(V34,0)+isnull(V35,0)+isnull(V36,0)+isnull(V37,0)+isnull(V38,0)+isnull(V39,0)+isnull(V40,0)+isnull(V41,0)+isnull(V42,0)+isnull(V43,0)+isnull(V44,0)+isnull(V45,0)+isnull(V46,0)+isnull(V47,0)+isnull(V48,0)+isnull(V49,0)+isnull(V50,0)+isnull(V51,0)+isnull(V52,0)+isnull(V53,0)+isnull(V54,0)+isnull(V55,0)+isnull(V56,0)+isnull(V57,0)+isnull(V58,0)+isnull(V59,0)+isnull(V60,0)+isnull(V61,0)+isnull(V62,0)+isnull(V63,0)+isnull(V64,0)+isnull(V65,0)+isnull(V66,0)+isnull(V67,0)+isnull(V68,0)+isnull(V69,0)+isnull(V70,0)+isnull(V71,0)+isnull(V72,0)+isnull(V73,0)+isnull(V74,0)+isnull(V75,0)+isnull(V76,0)+isnull(V77,0)+isnull(V78,0)+isnull(V79,0)+isnull(V80,0)+isnull(V81,0)+isnull(V82,0)+isnull(V83,0)+isnull(V84,0)+isnull(V85,0)+isnull(V86,0)+isnull(V87,0)+isnull(V88,0)+isnull(V89,0)+isnull(V90,0)+isnull(V91,0)+isnull(V92,0)+isnull(V93,0)+isnull(V94,0)+isnull(V95,0)+isnull(V96,0)+isnull(V97,0)+isnull(V98,0)+isnull(V99,0)+isnull(V100,0)+isnull(V101,0)+isnull(V102,0)+isnull(V103,0)+isnull(V104,0)+isnull(V105,0)+isnull(V106,0)+isnull(V107,0)+isnull(V108,0)+isnull(V109,0)+isnull(V110,0)+isnull(V111,0)+isnull(V112,0)+isnull(V113,0)+isnull(V114,0)+isnull(V115,0)+isnull(V116,0)+isnull(V117,0)+isnull(V118,0)+isnull(V119,0)+isnull(V120,0)+isnull(V121,0)+isnull(V122,0)+isnull(V123,0)+isnull(V124,0)+isnull(V125,0)+isnull(V126,0)+isnull(V127,0)+isnull(V128,0)+isnull(V129,0)+isnull(V130,0)+isnull(V131,0)+isnull(V132,0)+isnull(V133,0)+isnull(V134,0)+isnull(V135,0)+isnull(V136,0)+isnull(V137,0)+isnull(V138,0)+isnull(V139,0)+isnull(V140,0)+isnull(V141,0)+isnull(V142,0)+isnull(V143,0)+isnull(V144,0)+isnull(V145,0)+isnull(V146,0)+isnull(V147,0)+isnull(V148,0)+isnull(V149,0)+isnull(V150,0)+isnull(V151,0)+isnull(V152,0)+isnull(V153,0)+isnull(V154,0)+isnull(V155,0)+isnull(V156,0)+isnull(V157,0)+isnull(V158,0)+isnull(V159,0)+isnull(V160,0)+isnull(V161,0)+isnull(V162,0)+isnull(V163,0)+isnull(V164,0)+isnull(V165,0)+isnull(V166,0)+isnull(V167,0)+isnull(V168,0)+isnull(V169,0)+isnull(V170,0)+isnull(V171,0)+isnull(V172,0)+isnull(V173,0)+isnull(V174,0)+isnull(V175,0)+isnull(V176,0)+isnull(V177,0)+isnull(V178,0)+isnull(V179,0)+isnull(V180,0)+isnull(V181,0)+isnull(V182,0)+isnull(V183,0)+isnull(V184,0)+isnull(V185,0)+isnull(V186,0)+isnull(V187,0)+isnull(V188,0)+isnull(V189,0)+isnull(V190,0)+isnull(V191,0)+isnull(V192,0)+isnull(V193,0)+isnull(V194,0)+isnull(V195,0)+isnull(V196,0)+isnull(V197,0)+isnull(V198,0)+isnull(V199,0)+isnull(V200,0)+isnull(V201,0)+isnull(V202,0)+isnull(V203,0)+isnull(V204,0)+isnull(V205,0)+isnull(V206,0)+isnull(V207,0)+isnull(V208,0)+isnull(V209,0)+isnull(V210,0)+isnull(V211,0)+isnull(V212,0)+isnull(V213,0)+isnull(V214,0)+isnull(V215,0)+isnull(V216,0)+isnull(V217,0)+isnull(V218,0)+isnull(V219,0)+isnull(V220,0)+isnull(V221,0)+isnull(V222,0)+isnull(V223,0)+isnull(V224,0)+isnull(V225,0)+isnull(V226,0)+isnull(V227,0)+isnull(V228,0)+isnull(V229,0)+isnull(V230,0)+isnull(V231,0)+isnull(V232,0)+isnull(V233,0)+isnull(V234,0)+isnull(V235,0)+isnull(V236,0)+isnull(V237,0)+isnull(V238,0)+isnull(V239,0)+isnull(V240,0)+isnull(V241,0)+isnull(V242,0)+isnull(V243,0)+isnull(V244,0)+isnull(V245,0)+isnull(V246,0)+isnull(V247,0)+isnull(V248,0)+isnull(V249,0)+isnull(V250,0)+isnull(V251,0)+isnull(V252,0)+isnull(V253,0)+isnull(V254,0)+isnull(V255,0) sV15,
					(case when V0 is null then 0 else 1 end)+(case when V1 is null then 0 else 1 end)+(case when V2 is null then 0 else 1 end)+(case when V3 is null then 0 else 1 end)+(case when V4 is null then 0 else 1 end)+(case when V5 is null then 0 else 1 end)+(case when V6 is null then 0 else 1 end)+(case when V7 is null then 0 else 1 end)+(case when V8 is null then 0 else 1 end)+(case when V9 is null then 0 else 1 end)+(case when V10 is null then 0 else 1 end)+(case when V11 is null then 0 else 1 end)+(case when V12 is null then 0 else 1 end)+(case when V13 is null then 0 else 1 end)+(case when V14 is null then 0 else 1 end)+(case when V15 is null then 0 else 1 end)+(case when V16 is null then 0 else 1 end)+(case when V17 is null then 0 else 1 end)+(case when V18 is null then 0 else 1 end)+(case when V19 is null then 0 else 1 end)+(case when V20 is null then 0 else 1 end)+(case when V21 is null then 0 else 1 end)+(case when V22 is null then 0 else 1 end)+(case when V23 is null then 0 else 1 end)+(case when V24 is null then 0 else 1 end)+(case when V25 is null then 0 else 1 end)+(case when V26 is null then 0 else 1 end)+(case when V27 is null then 0 else 1 end)+(case when V28 is null then 0 else 1 end)+(case when V29 is null then 0 else 1 end)+(case when V30 is null then 0 else 1 end)+(case when V31 is null then 0 else 1 end)+(case when V32 is null then 0 else 1 end)+(case when V33 is null then 0 else 1 end)+(case when V34 is null then 0 else 1 end)+(case when V35 is null then 0 else 1 end)+(case when V36 is null then 0 else 1 end)+(case when V37 is null then 0 else 1 end)+(case when V38 is null then 0 else 1 end)+(case when V39 is null then 0 else 1 end)+(case when V40 is null then 0 else 1 end)+(case when V41 is null then 0 else 1 end)+(case when V42 is null then 0 else 1 end)+(case when V43 is null then 0 else 1 end)+(case when V44 is null then 0 else 1 end)+(case when V45 is null then 0 else 1 end)+(case when V46 is null then 0 else 1 end)+(case when V47 is null then 0 else 1 end)+(case when V48 is null then 0 else 1 end)+(case when V49 is null then 0 else 1 end)+(case when V50 is null then 0 else 1 end)+(case when V51 is null then 0 else 1 end)+(case when V52 is null then 0 else 1 end)+(case when V53 is null then 0 else 1 end)+(case when V54 is null then 0 else 1 end)+(case when V55 is null then 0 else 1 end)+(case when V56 is null then 0 else 1 end)+(case when V57 is null then 0 else 1 end)+(case when V58 is null then 0 else 1 end)+(case when V59 is null then 0 else 1 end)+(case when V60 is null then 0 else 1 end)+(case when V61 is null then 0 else 1 end)+(case when V62 is null then 0 else 1 end)+(case when V63 is null then 0 else 1 end)+(case when V64 is null then 0 else 1 end)+(case when V65 is null then 0 else 1 end)+(case when V66 is null then 0 else 1 end)+(case when V67 is null then 0 else 1 end)+(case when V68 is null then 0 else 1 end)+(case when V69 is null then 0 else 1 end)+(case when V70 is null then 0 else 1 end)+(case when V71 is null then 0 else 1 end)+(case when V72 is null then 0 else 1 end)+(case when V73 is null then 0 else 1 end)+(case when V74 is null then 0 else 1 end)+(case when V75 is null then 0 else 1 end)+(case when V76 is null then 0 else 1 end)+(case when V77 is null then 0 else 1 end)+(case when V78 is null then 0 else 1 end)+(case when V79 is null then 0 else 1 end)+(case when V80 is null then 0 else 1 end)+(case when V81 is null then 0 else 1 end)+(case when V82 is null then 0 else 1 end)+(case when V83 is null then 0 else 1 end)+(case when V84 is null then 0 else 1 end)+(case when V85 is null then 0 else 1 end)+(case when V86 is null then 0 else 1 end)+(case when V87 is null then 0 else 1 end)+(case when V88 is null then 0 else 1 end)+(case when V89 is null then 0 else 1 end)+(case when V90 is null then 0 else 1 end)+(case when V91 is null then 0 else 1 end)+(case when V92 is null then 0 else 1 end)+(case when V93 is null then 0 else 1 end)+(case when V94 is null then 0 else 1 end)+(case when V95 is null then 0 else 1 end)+(case when V96 is null then 0 else 1 end)+(case when V97 is null then 0 else 1 end)+(case when V98 is null then 0 else 1 end)+(case when V99 is null then 0 else 1 end)+(case when V100 is null then 0 else 1 end)+(case when V101 is null then 0 else 1 end)+(case when V102 is null then 0 else 1 end)+(case when V103 is null then 0 else 1 end)+(case when V104 is null then 0 else 1 end)+(case when V105 is null then 0 else 1 end)+(case when V106 is null then 0 else 1 end)+(case when V107 is null then 0 else 1 end)+(case when V108 is null then 0 else 1 end)+(case when V109 is null then 0 else 1 end)+(case when V110 is null then 0 else 1 end)+(case when V111 is null then 0 else 1 end)+(case when V112 is null then 0 else 1 end)+(case when V113 is null then 0 else 1 end)+(case when V114 is null then 0 else 1 end)+(case when V115 is null then 0 else 1 end)+(case when V116 is null then 0 else 1 end)+(case when V117 is null then 0 else 1 end)+(case when V118 is null then 0 else 1 end)+(case when V119 is null then 0 else 1 end)+(case when V120 is null then 0 else 1 end)+(case when V121 is null then 0 else 1 end)+(case when V122 is null then 0 else 1 end)+(case when V123 is null then 0 else 1 end)+(case when V124 is null then 0 else 1 end)+(case when V125 is null then 0 else 1 end)+(case when V126 is null then 0 else 1 end)+(case when V127 is null then 0 else 1 end)+(case when V128 is null then 0 else 1 end)+(case when V129 is null then 0 else 1 end)+(case when V130 is null then 0 else 1 end)+(case when V131 is null then 0 else 1 end)+(case when V132 is null then 0 else 1 end)+(case when V133 is null then 0 else 1 end)+(case when V134 is null then 0 else 1 end)+(case when V135 is null then 0 else 1 end)+(case when V136 is null then 0 else 1 end)+(case when V137 is null then 0 else 1 end)+(case when V138 is null then 0 else 1 end)+(case when V139 is null then 0 else 1 end)+(case when V140 is null then 0 else 1 end)+(case when V141 is null then 0 else 1 end)+(case when V142 is null then 0 else 1 end)+(case when V143 is null then 0 else 1 end)+(case when V144 is null then 0 else 1 end)+(case when V145 is null then 0 else 1 end)+(case when V146 is null then 0 else 1 end)+(case when V147 is null then 0 else 1 end)+(case when V148 is null then 0 else 1 end)+(case when V149 is null then 0 else 1 end)+(case when V150 is null then 0 else 1 end)+(case when V151 is null then 0 else 1 end)+(case when V152 is null then 0 else 1 end)+(case when V153 is null then 0 else 1 end)+(case when V154 is null then 0 else 1 end)+(case when V155 is null then 0 else 1 end)+(case when V156 is null then 0 else 1 end)+(case when V157 is null then 0 else 1 end)+(case when V158 is null then 0 else 1 end)+(case when V159 is null then 0 else 1 end)+(case when V160 is null then 0 else 1 end)+(case when V161 is null then 0 else 1 end)+(case when V162 is null then 0 else 1 end)+(case when V163 is null then 0 else 1 end)+(case when V164 is null then 0 else 1 end)+(case when V165 is null then 0 else 1 end)+(case when V166 is null then 0 else 1 end)+(case when V167 is null then 0 else 1 end)+(case when V168 is null then 0 else 1 end)+(case when V169 is null then 0 else 1 end)+(case when V170 is null then 0 else 1 end)+(case when V171 is null then 0 else 1 end)+(case when V172 is null then 0 else 1 end)+(case when V173 is null then 0 else 1 end)+(case when V174 is null then 0 else 1 end)+(case when V175 is null then 0 else 1 end)+(case when V176 is null then 0 else 1 end)+(case when V177 is null then 0 else 1 end)+(case when V178 is null then 0 else 1 end)+(case when V179 is null then 0 else 1 end)+(case when V180 is null then 0 else 1 end)+(case when V181 is null then 0 else 1 end)+(case when V182 is null then 0 else 1 end)+(case when V183 is null then 0 else 1 end)+(case when V184 is null then 0 else 1 end)+(case when V185 is null then 0 else 1 end)+(case when V186 is null then 0 else 1 end)+(case when V187 is null then 0 else 1 end)+(case when V188 is null then 0 else 1 end)+(case when V189 is null then 0 else 1 end)+(case when V190 is null then 0 else 1 end)+(case when V191 is null then 0 else 1 end)+(case when V192 is null then 0 else 1 end)+(case when V193 is null then 0 else 1 end)+(case when V194 is null then 0 else 1 end)+(case when V195 is null then 0 else 1 end)+(case when V196 is null then 0 else 1 end)+(case when V197 is null then 0 else 1 end)+(case when V198 is null then 0 else 1 end)+(case when V199 is null then 0 else 1 end)+(case when V200 is null then 0 else 1 end)+(case when V201 is null then 0 else 1 end)+(case when V202 is null then 0 else 1 end)+(case when V203 is null then 0 else 1 end)+(case when V204 is null then 0 else 1 end)+(case when V205 is null then 0 else 1 end)+(case when V206 is null then 0 else 1 end)+(case when V207 is null then 0 else 1 end)+(case when V208 is null then 0 else 1 end)+(case when V209 is null then 0 else 1 end)+(case when V210 is null then 0 else 1 end)+(case when V211 is null then 0 else 1 end)+(case when V212 is null then 0 else 1 end)+(case when V213 is null then 0 else 1 end)+(case when V214 is null then 0 else 1 end)+(case when V215 is null then 0 else 1 end)+(case when V216 is null then 0 else 1 end)+(case when V217 is null then 0 else 1 end)+(case when V218 is null then 0 else 1 end)+(case when V219 is null then 0 else 1 end)+(case when V220 is null then 0 else 1 end)+(case when V221 is null then 0 else 1 end)+(case when V222 is null then 0 else 1 end)+(case when V223 is null then 0 else 1 end)+(case when V224 is null then 0 else 1 end)+(case when V225 is null then 0 else 1 end)+(case when V226 is null then 0 else 1 end)+(case when V227 is null then 0 else 1 end)+(case when V228 is null then 0 else 1 end)+(case when V229 is null then 0 else 1 end)+(case when V230 is null then 0 else 1 end)+(case when V231 is null then 0 else 1 end)+(case when V232 is null then 0 else 1 end)+(case when V233 is null then 0 else 1 end)+(case when V234 is null then 0 else 1 end)+(case when V235 is null then 0 else 1 end)+(case when V236 is null then 0 else 1 end)+(case when V237 is null then 0 else 1 end)+(case when V238 is null then 0 else 1 end)+(case when V239 is null then 0 else 1 end)+(case when V240 is null then 0 else 1 end)+(case when V241 is null then 0 else 1 end)+(case when V242 is null then 0 else 1 end)+(case when V243 is null then 0 else 1 end)+(case when V244 is null then 0 else 1 end)+(case when V245 is null then 0 else 1 end)+(case when V246 is null then 0 else 1 end)+(case when V247 is null then 0 else 1 end)+(case when V248 is null then 0 else 1 end)+(case when V249 is null then 0 else 1 end)+(case when V250 is null then 0 else 1 end)+(case when V251 is null then 0 else 1 end)+(case when V252 is null then 0 else 1 end)+(case when V253 is null then 0 else 1 end)+(case when V254 is null then 0 else 1 end)+(case when V255 is null then 0 else 1 end) N15
				from (	
					select q.panel_number,
						min(V0) V0, min(V1) V1, min(V2) V2, min(V3) V3, min(V4) V4, min(V5) V5, min(V6) V6, min(V7) V7, min(V8) V8, min(V9) V9, min(V10) V10, min(V11) V11, min(V12) V12, min(V13) V13, min(V14) V14, min(V15) V15, min(V16) V16, min(V17) V17, min(V18) V18, min(V19) V19, min(V20) V20, min(V21) V21, min(V22) V22, min(V23) V23, min(V24) V24, min(V25) V25, min(V26) V26, min(V27) V27, min(V28) V28, min(V29) V29, min(V30) V30, min(V31) V31, min(V32) V32, min(V33) V33, min(V34) V34, min(V35) V35, min(V36) V36, min(V37) V37, min(V38) V38, min(V39) V39, min(V40) V40, min(V41) V41, min(V42) V42, min(V43) V43, min(V44) V44, min(V45) V45, min(V46) V46, min(V47) V47, min(V48) V48, min(V49) V49, min(V50) V50, min(V51) V51, min(V52) V52, min(V53) V53, min(V54) V54, min(V55) V55, min(V56) V56, min(V57) V57, min(V58) V58, min(V59) V59, min(V60) V60, min(V61) V61, min(V62) V62, min(V63) V63, min(V64) V64, min(V65) V65, min(V66) V66, min(V67) V67, min(V68) V68, min(V69) V69, min(V70) V70, min(V71) V71, min(V72) V72, min(V73) V73, min(V74) V74, min(V75) V75, min(V76) V76, min(V77) V77, min(V78) V78, min(V79) V79, min(V80) V80, min(V81) V81, min(V82) V82, min(V83) V83, min(V84) V84, min(V85) V85, min(V86) V86, min(V87) V87, min(V88) V88, min(V89) V89, min(V90) V90, min(V91) V91, min(V92) V92, min(V93) V93, min(V94) V94, min(V95) V95, min(V96) V96, min(V97) V97, min(V98) V98, min(V99) V99, min(V100) V100, min(V101) V101, min(V102) V102, min(V103) V103, min(V104) V104, min(V105) V105, min(V106) V106, min(V107) V107, min(V108) V108, min(V109) V109, min(V110) V110, min(V111) V111, min(V112) V112, min(V113) V113, min(V114) V114, min(V115) V115, min(V116) V116, min(V117) V117, min(V118) V118, min(V119) V119, min(V120) V120, min(V121) V121, min(V122) V122, min(V123) V123, min(V124) V124, min(V125) V125, min(V126) V126, min(V127) V127, min(V128) V128, min(V129) V129, min(V130) V130, min(V131) V131, min(V132) V132, min(V133) V133, min(V134) V134, min(V135) V135, min(V136) V136, min(V137) V137, min(V138) V138, min(V139) V139, min(V140) V140, min(V141) V141, min(V142) V142, min(V143) V143, min(V144) V144, min(V145) V145, min(V146) V146, min(V147) V147, min(V148) V148, min(V149) V149, min(V150) V150, min(V151) V151, min(V152) V152, min(V153) V153, min(V154) V154, min(V155) V155, min(V156) V156, min(V157) V157, min(V158) V158, min(V159) V159, min(V160) V160, min(V161) V161, min(V162) V162, min(V163) V163, min(V164) V164, min(V165) V165, min(V166) V166, min(V167) V167, min(V168) V168, min(V169) V169, min(V170) V170, min(V171) V171, min(V172) V172, min(V173) V173, min(V174) V174, min(V175) V175, min(V176) V176, min(V177) V177, min(V178) V178, min(V179) V179, min(V180) V180, min(V181) V181, min(V182) V182, min(V183) V183, min(V184) V184, min(V185) V185, min(V186) V186, min(V187) V187, min(V188) V188, min(V189) V189, min(V190) V190, min(V191) V191, min(V192) V192, min(V193) V193, min(V194) V194, min(V195) V195, min(V196) V196, min(V197) V197, min(V198) V198, min(V199) V199, min(V200) V200, min(V201) V201, min(V202) V202, min(V203) V203, min(V204) V204, min(V205) V205, min(V206) V206, min(V207) V207, min(V208) V208, min(V209) V209, min(V210) V210, min(V211) V211, min(V212) V212, min(V213) V213, min(V214) V214, min(V215) V215, min(V216) V216, min(V217) V217, min(V218) V218, min(V219) V219, min(V220) V220, min(V221) V221, min(V222) V222, min(V223) V223, min(V224) V224, min(V225) V225, min(V226) V226, min(V227) V227, min(V228) V228, min(V229) V229, min(V230) V230, min(V231) V231, min(V232) V232, min(V233) V233, min(V234) V234, min(V235) V235, min(V236) V236, min(V237) V237, min(V238) V238, min(V239) V239, min(V240) V240, min(V241) V241, min(V242) V242, min(V243) V243, min(V244) V244, min(V245) V245, min(V246) V246, min(V247) V247, min(V248) V248, min(V249) V249, min(V250) V250, min(V251) V251, min(V252) V252, min(V253) V253, min(V254) V254, min(V255) V255
					from #items q inner join CRC.CQ2_SKETCH_PATH8x256 s
						on q.concept_path_id = s.concept_path_id
					where q.panel_number IN (
						SELECT panel_number 
						FROM #Panels 
						WHERE all_concept_paths = 1 AND Invert=0
							AND ((@QueryMethod IN ('MINHASH8','MINHASH15')) OR (number_of_items > 1))
					)
					group by q.panel_number
				) t
			) t

		-- Update the panel estimate
		UPDATE p
			SET p.estimated_count = s.SketchPanelE
			FROM #Panels p 
				INNER JOIN #PanelSketch s
					ON p.panel_number = s.panel_number
			WHERE number_of_items > 1

		-- Switch to EXACT query mode if sketches provide no benefit
		IF @QueryMethod IN ('MINHASH8','MINHASH15')
		BEGIN
			SELECT @QueryMethod = 'EXACT'
				WHERE NOT EXISTS (SELECT * FROM #PanelSketch)
			IF @QueryMethod = 'MINHASH8'
				SELECT @QueryMethod = 'EXACT' WHERE (SELECT MIN(estimated_count) FROM #Panels WHERE Invert=0) <= 256
			IF @QueryMethod = 'MINHASH15'
				SELECT @QueryMethod = 'EXACT' WHERE (SELECT MIN(estimated_count) FROM #Panels WHERE Invert=0) <= 32768
		END
	END

	------------------------------------------------------------------------------
	-- Use sketches to get a sample of patients from the smallest panel
	------------------------------------------------------------------------------

	IF (@UseCQ2SketchTables = 0)
		SELECT @QueryMethod = 'EXACT'

	IF @QueryMethod IN ('MINHASH8','MINHASH15')
	BEGIN
		-- Determine the smallest panel
		SELECT @SketchPanel = panel_number
			FROM (
				SELECT panel_number, SketchPanelE, ROW_NUMBER() OVER (ORDER BY SketchPanelE, panel_number) k
				FROM #PanelSketch
			) t
			WHERE k=1

		-- Get the sketch size estimate of the smallest panel
		IF @QueryMethod = 'MINHASH8'
		BEGIN
			SELECT @SketchPanelE = SketchPanelE, @SketchPanelN = SketchPanelN
				FROM #PanelSketch
				WHERE panel_number = @SketchPanel

		END
		IF @QueryMethod = 'MINHASH15'
		BEGIN
			-- Replace the 8x256 sketch with a 15x256 sketch
			TRUNCATE TABLE #PanelSketch
			INSERT INTO #PanelSketch
				SELECT 0, B, 0, 0,
					min(V0) V0, min(V1) V1, min(V2) V2, min(V3) V3, min(V4) V4, min(V5) V5, min(V6) V6, min(V7) V7, min(V8) V8, min(V9) V9, min(V10) V10, min(V11) V11, min(V12) V12, min(V13) V13, min(V14) V14, min(V15) V15, min(V16) V16, min(V17) V17, min(V18) V18, min(V19) V19, min(V20) V20, min(V21) V21, min(V22) V22, min(V23) V23, min(V24) V24, min(V25) V25, min(V26) V26, min(V27) V27, min(V28) V28, min(V29) V29, min(V30) V30, min(V31) V31, min(V32) V32, min(V33) V33, min(V34) V34, min(V35) V35, min(V36) V36, min(V37) V37, min(V38) V38, min(V39) V39, min(V40) V40, min(V41) V41, min(V42) V42, min(V43) V43, min(V44) V44, min(V45) V45, min(V46) V46, min(V47) V47, min(V48) V48, min(V49) V49, min(V50) V50, min(V51) V51, min(V52) V52, min(V53) V53, min(V54) V54, min(V55) V55, min(V56) V56, min(V57) V57, min(V58) V58, min(V59) V59, min(V60) V60, min(V61) V61, min(V62) V62, min(V63) V63, min(V64) V64, min(V65) V65, min(V66) V66, min(V67) V67, min(V68) V68, min(V69) V69, min(V70) V70, min(V71) V71, min(V72) V72, min(V73) V73, min(V74) V74, min(V75) V75, min(V76) V76, min(V77) V77, min(V78) V78, min(V79) V79, min(V80) V80, min(V81) V81, min(V82) V82, min(V83) V83, min(V84) V84, min(V85) V85, min(V86) V86, min(V87) V87, min(V88) V88, min(V89) V89, min(V90) V90, min(V91) V91, min(V92) V92, min(V93) V93, min(V94) V94, min(V95) V95, min(V96) V96, min(V97) V97, min(V98) V98, min(V99) V99, min(V100) V100, min(V101) V101, min(V102) V102, min(V103) V103, min(V104) V104, min(V105) V105, min(V106) V106, min(V107) V107, min(V108) V108, min(V109) V109, min(V110) V110, min(V111) V111, min(V112) V112, min(V113) V113, min(V114) V114, min(V115) V115, min(V116) V116, min(V117) V117, min(V118) V118, min(V119) V119, min(V120) V120, min(V121) V121, min(V122) V122, min(V123) V123, min(V124) V124, min(V125) V125, min(V126) V126, min(V127) V127, min(V128) V128, min(V129) V129, min(V130) V130, min(V131) V131, min(V132) V132, min(V133) V133, min(V134) V134, min(V135) V135, min(V136) V136, min(V137) V137, min(V138) V138, min(V139) V139, min(V140) V140, min(V141) V141, min(V142) V142, min(V143) V143, min(V144) V144, min(V145) V145, min(V146) V146, min(V147) V147, min(V148) V148, min(V149) V149, min(V150) V150, min(V151) V151, min(V152) V152, min(V153) V153, min(V154) V154, min(V155) V155, min(V156) V156, min(V157) V157, min(V158) V158, min(V159) V159, min(V160) V160, min(V161) V161, min(V162) V162, min(V163) V163, min(V164) V164, min(V165) V165, min(V166) V166, min(V167) V167, min(V168) V168, min(V169) V169, min(V170) V170, min(V171) V171, min(V172) V172, min(V173) V173, min(V174) V174, min(V175) V175, min(V176) V176, min(V177) V177, min(V178) V178, min(V179) V179, min(V180) V180, min(V181) V181, min(V182) V182, min(V183) V183, min(V184) V184, min(V185) V185, min(V186) V186, min(V187) V187, min(V188) V188, min(V189) V189, min(V190) V190, min(V191) V191, min(V192) V192, min(V193) V193, min(V194) V194, min(V195) V195, min(V196) V196, min(V197) V197, min(V198) V198, min(V199) V199, min(V200) V200, min(V201) V201, min(V202) V202, min(V203) V203, min(V204) V204, min(V205) V205, min(V206) V206, min(V207) V207, min(V208) V208, min(V209) V209, min(V210) V210, min(V211) V211, min(V212) V212, min(V213) V213, min(V214) V214, min(V215) V215, min(V216) V216, min(V217) V217, min(V218) V218, min(V219) V219, min(V220) V220, min(V221) V221, min(V222) V222, min(V223) V223, min(V224) V224, min(V225) V225, min(V226) V226, min(V227) V227, min(V228) V228, min(V229) V229, min(V230) V230, min(V231) V231, min(V232) V232, min(V233) V233, min(V234) V234, min(V235) V235, min(V236) V236, min(V237) V237, min(V238) V238, min(V239) V239, min(V240) V240, min(V241) V241, min(V242) V242, min(V243) V243, min(V244) V244, min(V245) V245, min(V246) V246, min(V247) V247, min(V248) V248, min(V249) V249, min(V250) V250, min(V251) V251, min(V252) V252, min(V253) V253, min(V254) V254, min(V255) V255
				FROM #items q INNER JOIN CRC.CQ2_SKETCH_PATH15x256 s
					ON q.concept_path_id = s.concept_path_id
				WHERE q.panel_number = @SketchPanel
				GROUP BY B
			-- Calculate the more accurate sketch size estimate
			SELECT @SketchPanelE = HIVE.fnSketchEstimate(sV15, N15, N15, 32768, 1), @SketchPanelN = N15
				FROM (
					SELECT SUM(sV15) sV15, SUM(N15) N15
					FROM (
						SELECT
							cast(0 as float)+isnull(V0,0)+isnull(V1,0)+isnull(V2,0)+isnull(V3,0)+isnull(V4,0)+isnull(V5,0)+isnull(V6,0)+isnull(V7,0)+isnull(V8,0)+isnull(V9,0)+isnull(V10,0)+isnull(V11,0)+isnull(V12,0)+isnull(V13,0)+isnull(V14,0)+isnull(V15,0)+isnull(V16,0)+isnull(V17,0)+isnull(V18,0)+isnull(V19,0)+isnull(V20,0)+isnull(V21,0)+isnull(V22,0)+isnull(V23,0)+isnull(V24,0)+isnull(V25,0)+isnull(V26,0)+isnull(V27,0)+isnull(V28,0)+isnull(V29,0)+isnull(V30,0)+isnull(V31,0)+isnull(V32,0)+isnull(V33,0)+isnull(V34,0)+isnull(V35,0)+isnull(V36,0)+isnull(V37,0)+isnull(V38,0)+isnull(V39,0)+isnull(V40,0)+isnull(V41,0)+isnull(V42,0)+isnull(V43,0)+isnull(V44,0)+isnull(V45,0)+isnull(V46,0)+isnull(V47,0)+isnull(V48,0)+isnull(V49,0)+isnull(V50,0)+isnull(V51,0)+isnull(V52,0)+isnull(V53,0)+isnull(V54,0)+isnull(V55,0)+isnull(V56,0)+isnull(V57,0)+isnull(V58,0)+isnull(V59,0)+isnull(V60,0)+isnull(V61,0)+isnull(V62,0)+isnull(V63,0)+isnull(V64,0)+isnull(V65,0)+isnull(V66,0)+isnull(V67,0)+isnull(V68,0)+isnull(V69,0)+isnull(V70,0)+isnull(V71,0)+isnull(V72,0)+isnull(V73,0)+isnull(V74,0)+isnull(V75,0)+isnull(V76,0)+isnull(V77,0)+isnull(V78,0)+isnull(V79,0)+isnull(V80,0)+isnull(V81,0)+isnull(V82,0)+isnull(V83,0)+isnull(V84,0)+isnull(V85,0)+isnull(V86,0)+isnull(V87,0)+isnull(V88,0)+isnull(V89,0)+isnull(V90,0)+isnull(V91,0)+isnull(V92,0)+isnull(V93,0)+isnull(V94,0)+isnull(V95,0)+isnull(V96,0)+isnull(V97,0)+isnull(V98,0)+isnull(V99,0)+isnull(V100,0)+isnull(V101,0)+isnull(V102,0)+isnull(V103,0)+isnull(V104,0)+isnull(V105,0)+isnull(V106,0)+isnull(V107,0)+isnull(V108,0)+isnull(V109,0)+isnull(V110,0)+isnull(V111,0)+isnull(V112,0)+isnull(V113,0)+isnull(V114,0)+isnull(V115,0)+isnull(V116,0)+isnull(V117,0)+isnull(V118,0)+isnull(V119,0)+isnull(V120,0)+isnull(V121,0)+isnull(V122,0)+isnull(V123,0)+isnull(V124,0)+isnull(V125,0)+isnull(V126,0)+isnull(V127,0)+isnull(V128,0)+isnull(V129,0)+isnull(V130,0)+isnull(V131,0)+isnull(V132,0)+isnull(V133,0)+isnull(V134,0)+isnull(V135,0)+isnull(V136,0)+isnull(V137,0)+isnull(V138,0)+isnull(V139,0)+isnull(V140,0)+isnull(V141,0)+isnull(V142,0)+isnull(V143,0)+isnull(V144,0)+isnull(V145,0)+isnull(V146,0)+isnull(V147,0)+isnull(V148,0)+isnull(V149,0)+isnull(V150,0)+isnull(V151,0)+isnull(V152,0)+isnull(V153,0)+isnull(V154,0)+isnull(V155,0)+isnull(V156,0)+isnull(V157,0)+isnull(V158,0)+isnull(V159,0)+isnull(V160,0)+isnull(V161,0)+isnull(V162,0)+isnull(V163,0)+isnull(V164,0)+isnull(V165,0)+isnull(V166,0)+isnull(V167,0)+isnull(V168,0)+isnull(V169,0)+isnull(V170,0)+isnull(V171,0)+isnull(V172,0)+isnull(V173,0)+isnull(V174,0)+isnull(V175,0)+isnull(V176,0)+isnull(V177,0)+isnull(V178,0)+isnull(V179,0)+isnull(V180,0)+isnull(V181,0)+isnull(V182,0)+isnull(V183,0)+isnull(V184,0)+isnull(V185,0)+isnull(V186,0)+isnull(V187,0)+isnull(V188,0)+isnull(V189,0)+isnull(V190,0)+isnull(V191,0)+isnull(V192,0)+isnull(V193,0)+isnull(V194,0)+isnull(V195,0)+isnull(V196,0)+isnull(V197,0)+isnull(V198,0)+isnull(V199,0)+isnull(V200,0)+isnull(V201,0)+isnull(V202,0)+isnull(V203,0)+isnull(V204,0)+isnull(V205,0)+isnull(V206,0)+isnull(V207,0)+isnull(V208,0)+isnull(V209,0)+isnull(V210,0)+isnull(V211,0)+isnull(V212,0)+isnull(V213,0)+isnull(V214,0)+isnull(V215,0)+isnull(V216,0)+isnull(V217,0)+isnull(V218,0)+isnull(V219,0)+isnull(V220,0)+isnull(V221,0)+isnull(V222,0)+isnull(V223,0)+isnull(V224,0)+isnull(V225,0)+isnull(V226,0)+isnull(V227,0)+isnull(V228,0)+isnull(V229,0)+isnull(V230,0)+isnull(V231,0)+isnull(V232,0)+isnull(V233,0)+isnull(V234,0)+isnull(V235,0)+isnull(V236,0)+isnull(V237,0)+isnull(V238,0)+isnull(V239,0)+isnull(V240,0)+isnull(V241,0)+isnull(V242,0)+isnull(V243,0)+isnull(V244,0)+isnull(V245,0)+isnull(V246,0)+isnull(V247,0)+isnull(V248,0)+isnull(V249,0)+isnull(V250,0)+isnull(V251,0)+isnull(V252,0)+isnull(V253,0)+isnull(V254,0)+isnull(V255,0) sV15,
							(case when V0 is null then 0 else 1 end)+(case when V1 is null then 0 else 1 end)+(case when V2 is null then 0 else 1 end)+(case when V3 is null then 0 else 1 end)+(case when V4 is null then 0 else 1 end)+(case when V5 is null then 0 else 1 end)+(case when V6 is null then 0 else 1 end)+(case when V7 is null then 0 else 1 end)+(case when V8 is null then 0 else 1 end)+(case when V9 is null then 0 else 1 end)+(case when V10 is null then 0 else 1 end)+(case when V11 is null then 0 else 1 end)+(case when V12 is null then 0 else 1 end)+(case when V13 is null then 0 else 1 end)+(case when V14 is null then 0 else 1 end)+(case when V15 is null then 0 else 1 end)+(case when V16 is null then 0 else 1 end)+(case when V17 is null then 0 else 1 end)+(case when V18 is null then 0 else 1 end)+(case when V19 is null then 0 else 1 end)+(case when V20 is null then 0 else 1 end)+(case when V21 is null then 0 else 1 end)+(case when V22 is null then 0 else 1 end)+(case when V23 is null then 0 else 1 end)+(case when V24 is null then 0 else 1 end)+(case when V25 is null then 0 else 1 end)+(case when V26 is null then 0 else 1 end)+(case when V27 is null then 0 else 1 end)+(case when V28 is null then 0 else 1 end)+(case when V29 is null then 0 else 1 end)+(case when V30 is null then 0 else 1 end)+(case when V31 is null then 0 else 1 end)+(case when V32 is null then 0 else 1 end)+(case when V33 is null then 0 else 1 end)+(case when V34 is null then 0 else 1 end)+(case when V35 is null then 0 else 1 end)+(case when V36 is null then 0 else 1 end)+(case when V37 is null then 0 else 1 end)+(case when V38 is null then 0 else 1 end)+(case when V39 is null then 0 else 1 end)+(case when V40 is null then 0 else 1 end)+(case when V41 is null then 0 else 1 end)+(case when V42 is null then 0 else 1 end)+(case when V43 is null then 0 else 1 end)+(case when V44 is null then 0 else 1 end)+(case when V45 is null then 0 else 1 end)+(case when V46 is null then 0 else 1 end)+(case when V47 is null then 0 else 1 end)+(case when V48 is null then 0 else 1 end)+(case when V49 is null then 0 else 1 end)+(case when V50 is null then 0 else 1 end)+(case when V51 is null then 0 else 1 end)+(case when V52 is null then 0 else 1 end)+(case when V53 is null then 0 else 1 end)+(case when V54 is null then 0 else 1 end)+(case when V55 is null then 0 else 1 end)+(case when V56 is null then 0 else 1 end)+(case when V57 is null then 0 else 1 end)+(case when V58 is null then 0 else 1 end)+(case when V59 is null then 0 else 1 end)+(case when V60 is null then 0 else 1 end)+(case when V61 is null then 0 else 1 end)+(case when V62 is null then 0 else 1 end)+(case when V63 is null then 0 else 1 end)+(case when V64 is null then 0 else 1 end)+(case when V65 is null then 0 else 1 end)+(case when V66 is null then 0 else 1 end)+(case when V67 is null then 0 else 1 end)+(case when V68 is null then 0 else 1 end)+(case when V69 is null then 0 else 1 end)+(case when V70 is null then 0 else 1 end)+(case when V71 is null then 0 else 1 end)+(case when V72 is null then 0 else 1 end)+(case when V73 is null then 0 else 1 end)+(case when V74 is null then 0 else 1 end)+(case when V75 is null then 0 else 1 end)+(case when V76 is null then 0 else 1 end)+(case when V77 is null then 0 else 1 end)+(case when V78 is null then 0 else 1 end)+(case when V79 is null then 0 else 1 end)+(case when V80 is null then 0 else 1 end)+(case when V81 is null then 0 else 1 end)+(case when V82 is null then 0 else 1 end)+(case when V83 is null then 0 else 1 end)+(case when V84 is null then 0 else 1 end)+(case when V85 is null then 0 else 1 end)+(case when V86 is null then 0 else 1 end)+(case when V87 is null then 0 else 1 end)+(case when V88 is null then 0 else 1 end)+(case when V89 is null then 0 else 1 end)+(case when V90 is null then 0 else 1 end)+(case when V91 is null then 0 else 1 end)+(case when V92 is null then 0 else 1 end)+(case when V93 is null then 0 else 1 end)+(case when V94 is null then 0 else 1 end)+(case when V95 is null then 0 else 1 end)+(case when V96 is null then 0 else 1 end)+(case when V97 is null then 0 else 1 end)+(case when V98 is null then 0 else 1 end)+(case when V99 is null then 0 else 1 end)+(case when V100 is null then 0 else 1 end)+(case when V101 is null then 0 else 1 end)+(case when V102 is null then 0 else 1 end)+(case when V103 is null then 0 else 1 end)+(case when V104 is null then 0 else 1 end)+(case when V105 is null then 0 else 1 end)+(case when V106 is null then 0 else 1 end)+(case when V107 is null then 0 else 1 end)+(case when V108 is null then 0 else 1 end)+(case when V109 is null then 0 else 1 end)+(case when V110 is null then 0 else 1 end)+(case when V111 is null then 0 else 1 end)+(case when V112 is null then 0 else 1 end)+(case when V113 is null then 0 else 1 end)+(case when V114 is null then 0 else 1 end)+(case when V115 is null then 0 else 1 end)+(case when V116 is null then 0 else 1 end)+(case when V117 is null then 0 else 1 end)+(case when V118 is null then 0 else 1 end)+(case when V119 is null then 0 else 1 end)+(case when V120 is null then 0 else 1 end)+(case when V121 is null then 0 else 1 end)+(case when V122 is null then 0 else 1 end)+(case when V123 is null then 0 else 1 end)+(case when V124 is null then 0 else 1 end)+(case when V125 is null then 0 else 1 end)+(case when V126 is null then 0 else 1 end)+(case when V127 is null then 0 else 1 end)+(case when V128 is null then 0 else 1 end)+(case when V129 is null then 0 else 1 end)+(case when V130 is null then 0 else 1 end)+(case when V131 is null then 0 else 1 end)+(case when V132 is null then 0 else 1 end)+(case when V133 is null then 0 else 1 end)+(case when V134 is null then 0 else 1 end)+(case when V135 is null then 0 else 1 end)+(case when V136 is null then 0 else 1 end)+(case when V137 is null then 0 else 1 end)+(case when V138 is null then 0 else 1 end)+(case when V139 is null then 0 else 1 end)+(case when V140 is null then 0 else 1 end)+(case when V141 is null then 0 else 1 end)+(case when V142 is null then 0 else 1 end)+(case when V143 is null then 0 else 1 end)+(case when V144 is null then 0 else 1 end)+(case when V145 is null then 0 else 1 end)+(case when V146 is null then 0 else 1 end)+(case when V147 is null then 0 else 1 end)+(case when V148 is null then 0 else 1 end)+(case when V149 is null then 0 else 1 end)+(case when V150 is null then 0 else 1 end)+(case when V151 is null then 0 else 1 end)+(case when V152 is null then 0 else 1 end)+(case when V153 is null then 0 else 1 end)+(case when V154 is null then 0 else 1 end)+(case when V155 is null then 0 else 1 end)+(case when V156 is null then 0 else 1 end)+(case when V157 is null then 0 else 1 end)+(case when V158 is null then 0 else 1 end)+(case when V159 is null then 0 else 1 end)+(case when V160 is null then 0 else 1 end)+(case when V161 is null then 0 else 1 end)+(case when V162 is null then 0 else 1 end)+(case when V163 is null then 0 else 1 end)+(case when V164 is null then 0 else 1 end)+(case when V165 is null then 0 else 1 end)+(case when V166 is null then 0 else 1 end)+(case when V167 is null then 0 else 1 end)+(case when V168 is null then 0 else 1 end)+(case when V169 is null then 0 else 1 end)+(case when V170 is null then 0 else 1 end)+(case when V171 is null then 0 else 1 end)+(case when V172 is null then 0 else 1 end)+(case when V173 is null then 0 else 1 end)+(case when V174 is null then 0 else 1 end)+(case when V175 is null then 0 else 1 end)+(case when V176 is null then 0 else 1 end)+(case when V177 is null then 0 else 1 end)+(case when V178 is null then 0 else 1 end)+(case when V179 is null then 0 else 1 end)+(case when V180 is null then 0 else 1 end)+(case when V181 is null then 0 else 1 end)+(case when V182 is null then 0 else 1 end)+(case when V183 is null then 0 else 1 end)+(case when V184 is null then 0 else 1 end)+(case when V185 is null then 0 else 1 end)+(case when V186 is null then 0 else 1 end)+(case when V187 is null then 0 else 1 end)+(case when V188 is null then 0 else 1 end)+(case when V189 is null then 0 else 1 end)+(case when V190 is null then 0 else 1 end)+(case when V191 is null then 0 else 1 end)+(case when V192 is null then 0 else 1 end)+(case when V193 is null then 0 else 1 end)+(case when V194 is null then 0 else 1 end)+(case when V195 is null then 0 else 1 end)+(case when V196 is null then 0 else 1 end)+(case when V197 is null then 0 else 1 end)+(case when V198 is null then 0 else 1 end)+(case when V199 is null then 0 else 1 end)+(case when V200 is null then 0 else 1 end)+(case when V201 is null then 0 else 1 end)+(case when V202 is null then 0 else 1 end)+(case when V203 is null then 0 else 1 end)+(case when V204 is null then 0 else 1 end)+(case when V205 is null then 0 else 1 end)+(case when V206 is null then 0 else 1 end)+(case when V207 is null then 0 else 1 end)+(case when V208 is null then 0 else 1 end)+(case when V209 is null then 0 else 1 end)+(case when V210 is null then 0 else 1 end)+(case when V211 is null then 0 else 1 end)+(case when V212 is null then 0 else 1 end)+(case when V213 is null then 0 else 1 end)+(case when V214 is null then 0 else 1 end)+(case when V215 is null then 0 else 1 end)+(case when V216 is null then 0 else 1 end)+(case when V217 is null then 0 else 1 end)+(case when V218 is null then 0 else 1 end)+(case when V219 is null then 0 else 1 end)+(case when V220 is null then 0 else 1 end)+(case when V221 is null then 0 else 1 end)+(case when V222 is null then 0 else 1 end)+(case when V223 is null then 0 else 1 end)+(case when V224 is null then 0 else 1 end)+(case when V225 is null then 0 else 1 end)+(case when V226 is null then 0 else 1 end)+(case when V227 is null then 0 else 1 end)+(case when V228 is null then 0 else 1 end)+(case when V229 is null then 0 else 1 end)+(case when V230 is null then 0 else 1 end)+(case when V231 is null then 0 else 1 end)+(case when V232 is null then 0 else 1 end)+(case when V233 is null then 0 else 1 end)+(case when V234 is null then 0 else 1 end)+(case when V235 is null then 0 else 1 end)+(case when V236 is null then 0 else 1 end)+(case when V237 is null then 0 else 1 end)+(case when V238 is null then 0 else 1 end)+(case when V239 is null then 0 else 1 end)+(case when V240 is null then 0 else 1 end)+(case when V241 is null then 0 else 1 end)+(case when V242 is null then 0 else 1 end)+(case when V243 is null then 0 else 1 end)+(case when V244 is null then 0 else 1 end)+(case when V245 is null then 0 else 1 end)+(case when V246 is null then 0 else 1 end)+(case when V247 is null then 0 else 1 end)+(case when V248 is null then 0 else 1 end)+(case when V249 is null then 0 else 1 end)+(case when V250 is null then 0 else 1 end)+(case when V251 is null then 0 else 1 end)+(case when V252 is null then 0 else 1 end)+(case when V253 is null then 0 else 1 end)+(case when V254 is null then 0 else 1 end)+(case when V255 is null then 0 else 1 end) N15
						FROM #PanelSketch
					) t
				) t
		END

		-- Convert the sketch values into a list of patient_nums
		SELECT patient_num
			INTO #SamplePatientList
			FROM CRC.CQ2_SKETCH_PATIENT
			WHERE v IN (
				SELECT v
				FROM #PanelSketch
					CROSS APPLY (
						select 0 b, v0 v
						union all select 1 b, v1 union all select 2 b, v2 union all select 3 b, v3 union all select 4 b, v4 union all select 5 b, v5 union all select 6 b, v6 union all select 7 b, v7 union all select 8 b, v8 union all select 9 b, v9 union all select 10 b, v10 union all select 11 b, v11 union all select 12 b, v12 union all select 13 b, v13 union all select 14 b, v14 union all select 15 b, v15 union all select 16 b, v16 union all select 17 b, v17 union all select 18 b, v18 union all select 19 b, v19 union all select 20 b, v20 union all select 21 b, v21 union all select 22 b, v22 union all select 23 b, v23 union all select 24 b, v24 union all select 25 b, v25 union all select 26 b, v26 union all select 27 b, v27 union all select 28 b, v28 union all select 29 b, v29 union all select 30 b, v30 union all select 31 b, v31 union all select 32 b, v32 union all select 33 b, v33 union all select 34 b, v34 union all select 35 b, v35 union all select 36 b, v36 union all select 37 b, v37 union all select 38 b, v38 union all select 39 b, v39 union all select 40 b, v40 union all select 41 b, v41 union all select 42 b, v42 union all select 43 b, v43 union all select 44 b, v44 union all select 45 b, v45 union all select 46 b, v46 union all select 47 b, v47 union all select 48 b, v48 union all select 49 b, v49 union all select 50 b, v50 union all select 51 b, v51 union all select 52 b, v52 union all select 53 b, v53 union all select 54 b, v54 union all select 55 b, v55 union all select 56 b, v56 union all select 57 b, v57 union all select 58 b, v58 union all select 59 b, v59 union all select 60 b, v60 union all select 61 b, v61 union all select 62 b, v62 union all select 63 b, v63 union all select 64 b, v64 union all select 65 b, v65 union all select 66 b, v66 union all select 67 b, v67 union all select 68 b, v68 union all select 69 b, v69 union all select 70 b, v70 union all select 71 b, v71 union all select 72 b, v72 union all select 73 b, v73 union all select 74 b, v74 union all select 75 b, v75 union all select 76 b, v76 union all select 77 b, v77 union all select 78 b, v78 union all select 79 b, v79 union all select 80 b, v80 union all select 81 b, v81 union all select 82 b, v82 union all select 83 b, v83 union all select 84 b, v84 union all select 85 b, v85 union all select 86 b, v86 union all select 87 b, v87 union all select 88 b, v88 union all select 89 b, v89 union all select 90 b, v90 union all select 91 b, v91 union all select 92 b, v92 union all select 93 b, v93 union all select 94 b, v94 union all select 95 b, v95 union all select 96 b, v96 union all select 97 b, v97 union all select 98 b, v98 union all select 99 b, v99 union all select 100 b, v100 union all select 101 b, v101 union all select 102 b, v102 union all select 103 b, v103 union all select 104 b, v104 union all select 105 b, v105 union all select 106 b, v106 union all select 107 b, v107 union all select 108 b, v108 union all select 109 b, v109 union all select 110 b, v110 union all select 111 b, v111 union all select 112 b, v112 union all select 113 b, v113 union all select 114 b, v114 union all select 115 b, v115 union all select 116 b, v116 union all select 117 b, v117 union all select 118 b, v118 union all select 119 b, v119 union all select 120 b, v120 union all select 121 b, v121 union all select 122 b, v122 union all select 123 b, v123 union all select 124 b, v124 union all select 125 b, v125 union all select 126 b, v126 union all select 127 b, v127 union all select 128 b, v128 union all select 129 b, v129 union all select 130 b, v130 union all select 131 b, v131 union all select 132 b, v132 union all select 133 b, v133 union all select 134 b, v134 union all select 135 b, v135 union all select 136 b, v136 union all select 137 b, v137 union all select 138 b, v138 union all select 139 b, v139 union all select 140 b, v140 union all select 141 b, v141 union all select 142 b, v142 union all select 143 b, v143 union all select 144 b, v144 union all select 145 b, v145 union all select 146 b, v146 union all select 147 b, v147 union all select 148 b, v148 union all select 149 b, v149 union all select 150 b, v150 union all select 151 b, v151 union all select 152 b, v152 union all select 153 b, v153 union all select 154 b, v154 union all select 155 b, v155 union all select 156 b, v156 union all select 157 b, v157 union all select 158 b, v158 union all select 159 b, v159 union all select 160 b, v160 union all select 161 b, v161 union all select 162 b, v162 union all select 163 b, v163 union all select 164 b, v164 union all select 165 b, v165 union all select 166 b, v166 union all select 167 b, v167 union all select 168 b, v168 union all select 169 b, v169 union all select 170 b, v170 union all select 171 b, v171 union all select 172 b, v172 union all select 173 b, v173 union all select 174 b, v174 union all select 175 b, v175 union all select 176 b, v176 union all select 177 b, v177 union all select 178 b, v178 union all select 179 b, v179 union all select 180 b, v180 union all select 181 b, v181 union all select 182 b, v182 union all select 183 b, v183 union all select 184 b, v184 union all select 185 b, v185 union all select 186 b, v186 union all select 187 b, v187 union all select 188 b, v188 union all select 189 b, v189 union all select 190 b, v190 union all select 191 b, v191 union all select 192 b, v192 union all select 193 b, v193 union all select 194 b, v194 union all select 195 b, v195 union all select 196 b, v196 union all select 197 b, v197 union all select 198 b, v198 union all select 199 b, v199 union all select 200 b, v200 union all select 201 b, v201 union all select 202 b, v202 union all select 203 b, v203 union all select 204 b, v204 union all select 205 b, v205 union all select 206 b, v206 union all select 207 b, v207 union all select 208 b, v208 union all select 209 b, v209 union all select 210 b, v210 union all select 211 b, v211 union all select 212 b, v212 union all select 213 b, v213 union all select 214 b, v214 union all select 215 b, v215 union all select 216 b, v216 union all select 217 b, v217 union all select 218 b, v218 union all select 219 b, v219 union all select 220 b, v220 union all select 221 b, v221 union all select 222 b, v222 union all select 223 b, v223 union all select 224 b, v224 union all select 225 b, v225 union all select 226 b, v226 union all select 227 b, v227 union all select 228 b, v228 union all select 229 b, v229 union all select 230 b, v230 union all select 231 b, v231 union all select 232 b, v232 union all select 233 b, v233 union all select 234 b, v234 union all select 235 b, v235 union all select 236 b, v236 union all select 237 b, v237 union all select 238 b, v238 union all select 239 b, v239 union all select 240 b, v240 union all select 241 b, v241 union all select 242 b, v242 union all select 243 b, v243 union all select 244 b, v244 union all select 245 b, v245 union all select 246 b, v246 union all select 247 b, v247 union all select 248 b, v248 union all select 249 b, v249 union all select 250 b, v250 union all select 251 b, v251 union all select 252 b, v252 union all select 253 b, v253 union all select 254 b, v254 union all select 255 b, v255
					) v
				WHERE v.v IS NOT NULL
			)
		ALTER TABLE #SamplePatientList ADD PRIMARY KEY (patient_num)

		--select * from #SamplePatientList
		--select count(*) from #SamplePatientList

		-- Create a new panel containing the sampled patients, and set its estimated count to 1 to force it to be processed first
		INSERT INTO #panels (panel_number, panel_accuracy_scale, invert, panel_timing, total_item_occurrences, estimated_count, has_multiple_occurrences, has_date_constraint, has_date_range_constraint, has_modifier_constraint, has_value_constraint, has_complex_value_constraint, all_concept_paths, number_of_items, panel_table)
			SELECT max(panel_number)+1, 100 panel_accuracy_scale, 0 invert, 'ANY' panel_timing, 1 total_item_occurrences, 1 estimated_count, 0 has_multiple_occurrences, 0 has_date_constraint, 0 has_date_range_constraint, 0 has_modifier_constraint, 0 has_value_constraint, 0 has_complex_value_constraint, 0 all_concept_paths, 1 number_of_items, 'patient_dimension' panel_table
				FROM #panels
		-- Create an item in the new panel that points to the saved list of sampled patients
		INSERT INTO #items (panel_number, item_key, item_type, c_facttablecolumn, c_tablename, c_columnname, c_columndatatype, c_operator, c_dimcode, c_totalnum, valid)
			SELECT max(panel_number), 'sample', 'sample', 'patient_num', 'patient_dimension', 'patient_num', 'N', 'IN', '(SELECT patient_num FROM #SamplePatientList)', 1, 1
				FROM #panels

		--create table dbo.SketchList (patient_num int primary key)
		--delete from dbo.SketchList; insert into dbo.SketchList select * from #SamplePatientList

		--select * from #panels;
		--select * from #items;

		--return;

	END

	------------------------------------------------------------------------------
	-- Determine if CQ2 table alternatives can be used
	------------------------------------------------------------------------------

	IF @UseCQ2Tables = 1
	BEGIN
		UPDATE #Panels
			--SET panel_table = 'cq2_fact_counts_concept_patient'
			SET panel_table = 'cq2_fact_counts_path_patient'
			WHERE panel_timing = 'ANY'
				AND all_concept_paths = 1
				AND has_complex_value_constraint = 0
				AND has_date_range_constraint = 0
				AND has_modifier_constraint = 0
				AND (has_multiple_occurrences = 0 OR number_of_items = 1)
				AND (has_date_constraint + has_multiple_occurrences + has_value_constraint <= 1)
				AND panel_table = 'concept_dimension'
				AND @DebugEnableCQ2PathTables = 1
		UPDATE #Items
			SET c_tablename = 'CQ2_CONCEPT_PATH_CODE', c_columnname = 'CONCEPT_PATH_ID', c_operator = '=', c_dimcode = CAST(concept_path_id AS VARCHAR(50))
			WHERE concept_path_id IS NOT NULL AND c_facttablecolumn = 'concept_cd'
	END

	------------------------------------------------------------------------------
	-- Prepare to run the query
	------------------------------------------------------------------------------

	-- Determine if a temp table is needed
	SELECT @UseTempListTables = 1
	SELECT @UseTempListTables = 0
		WHERE (@ReturnPatientList = 0 AND @ReturnEncounterList = 0)
			AND ((SELECT COUNT(*) FROM #Panels) = 1)
			AND @DebugEnableAvoidTempListTables = 1

	-- Determine panel process order
	;WITH a AS (
		SELECT panel_number, estimated_count,
			ROW_NUMBER() OVER (ORDER BY	(CASE panel_timing WHEN 'ANY' THEN 1 WHEN 'SAMEVISIT' THEN 2 ELSE 3 END),
										invert,
										(CASE WHEN @DebugEnablePanelReorder = 1 THEN estimated_count ELSE 0 END)
										) k1,
			ROW_NUMBER() OVER (ORDER BY	(CASE panel_timing WHEN 'ANY' THEN 3 WHEN 'SAMEVISIT' THEN 2 ELSE 1 END),
										invert,
										(CASE WHEN @DebugEnablePanelReorder = 1 THEN estimated_count ELSE 0 END)
										) k2
		FROM #Panels
	), b AS (
		SELECT (SELECT estimated_count FROM a WHERE k1 = 1) e1, (SELECT estimated_count FROM a WHERE k2 = 1) e2
	)
	UPDATE p
		SET p.process_order = (CASE WHEN e1 <= e2 THEN k1 ELSE k2 END)
		FROM #Panels p, a, b
		WHERE p.panel_number = a.panel_number

	-- Get the panel timing for the last panel that was processed (important for join type)
	UPDATE p
		SET p.previous_panel_timing = q.panel_timing
		FROM #Panels p, #Panels q
		WHERE p.process_order = q.process_order + 1

	--SELECT 'P', * FROM #Panels
	--SELECT 'I', * FROM #Items
	--SELECT 'QueryTiming', @query_timing
	--return;

	/*
	UPDATE #Items
		SET c_tablename = 'CQ2_CONCEPT_PATH_CODE', c_columnname = 'CONCEPT_PATH_ID', c_operator = '=', c_dimcode = CAST(concept_path_id AS VARCHAR(50))
		WHERE concept_path_id IS NOT NULL AND c_facttablecolumn = 'concept_cd'
	*/
	--SELECT 'I2', * FROM #Items

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Run the query
	-- ***************************************************************************
	-- ***************************************************************************

	SELECT @p = 1, @MaxP = IsNull((SELECT MAX(process_order) FROM #Panels),0)
	WHILE @p <= @MaxP
	BEGIN
		------------------------------------------------------------
		-- Setup
		------------------------------------------------------------
		-- Initialize the timer
		SELECT @ProcessStartTime = GETDATE()
		-- Get panel variables
		SELECT	@panel_date_from = panel_date_from,
				@panel_date_to = panel_date_to,
				@panel_accuracy_scale = panel_accuracy_scale,
				@invert = invert,
				@panel_timing = panel_timing,
				@total_item_occurrences = total_item_occurrences,
				@has_date_constraint = has_date_constraint,
				@has_date_range_constraint = has_date_range_constraint,
				@has_modifier_constraint = has_modifier_constraint,
				@has_value_constraint = has_value_constraint,
				@number_of_items = number_of_items,
				@panel_table = panel_table,
				@previous_panel_timing = previous_panel_timing
			FROM #Panels
			WHERE process_order = @p

		SELECT @panel_temp_table = (CASE
										WHEN (ISNULL(@previous_panel_temp_table,'') = '#InstanceList') OR (@panel_timing = 'SAMEINSTANCENUM')
											THEN '#InstanceList'
										WHEN (ISNULL(@previous_panel_temp_table,'') = '#EncounterList') OR (@panel_timing = 'SAMEVISIT')
											THEN '#EncounterList'
										ELSE '#PatientList'
										END)

		SELECT @panel_temp_table_columns = (CASE @panel_temp_table
										WHEN '#InstanceList' THEN 'patient_num, encounter_num, concept_cd, start_date, instance_num, provider_id'
										WHEN '#EncounterList' THEN 'patient_num, encounter_num'
										ELSE 'patient_num' END)

		SELECT @join_to_temp = (CASE
									WHEN @previous_panel_temp_table IS NULL
										THEN ''
									ELSE ' INNER JOIN '+@previous_panel_temp_table+' p
												ON p.panels = '+CAST((@p-1) AS VARCHAR(50))+'
												AND f.patient_num = p.patient_num '
										+(CASE WHEN @panel_timing IN ('SAMEVISIT','SAMEINSTANCENUM')
													AND @previous_panel_temp_table IN ('#EncounterList','#InstanceList')
											THEN ' AND f.encounter_num = p.encounter_num '
											ELSE '' END)
										+(CASE WHEN @panel_timing = 'SAMEINSTANCENUM' AND @previous_panel_temp_table = '#InstanceList'
											THEN '
												AND f.concept_cd = p.concept_cd
												AND f.provider_id = p.provider_id
												AND f.start_date = p.start_date
												AND f.instance_num = p.instance_num
												'
											ELSE '' END)
									END)

		-- Initialize panel SQL
		SELECT @sql = ''
		------------------------------------------------------------
		-- Select the correct facts within the panel
		------------------------------------------------------------
		-- Select the query table
		IF (@panel_table = 'patient_dimension') AND (@panel_timing = 'ANY')
		BEGIN
			-- Handle item constraints
			SELECT @sql = @sql +' OR (f.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode+')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number
			-- Select patients
			SELECT @sql = 'SELECT f.patient_num
								FROM '+@Schema+'.patient_dimension f '+@join_to_temp+'
								WHERE 1=0 ' + @sql
		END
		ELSE IF (@panel_table = 'visit_dimension') AND (@panel_timing IN ('ANY','SAMEVISIT'))
		BEGIN
			-- Handle item constraints
			SELECT @sql = @sql +' OR ('
							+'f.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode
							+(CASE	WHEN p.panel_date_from IS NOT NULL
										THEN ' AND f.start_date >= ''' + CAST(p.panel_date_from AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN p.panel_date_to IS NOT NULL
										THEN ' AND f.start_date <= ''' + CAST(p.panel_date_to AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN i.date_from IS NOT NULL
										THEN ' AND f.start_date >= ''' + CAST(i.date_from AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN i.date_to IS NOT NULL
										THEN ' AND f.start_date <= ''' + CAST(i.date_to AS VARCHAR(50)) + ''''
									ELSE '' END)
							+')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number
			-- Select patients
			SELECT @sql = 'SELECT DISTINCT f.patient_num '
									+(CASE	WHEN @panel_timing = 'SAMEVISIT' 
												THEN ', f.encounter_num'
											ELSE '' END)+'
								FROM '+@Schema+'.visit_dimension f '+@join_to_temp+'
								WHERE 1=0 ' + @sql
		END
		ELSE IF (@panel_table = 'cq2_fact_counts_path_patient')
		BEGIN
			SELECT @sqlTemp1='', @sqlTemp2=''
			-- Handle item constraints (paths)
			SELECT @sqlTemp1 = @sqlTemp1 + ' OR ('
							+'f.concept_path_id = ' + CAST(i.concept_path_id AS NVARCHAR(50))
							+(CASE	WHEN i.value_type='NUMBER' AND i.value_operator IN ('<','<=')
									THEN ' AND f.min_nval_num '+i.value_operator+' '+i.value_constraint
									WHEN i.value_type='NUMBER' AND i.value_operator IN ('>','>=')
									THEN ' AND f.max_nval_num '+i.value_operator+' '+i.value_constraint
									ELSE '' END)
							+(CASE	WHEN i.date_from IS NOT NULL
									THEN ' AND f.last_start >= ''' + CAST(i.date_from AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN i.date_to IS NOT NULL
									THEN ' AND f.first_start <= ''' + CAST(i.date_to AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN @panel_date_from IS NOT NULL
									THEN ' AND f.last_start >= ''' + CAST(@panel_date_from AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN @panel_date_to IS NOT NULL
									THEN ' AND f.first_start <= ''' + CAST(@panel_date_to AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN @total_item_occurrences > 1
									THEN ' AND f.num_instances >= ' + CAST(@total_item_occurrences AS VARCHAR(50))
									ELSE '' END)
							+ ')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number AND i.concept_cd = ''
			-- Handle item constraints (concepts)
			SELECT @sqlTemp2 = @sqlTemp2 + ' OR ('
							+'f.concept_cd = ''' + REPLACE(i.concept_cd,'''','''''') + ''''
							+(CASE	WHEN i.value_type='NUMBER' AND i.value_operator IN ('<','<=')
									THEN ' AND f.min_nval_num '+i.value_operator+' '+i.value_constraint
									WHEN i.value_type='NUMBER' AND i.value_operator IN ('>','>=')
									THEN ' AND f.max_nval_num '+i.value_operator+' '+i.value_constraint
									ELSE '' END)
							+(CASE	WHEN i.date_from IS NOT NULL
									THEN ' AND f.last_start >= ''' + CAST(i.date_from AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN i.date_to IS NOT NULL
									THEN ' AND f.first_start <= ''' + CAST(i.date_to AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN @panel_date_from IS NOT NULL
									THEN ' AND f.last_start >= ''' + CAST(@panel_date_from AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN @panel_date_to IS NOT NULL
									THEN ' AND f.first_start <= ''' + CAST(@panel_date_to AS VARCHAR(50)) + ''''
									ELSE '' END)
							+(CASE	WHEN @total_item_occurrences > 1
									THEN ' AND f.num_instances >= ' + CAST(@total_item_occurrences AS VARCHAR(50))
									ELSE '' END)
							+ ')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number AND i.concept_cd <> ''
			-- Select patients
			SELECT @sql = 'SELECT DISTINCT f.patient_num
								FROM (
									SELECT f.patient_num
										FROM '+@Schema+'.cq2_fact_counts_path_patient f '+@join_to_temp+'
										WHERE (1=0 ' + @sqlTemp1 + ')
									UNION ALL
									SELECT f.patient_num
										FROM '+@Schema+'.cq2_fact_counts_concept_patient f '+@join_to_temp+'
										WHERE (1=0 ' + @sqlTemp2 + ')
								) f '
		END
		ELSE IF (@panel_table = 'cq2_fact_counts_concept_patient')  --TODO: This isn't fully implemented!
		BEGIN
			-- Handle item constraints
			SELECT @sql = @sql 
				+' OR ('
				+'	f.'+i.c_facttablecolumn+' IN ('
				+'	SELECT '+i.c_facttablecolumn
				+'		FROM '+@Schema+'.'+i.c_tablename+' t'
				+'		WHERE t.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode
				+'	)'
				+')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number
			-- Select patients
			SELECT @sql = 'SELECT DISTINCT f.patient_num
								FROM '+@Schema+'.cq2_fact_counts_concept_patient f '+@join_to_temp+'
								WHERE 1=0 ' + @sql
		END
		ELSE
		BEGIN
			-- Handle item constraints
			SELECT @sql = @sql 
				+' OR ('
				+'	f.'+i.c_facttablecolumn+' IN ('
				+'	SELECT '+i.c_facttablecolumn
				+'		FROM '+@Schema+'.'+i.c_tablename+' t'
				+'		WHERE t.'+i.c_columnname+' '+i.c_operator+' '+i.c_dimcode
				+'	)'
				+(CASE	WHEN IsNull(i.modifier_path,'') <> ''
							THEN ' AND f.'+i.m_facttablecolumn+' IN ('
									+'	SELECT '+i.m_facttablecolumn
									+'		FROM '+@Schema+'.'+i.m_tablename+' t'
									+'		WHERE t.'+i.m_columnname+' '+i.m_operator+' '+i.m_dimcode
									+')'
						ELSE '' END)
				+(CASE	WHEN (i.value_operator IS NULL) OR (i.value_constraint IS NULL)
							THEN ''
						WHEN i.value_type='TEXT'
							THEN ' AND f.tval_char '+i.value_operator+' '+i.value_constraint
						WHEN i.value_type='NUMBER'
							THEN ' AND f.nval_num '+i.value_operator+' '+i.value_constraint
						WHEN i.value_type='FLAG'
							THEN ' AND IsNull(f.valueflag_cd,''@'') '+i.value_operator+' '+i.value_constraint
						ELSE '' END)
				+(CASE	WHEN i.date_from IS NOT NULL
							THEN ' AND f.start_date >= ''' + CAST(i.date_from AS VARCHAR(50)) + ''''
						ELSE '' END)
				+(CASE	WHEN i.date_to IS NOT NULL
							THEN ' AND f.start_date <= ''' + CAST(i.date_to AS VARCHAR(50)) + ''''
						ELSE '' END)
				+(CASE	WHEN p.panel_date_from IS NOT NULL
							THEN ' AND f.start_date >= ''' + CAST(p.panel_date_from AS VARCHAR(50)) + ''''
						ELSE '' END)
				+(CASE	WHEN p.panel_date_to IS NOT NULL
							THEN ' AND f.start_date <= ''' + CAST(p.panel_date_to AS VARCHAR(50)) + ''''
						ELSE '' END)
				+')'
				FROM #Panels p, #Items i
				WHERE p.process_order = @p AND p.panel_number = i.panel_number
			-- Handle total_item_occurrences
			IF (@total_item_occurrences > 1) AND (@panel_timing = 'ANY')
				-- Multiple occurrences, ANY timing
				SELECT @sql = 'SELECT patient_num
									FROM (
										SELECT DISTINCT f.encounter_num, f.patient_num, f.concept_cd, f.provider_id, f.start_date, f.instance_num
											FROM '+@Schema+'.observation_fact f '+@join_to_temp+'
											WHERE 1=0 ' + @sql + '
									) t
									GROUP BY patient_num
									HAVING COUNT(*) >= '+CAST(@total_item_occurrences AS VARCHAR(50))
			ELSE IF (@total_item_occurrences > 1)
				-- Multiple occurrences, not ANY timing
				SELECT @sql = 'SELECT DISTINCT patient_num '
									+(CASE	WHEN @panel_timing = 'SAMEVISIT' 
												THEN ', encounter_num'
											WHEN @panel_timing = 'SAMEINSTANCENUM'
												THEN ', encounter_num, concept_cd, provider_id, start_date, instance_num'
											ELSE '' END)+'
									FROM (
										SELECT *, ROW_NUMBER() OVER (PARTITION BY patient_num ORDER BY patient_num) k
											FROM (
												SELECT DISTINCT f.encounter_num, f.patient_num, f.concept_cd, f.provider_id, f.start_date, f.instance_num
													FROM '+@Schema+'.observation_fact f '+@join_to_temp+'
													WHERE 1=0 ' + @sql + '
											) t
									) t
									WHERE k = '+CAST(@total_item_occurrences AS VARCHAR(50))
			ELSE
				-- Single occurrence
				SELECT @sql = 'SELECT DISTINCT f.patient_num '
									+(CASE	WHEN @panel_timing = 'SAMEVISIT' 
												THEN ', f.encounter_num'
											WHEN @panel_timing = 'SAMEINSTANCENUM'
												THEN ', f.encounter_num, f.concept_cd, f.provider_id, f.start_date, f.instance_num'
											ELSE '' END)+'
									FROM '+@Schema+'.observation_fact f '+@join_to_temp+'
									WHERE 1=0 ' + @sql
		END
		------------------------------------------------------------
		-- Combine panel with other panels
		------------------------------------------------------------
		IF @QueryMethod IN ('MINHASH8') -- AND (1=0)
			SELECT @PanelMaxdop = ' OPTION (MAXDOP 1) '
		ELSE
			SELECT @PanelMaxdop = ''

		SELECT @sql = (CASE WHEN @UseTempListTables = 0
							THEN 'INSERT INTO #QueryCounts (num_patients)
										SELECT COUNT(DISTINCT patient_num)
											FROM ('+@sql+') t' + @PanelMaxdop
								+'; UPDATE #Panels SET actual_count = (SELECT TOP 1 num_patients FROM #QueryCounts)'
							WHEN (@invert = 0) AND (ISNULL(@previous_panel_temp_table,'') <> @panel_temp_table)
							THEN 'INSERT INTO '+@panel_temp_table+' (panels, '+@panel_temp_table_columns+')'
								--+' SELECT 1, '+@panel_temp_table_columns
								+' SELECT '+CAST(@p AS VARCHAR(50))+', '+@panel_temp_table_columns
								+' FROM ('+@sql+') t' + @PanelMaxdop
								+'; UPDATE #Panels SET actual_count = @@ROWCOUNT WHERE process_order = '+CAST(@p AS VARCHAR(50))
								+(CASE	WHEN (@MaxP > @p)
										THEN '; ALTER TABLE '+@panel_temp_table+' ADD PRIMARY KEY (panels, '+@panel_temp_table_columns+')'
										ELSE ''
										END)
							ELSE 'SELECT * INTO #TempList FROM ('+@sql+') t ' + @PanelMaxdop + '; '
								+'UPDATE p '
								+' SET p.panels = '+CAST(@p AS VARCHAR(50))+' '
								+' FROM '+@previous_panel_temp_table+' p'
								+(CASE	WHEN @invert = 1
										THEN ' LEFT OUTER JOIN #TempList t '
										ELSE ' INNER JOIN #TempList t '
										END)
								+' ON p.patient_num = t.patient_num '
								+(CASE	WHEN @panel_timing IN ('SAMEVISIT','SAMEINSTANCENUM')
													AND @previous_panel_temp_table IN ('#EncounterList','#InstanceList')
										THEN ' AND p.encounter_num = t.encounter_num '
										ELSE ''
										END)
								+(CASE	WHEN @panel_timing = 'SAMEINSTANCENUM' AND @previous_panel_temp_table = '#InstanceList'
										THEN ' AND p.concept_cd = t.concept_cd 
												AND p.start_date = t.start_date 
												AND p.instance_num = t.instance_num 
												AND p.provider_id = t.provider_id '
										ELSE ''
										END)
								+'WHERE p.panels = '+CAST((@p-1) AS VARCHAR(50))+' '
								+(CASE	WHEN @invert = 1
										THEN 'AND t.patient_num IS NULL '
										ELSE ''
										END)
								+'; DROP TABLE #TempList'
								+'; UPDATE #Panels SET actual_count = @@ROWCOUNT WHERE process_order = '+CAST(@p AS VARCHAR(50))
							END)

		------------------------------------------------------------
		-- Process the SQL
		------------------------------------------------------------
		-- Run the panel sql
		--insert into dbo.x(s) select @sql
		UPDATE #Panels SET panel_sql = @sql WHERE process_order = @p
		EXEC sp_executesql @sql
		UPDATE #Panels SET run_time_ms = DATEDIFF(ms,@ProcessStartTime,GETDATE()) WHERE process_order = @p
		-- Move to the next panel
		SELECT @p = @p + 1
		SELECT @previous_panel_temp_table = @panel_temp_table
	END

	--insert into dbo.x(x) select 'RT = '+cast(run_time_ms as varchar(50)) from #Panels
	--SELECT 'PL', * FROM #PatientList
	--SELECT 'PP', * FROM #Panels
	--SELECT 'II', * FROM #Items
	--SELECT 'GG', patient_num FROM #GlobalPatientList WHERE query_master_id = 1

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Return the results
	-- ***************************************************************************
	-- ***************************************************************************

	IF (@ReturnPatientCount = 1 OR @ReturnEncounterCount = 1)
	BEGIN
		-- Declare the count variables
		DECLARE @NumPatients INT
		DECLARE @NumEncounters BIGINT
		DECLARE @NumInstances BIGINT
		DECLARE @NumFacts BIGINT
		-- Get values from the #QueryCounts table
		SELECT @NumPatients = num_patients, @NumEncounters = num_encounters, @NumInstances = num_instances, @NumFacts = num_facts
			FROM #QueryCounts
		-- Get number of patients
		IF (@ReturnPatientCount = 1) AND (@NumPatients IS NULL)
		BEGIN
			--insert into dbo.x(x) select 'PTT = '+@panel_temp_table;
			SELECT @NumPatients = (CASE @panel_temp_table
									WHEN '#InstanceList' THEN
										(SELECT COUNT(DISTINCT patient_num) FROM #InstanceList WHERE panels = @MaxP)
									WHEN '#EncounterList' THEN
										(SELECT COUNT(DISTINCT patient_num) FROM #EncounterList WHERE panels = @MaxP)
									ELSE
										(SELECT COUNT(*) FROM #PatientList WHERE panels = @MaxP)
									END)
		END
		-- Get number of encounters
		IF (@ReturnEncounterCount = 1) AND (@NumEncounters IS NULL)
		BEGIN
			SELECT @NumEncounters = (CASE @panel_temp_table
									WHEN '#InstanceList' THEN
										(SELECT COUNT_BIG(*) FROM (SELECT DISTINCT patient_num, encounter_num FROM #InstanceList WHERE panels = @MaxP) t)
									WHEN '#EncounterList' THEN
										(SELECT COUNT_BIG(*) FROM #EncounterList WHERE panels = @MaxP)
									ELSE
										(SELECT COUNT_BIG(*) FROM #PatientList p INNER JOIN ..VISIT_DIMENSION v ON p.patient_num = v.patient_num WHERE panels = @MaxP)
									END)
		END
		-- Adjust counts for sampling
		IF @QueryMethod in ('MINHASH8','MINHASH15')
		BEGIN
			SELECT @SketchPanelQ = @NumPatients
			SELECT @NumPatients = (CASE WHEN @SketchPanelN=0 THEN 0 ELSE floor(@SketchPanelE*(@NumPatients/cast(@SketchPanelN as float))+0.5) END)
			SELECT @SketchPanelM = (CASE WHEN @QueryMethod='MINHASH8' THEN 256 ELSE 32768 END)
		END
		-- Return counts
		INSERT INTO #GlobalQueryCounts (query_master_id, num_patients, num_encounters, num_instances, num_facts, sketch_e, sketch_n, sketch_q, sketch_m)
			SELECT @QueryMasterID, @NumPatients, @NumEncounters, @NumInstances, @NumFacts, @SketchPanelE, @SketchPanelN, @SketchPanelQ, @SketchPanelM

	END

	IF @ReturnPatientList = 1
	BEGIN
		IF @panel_temp_table = '#InstanceList'
			INSERT INTO #GlobalPatientList (query_master_id, patient_num)
				SELECT DISTINCT @QueryMasterID, patient_num FROM #InstanceList WHERE panels = @MaxP
		IF @panel_temp_table = '#EncounterList'
			INSERT INTO #GlobalPatientList (query_master_id, patient_num)
				SELECT DISTINCT @QueryMasterID, patient_num FROM #EncounterList WHERE panels = @MaxP
		IF @panel_temp_table = '#PatientList'
			INSERT INTO #GlobalPatientList (query_master_id, patient_num)
				SELECT @QueryMasterID, patient_num FROM #PatientList WHERE panels = @MaxP
	END

	IF @ReturnEncounterList = 1
	BEGIN
		IF @panel_temp_table = '#InstanceList'
			INSERT INTO #GlobalEncounterList (query_master_id, encounter_num, patient_num)
				SELECT DISTINCT @QueryMasterID, encounter_num, patient_num FROM #InstanceList WHERE panels = @MaxP
		IF @panel_temp_table = '#EncounterList'
			INSERT INTO #GlobalEncounterList (query_master_id, encounter_num, patient_num)
				SELECT @QueryMasterID, encounter_num, patient_num FROM #EncounterList WHERE panels = @MaxP
		IF @panel_temp_table = '#PatientList'
			INSERT INTO #GlobalEncounterList (query_master_id, encounter_num, patient_num)
				SELECT @QueryMasterID, v.encounter_num, v.patient_num 
					FROM #PatientList p INNER JOIN ..VISIT_DIMENSION v 
						ON p.patient_num = v.patient_num 
					WHERE panels = @MaxP
	END

	IF @QueryMasterID < 0
	BEGIN
		SELECT @SQL = 'SELECT f.*
						FROM '+@Schema+'.observation_fact f
							INNER JOIN '+@panel_temp_table+' t
								ON f.patient_num = t.patient_num '
					+(CASE @panel_temp_table
						WHEN '#EncounterList'
							THEN ' AND f.encounter_num = t.encounter_num '
						WHEN '#InstanceList'
							THEN ' AND f.encounter_num = t.encounter_num
								AND f.concept_cd = t.concept_cd 
								AND f.start_date = t.start_date 
								AND f.instance_num = t.instance_num 
								AND f.provider_id = t.provider_id '
						ELSE '' END)
		IF (@panel_temp_table = '#InstanceList') AND (@ReturnTemporalListEnd IS NULL)
			SELECT @SQL = 'SELECT * FROM #InstanceList'
		SELECT @SQL = ';WITH t AS ('+@SQL+') '
			+'INSERT INTO #GlobalTemporalList (subquery_id, patient_num, is_start, the_date) '
			+' SELECT 0, 0, 0, ''1/1/1900'' WHERE 1=0'
			+(CASE @ReturnTemporalListStart
				WHEN 'FIRST'	THEN ' UNION ALL SELECT '+CAST(@QueryMasterID AS VARCHAR(50))+', patient_num, 1, MIN(start_date) FROM t GROUP BY patient_num'
				WHEN 'LAST'		THEN ' UNION ALL SELECT '+CAST(@QueryMasterID AS VARCHAR(50))+', patient_num, 1, MAX(start_date) FROM t GROUP BY patient_num'
				WHEN 'ANY'		THEN ' UNION ALL SELECT DISTINCT '+CAST(@QueryMasterID AS VARCHAR(50))+', patient_num, 1, start_date FROM t'
				ELSE '' END)
			+(CASE @ReturnTemporalListEnd
				WHEN 'FIRST'	THEN ' UNION ALL SELECT '+CAST(@QueryMasterID AS VARCHAR(50))+', patient_num, 0, MIN(end_date) FROM t WHERE end_date IS NOT NULL GROUP BY patient_num'
				WHEN 'LAST'		THEN ' UNION ALL SELECT '+CAST(@QueryMasterID AS VARCHAR(50))+', patient_num, 0, MAX(end_date) FROM t WHERE end_date IS NOT NULL GROUP BY patient_num'
				WHEN 'ANY'		THEN ' UNION ALL SELECT DISTINCT '+CAST(@QueryMasterID AS VARCHAR(50))+', patient_num, 0, end_date FROM t WHERE end_date IS NOT NULL'
				ELSE '' END)
			+'; UPDATE #GlobalSubqueryList SET num_patients = @@ROWCOUNT WHERE subquery_id = '+CAST(@QueryMasterID AS VARCHAR(50))

		EXEC sp_executesql @sql
	END

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Display debugging information
	-- ***************************************************************************
	-- ***************************************************************************

	IF @DebugShowDetails = 1
	BEGIN
		SELECT 'Panels', * FROM #Panels
		SELECT 'Items', * FROM #Items
		SELECT	DateDiff(ms,@QueryStartTime,GetDate()) QueryTimeMS,
				@UseCQ2Tables UseCQ2Tables, 
				@UseCQ2SketchTables UseCQ2SketchTables, 
				@query_timing QueryTiming, 
				@UseTempListTables UseTempListTables,
				@UseEstimatedCountAsActual UseEstimatedCountAsActual,
				@DebugEnablePanelReorder DebugEnablePanelReorder,
				@DebugEnableCQ2Tables DebugEnableCQ2Tables,
				@DebugEnableCQ2PathTables DebugEnableCQ2PathTables,
				@DebugEnableAvoidTempListTables DebugEnableAvoidTempListTables,
				@DebugEnableEstimatedCountAsActual DebugEnableEstimatedCountAsActual
	END

END
GO
GO
CREATE PROCEDURE [CRC].[uspRunQueryInstanceSubquery]
	@QueryMasterID INT,
	@DomainID VARCHAR(50),
	@UserID VARCHAR(50),
	@ProjectID VARCHAR(50),
	@GetConstraints BIT = 0,
	@QueryDefinition XML = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	------------------------------------------------------------------------------
	-- Declare variables
	------------------------------------------------------------------------------

	DECLARE @QueryStartTime DATETIME
	SELECT @QueryStartTime = GETDATE()

	DECLARE @Schema VARCHAR(100)

	-- Get the schema
	SELECT @Schema = OBJECT_SCHEMA_NAME(@@PROCID)
	--SELECT @Schema = OBJECT_SCHEMA_NAME(187147712, DB_ID ( 'i2b2_demo' ) )
	DECLARE @uspRunQueryInstanceQM VARCHAR(100)
	SELECT @uspRunQueryInstanceQM = @Schema+'.uspRunQueryInstanceQM'


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Parse subquery constraints from query definition, then exit proc
	-- ***************************************************************************
	-- ***************************************************************************

	IF @GetConstraints = 1
	BEGIN

		-- Get subquery data
		INSERT INTO #GlobalSubqueryList(query_type,query_id,query_definition)
			SELECT x.value('subquery[1]/query_type[1]','VARCHAR(MAX)'), x.value('subquery[1]/query_id[1]','VARCHAR(MAX)'), x
			FROM (
				SELECT x.query('.') x
				FROM @QueryDefinition.nodes('query_definition[1]/subquery') AS R(x)
			) t

		-- Get subquery constraints
		INSERT INTO #GlobalSubqueryConstraintList (
				subquery_id1,join_column1,aggregate_operator1,
				operator,
				subquery_id2,join_column2,aggregate_operator2,
				span_operator1,span_value1,span_units1,
				span_operator2,span_value2,span_units2
			)
		SELECT	(SELECT subquery_id FROM #GlobalSubqueryList WHERE query_id = x.value('first_query[1]/query_id[1]','VARCHAR(MAX)')),
				x.value('first_query[1]/join_column[1]','VARCHAR(MAX)'),
				x.value('first_query[1]/aggregate_operator[1]','VARCHAR(MAX)'),
				x.value('operator[1]','VARCHAR(MAX)'),
				(SELECT subquery_id FROM #GlobalSubqueryList WHERE query_id = x.value('second_query[1]/query_id[1]','VARCHAR(MAX)')),
				x.value('second_query[1]/join_column[1]','VARCHAR(MAX)'),
				x.value('second_query[1]/aggregate_operator[1]','VARCHAR(MAX)'),
				x.value('span[1]/operator[1]','VARCHAR(MAX)'),
				x.value('span[1]/span_value[1]','INT'),
				x.value('span[1]/units[1]','VARCHAR(MAX)'),
				x.value('span[2]/operator[1]','VARCHAR(MAX)'),
				x.value('span[2]/span_value[1]','INT'),
				x.value('span[2]/units[1]','VARCHAR(MAX)')
		FROM (
			SELECT x.query('./*') x
			FROM @QueryDefinition.nodes('query_definition[1]/subquery_constraint') AS R(x)
		) t

		-- Validate subquery constraints
		DELETE 
			FROM #GlobalSubqueryConstraintList
			WHERE (subquery_id1 IS NULL) OR (ISNULL(join_column1,'') NOT IN ('STARTDATE','ENDDATE')) OR (ISNULL(aggregate_operator1,'') NOT IN ('FIRST','LAST','ANY'))
				OR (subquery_id2 IS NULL) OR (ISNULL(join_column2,'') NOT IN ('STARTDATE','ENDDATE')) OR (ISNULL(aggregate_operator2,'') NOT IN ('FIRST','LAST','ANY'))
				OR (ISNULL(operator,'') NOT IN ('LESS','LESSEQUAL','EQUAL','GREATEREQUAL','GREATER'))
		UPDATE #GlobalSubqueryConstraintList
			SET span_operator1 = NULL
			WHERE (ISNULL(span_operator1,'') NOT IN ('LESS','LESSEQUAL','EQUAL','GREATEREQUAL','GREATER'))
				OR (span_value1 IS NULL)
				OR (ISNULL(span_units1,'') NOT IN ('HOUR','DAY','MONTH','YEAR'))
		UPDATE #GlobalSubqueryConstraintList
			SET span_operator2 = NULL
			WHERE (ISNULL(span_operator2,'') NOT IN ('LESS','LESSEQUAL','EQUAL','GREATEREQUAL','GREATER'))
				OR (span_value2 IS NULL)
				OR (ISNULL(span_units2,'') NOT IN ('HOUR','DAY','MONTH','YEAR'))
		UPDATE #GlobalSubqueryConstraintList
			SET	operator = (CASE operator WHEN 'LESS' THEN '<' WHEN 'LESSEQUAL' THEN '<=' WHEN 'EQUAL' THEN '=' WHEN 'GREATEREQUAL' THEN '>=' WHEN 'GREATER' THEN '>' ELSE NULL END),
				span_operator1 = (CASE span_operator1 WHEN 'LESS' THEN '<' WHEN 'LESSEQUAL' THEN '<=' WHEN 'EQUAL' THEN '=' WHEN 'GREATEREQUAL' THEN '>=' WHEN 'GREATER' THEN '>' ELSE NULL END),
				span_operator2 = (CASE span_operator2 WHEN 'LESS' THEN '<' WHEN 'LESSEQUAL' THEN '<=' WHEN 'EQUAL' THEN '=' WHEN 'GREATEREQUAL' THEN '>=' WHEN 'GREATER' THEN '>' ELSE NULL END),
				span_units1 = (CASE span_units1 WHEN 'HOUR' THEN 'hh' WHEN 'DAY' THEN 'dd' WHEN 'MONTH' THEN 'mm' WHEN 'YEAR' THEN 'yy' ELSE NULL END),
				span_units2 = (CASE span_units2 WHEN 'HOUR' THEN 'hh' WHEN 'DAY' THEN 'dd' WHEN 'MONTH' THEN 'mm' WHEN 'YEAR' THEN 'yy' ELSE NULL END)

		-- Join each subquery to the initial results of the main query definition
		UPDATE a
			SET a.query_definition = (
				SELECT
					query_definition.query('subquery[1]/*'),
					CAST('<panel>
								<panel_number>-1</panel_number>
								<panel_accuracy_scale>100</panel_accuracy_scale>
								<invert>0</invert>
								<panel_timing>ANY</panel_timing>
								<total_item_occurrences>1</total_item_occurrences>
								<item>
									<item_key>masterid:'+CAST(@QueryMasterID AS VARCHAR(50))+'</item_key>
								</item>
							</panel>' AS XML)
				FROM #GlobalSubqueryList b
				WHERE a.subquery_id = b.subquery_id
				FOR XML PATH('query_definition'), TYPE
			)
			FROM #GlobalSubqueryList a

		-- Exit the proc
		RETURN

	END

	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Apply the subquery constraints
	-- ***************************************************************************
	-- ***************************************************************************

	------------------------------------------------------------------------------
	-- Declare variables
	------------------------------------------------------------------------------

	DECLARE @subquery_id INT
	DECLARE @ReturnTemporalListStart VARCHAR(50)
	DECLARE @ReturnTemporalListEnd VARCHAR(50)

	DECLARE @i INT
	DECLARE @MaxI INT

	DECLARE @sql NVARCHAR(MAX)

	CREATE TABLE #ConstraintPatient (
		constraint_id INT NOT NULL,
		patient_num INT NOT NULL
	)

	CREATE TABLE #CombinedConstraintPatient (
		patient_num INT NOT NULL
	)

	------------------------------------------------------------------------------
	-- Run each subquery
	------------------------------------------------------------------------------

	SELECT @MaxI = ISNULL((SELECT MIN(subquery_id) FROM #GlobalSubqueryList),0)
	SELECT @i = -1
	WHILE (@i >= @MaxI)
	BEGIN
		IF EXISTS (SELECT * FROM #GlobalSubqueryConstraintList WHERE subquery_id1 = @i OR subquery_id2 = @i)
		BEGIN
			-- Determine if start/end and first/any/last dates need to be returned
			SELECT @ReturnTemporalListStart = NULL, @ReturnTemporalListEnd = NULL
			;WITH a AS (
				SELECT	MAX(CASE WHEN (subquery_id1 = @i AND join_column1 = 'STARTDATE' AND aggregate_operator1 = 'ANY')
									OR (subquery_id2 = @i AND join_column2 = 'STARTDATE' AND aggregate_operator2 = 'ANY')
									THEN 1 ELSE 0 END) Start_Any,
						MAX(CASE WHEN (subquery_id1 = @i AND join_column1 = 'STARTDATE' AND aggregate_operator1 = 'FIRST')
									OR (subquery_id2 = @i AND join_column2 = 'STARTDATE' AND aggregate_operator2 = 'FIRST')
									THEN 1 ELSE 0 END) Start_First,
						MAX(CASE WHEN (subquery_id1 = @i AND join_column1 = 'STARTDATE' AND aggregate_operator1 = 'LAST')
									OR (subquery_id2 = @i AND join_column2 = 'STARTDATE' AND aggregate_operator2 = 'LAST')
									THEN 1 ELSE 0 END) Start_Last,
						MAX(CASE WHEN (subquery_id1 = @i AND join_column1 = 'ENDDATE' AND aggregate_operator1 = 'ANY')
									OR (subquery_id2 = @i AND join_column2 = 'ENDDATE' AND aggregate_operator2 = 'ANY')
									THEN 1 ELSE 0 END) End_Any,
						MAX(CASE WHEN (subquery_id1 = @i AND join_column1 = 'ENDDATE' AND aggregate_operator1 = 'FIRST')
									OR (subquery_id2 = @i AND join_column2 = 'ENDDATE' AND aggregate_operator2 = 'FIRST')
									THEN 1 ELSE 0 END) End_First,
						MAX(CASE WHEN (subquery_id1 = @i AND join_column1 = 'ENDDATE' AND aggregate_operator1 = 'LAST')
									OR (subquery_id2 = @i AND join_column2 = 'ENDDATE' AND aggregate_operator2 = 'LAST')
									THEN 1 ELSE 0 END) End_Last
					FROM #GlobalSubqueryConstraintList
			)
			SELECT	@ReturnTemporalListStart =
						(CASE	WHEN Start_Any = 1 THEN 'ANY'
								WHEN Start_First + Start_Last > 1 THEN 'ANY'
								WHEN Start_First > 0 THEN 'FIRST'
								WHEN Start_Last > 0 THEN 'LAST'
								END),
					@ReturnTemporalListEnd =
						(CASE	WHEN End_Any = 1 THEN 'ANY'
								WHEN End_First + End_Last > 1 THEN 'ANY'
								WHEN End_First > 0 THEN 'FIRST'
								WHEN End_Last > 0 THEN 'LAST'
								END)
				FROM a

			-- Run the subquery
			EXEC @uspRunQueryInstanceQM
				@QueryMasterID = @i,
				@DomainID = @DomainID,
				@UserID = @UserID,
				@ProjectID = @ProjectID,
				@ReturnTemporalListStart = @ReturnTemporalListStart,
				@ReturnTemporalListEnd = @ReturnTemporalListEnd
				
		END
		SELECT @i = @i - 1
	END

	------------------------------------------------------------------------------
	-- Determine the patients who pass each constraint
	------------------------------------------------------------------------------

	SELECT @MaxI = ISNULL((SELECT MAX(constraint_id) FROM #GlobalSubqueryConstraintList),0)
	SELECT @i = 1
	WHILE (@i <= @MaxI)
	BEGIN
		SELECT @SQL = 
			';WITH a AS ('
			+'SELECT patient_num, '
			+(CASE aggregate_operator1 WHEN 'FIRST' THEN 'MIN(the_date)' WHEN 'LAST' THEN 'MAX(the_date)' ELSE '' END)
			+' the_date '
			+' FROM #GlobalTemporalList '
			+' WHERE subquery_id = '+CAST(subquery_id1 AS VARCHAR(50))
			+' AND is_start = '+(CASE WHEN join_column1 = 'STARTDATE' THEN '1' ELSE '0' END)
			+(CASE aggregate_operator1 WHEN 'ANY' THEN '' ELSE ' GROUP BY patient_num ' END)
			+'), b AS ('
			+'SELECT patient_num, '
			+(CASE aggregate_operator2 WHEN 'FIRST' THEN 'MIN(the_date)' WHEN 'LAST' THEN 'MAX(the_date)' ELSE '' END)
			+' the_date '
			+' FROM #GlobalTemporalList '
			+' WHERE subquery_id = '+CAST(subquery_id2 AS VARCHAR(50))
			+' AND is_start = '+(CASE WHEN join_column2 = 'STARTDATE' THEN '1' ELSE '0' END)
			+(CASE aggregate_operator2 WHEN 'ANY' THEN '' ELSE ' GROUP BY patient_num ' END)
			+')'
			+'INSERT INTO #ConstraintPatient(constraint_id,patient_num) '
			+' SELECT DISTINCT '+CAST(constraint_id AS VARCHAR(50))+', a.patient_num '
			+' FROM a INNER JOIN b ON a.patient_num = b.patient_num '
			+' WHERE a.the_date '+operator+' b.the_date'
			+(CASE	WHEN span_operator1 IS NOT NULL AND operator IN ('<','<=','=')
					THEN ' AND DATEDIFF('+span_units1+',a.the_date,b.the_date) '+span_operator1+' '+CAST(span_value1 AS VARCHAR(50))
					WHEN span_operator1 IS NOT NULL AND operator IN ('>','>=')
					THEN ' AND DATEDIFF('+span_units1+',b.the_date,a.the_date) '+span_operator1+' '+CAST(span_value1 AS VARCHAR(50))
					ELSE '' END)
			+(CASE	WHEN span_operator2 IS NOT NULL AND operator IN ('<','<=','=')
					THEN ' AND DATEDIFF('+span_units2+',a.the_date,b.the_date) '+span_operator2+' '+CAST(span_value2 AS VARCHAR(50))
					WHEN span_operator2 IS NOT NULL AND operator IN ('>','>=')
					THEN ' AND DATEDIFF('+span_units2+',b.the_date,a.the_date) '+span_operator2+' '+CAST(span_value2 AS VARCHAR(50))
					ELSE '' END)
			FROM #GlobalSubqueryConstraintList
			WHERE constraint_id = @i

		EXEC sp_executesql @sql

		UPDATE #GlobalSubqueryConstraintList
			SET constraint_sql = @sql, num_patients = @@ROWCOUNT
			WHERE constraint_id = @i

		SELECT @i = @i + 1
	END

	------------------------------------------------------------------------------
	-- Get patients who pass all constraints
	------------------------------------------------------------------------------

	INSERT INTO #CombinedConstraintPatient
		SELECT patient_num
		FROM #ConstraintPatient
		GROUP BY patient_num
		HAVING COUNT(*) = @MaxI

	ALTER TABLE #CombinedConstraintPatient ADD PRIMARY KEY (patient_num)

	------------------------------------------------------------------------------
	-- Delete patients who do not pass all constraints
	------------------------------------------------------------------------------

	DELETE FROM #GlobalPatientList WHERE query_master_id = @QueryMasterID AND patient_num NOT IN (SELECT patient_num FROM #CombinedConstraintPatient)
	DELETE FROM #GlobalEncounterList WHERE query_master_id = @QueryMasterID AND patient_num NOT IN (SELECT patient_num FROM #CombinedConstraintPatient)
	DELETE FROM #GlobalInstanceList WHERE query_master_id = @QueryMasterID AND patient_num NOT IN (SELECT patient_num FROM #CombinedConstraintPatient)

	UPDATE #GlobalQueryCounts
		SET	num_patients = (SELECT COUNT(*) FROM #GlobalPatientList WHERE query_master_id = @QueryMasterID),
			num_encounters = (SELECT COUNT(*) FROM #GlobalEncounterList WHERE query_master_id = @QueryMasterID),
			num_instances = (SELECT COUNT(*) FROM #GlobalInstanceList WHERE query_master_id = @QueryMasterID)
		WHERE query_master_id = @QueryMasterID


	-- SELECT * FROM #CombinedConstraintPatient

END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateAllSteps]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	EXEC [CRC].[uspUpdateStep1CreateDataTables];
	EXEC [CRC].[uspUpdateStep2LoadDataTables];
	EXEC [CRC].[uspUpdateStep3IndexDataTables];
	EXEC [CRC].[uspUpdateStep4CreateCQ2Tables];
	EXEC [CRC].[uspUpdateStep5SwapTables];
	EXEC [CRC].[uspUpdateStep6DropOldTables];

END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateStep1CreateDataTables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- **********************************************************
	-- **********************************************************
	-- **** Create new tables
	-- **********************************************************
	-- **********************************************************

	CREATE TABLE [CRC].[PATIENT_DIMENSION_NEW](
		[PATIENT_NUM] [int] NOT NULL,
		[VITAL_STATUS_CD] [varchar](50) NULL,
		[BIRTH_DATE] [datetime] NULL,
		[DEATH_DATE] [datetime] NULL,
		[SEX_CD] [varchar](50) NULL,
		[AGE_IN_YEARS_NUM] [int] NULL,
		[LANGUAGE_CD] [varchar](50) NULL,
		[RACE_CD] [varchar](50) NULL,
		[MARITAL_STATUS_CD] [varchar](50) NULL,
		[RELIGION_CD] [varchar](50) NULL,
		[ZIP_CD] [varchar](10) NULL,
		[STATECITYZIP_PATH] [varchar](700) NULL,
		[INCOME_CD] [varchar](50) NULL,
		[PATIENT_BLOB] [varchar](max) NULL,
		[UPDATE_DATE] [datetime] NULL,
		[DOWNLOAD_DATE] [datetime] NULL,
		[IMPORT_DATE] [datetime] NULL,
		[SOURCESYSTEM_CD] [varchar](50) NULL,
		[UPLOAD_ID] [int] NULL
	)

	CREATE TABLE [CRC].[VISIT_DIMENSION_NEW](
		[ENCOUNTER_NUM] [int] NOT NULL,
		[PATIENT_NUM] [int] NOT NULL,
		[ACTIVE_STATUS_CD] [varchar](50) NULL,
		[START_DATE] [datetime] NULL,
		[END_DATE] [datetime] NULL,
		[INOUT_CD] [varchar](50) NULL,
		[LOCATION_CD] [varchar](50) NULL,
		[LOCATION_PATH] [varchar](900) NULL,
		[LENGTH_OF_STAY] [int] NULL,
		[VISIT_BLOB] [varchar](max) NULL,
		[UPDATE_DATE] [datetime] NULL,
		[DOWNLOAD_DATE] [datetime] NULL,
		[IMPORT_DATE] [datetime] NULL,
		[SOURCESYSTEM_CD] [varchar](50) NULL,
		[UPLOAD_ID] [int] NULL
	)

	CREATE TABLE [CRC].[OBSERVATION_FACT_NEW](
		[ENCOUNTER_NUM] [int] NOT NULL,
		[PATIENT_NUM] [int] NOT NULL,
		[CONCEPT_CD] [varchar](50) NOT NULL,
		[PROVIDER_ID] [varchar](50) NOT NULL,
		[START_DATE] [datetime] NOT NULL,
		[MODIFIER_CD] [varchar](100) NOT NULL,
		[INSTANCE_NUM] [int] NOT NULL,
		[VALTYPE_CD] [varchar](50) NULL,
		[TVAL_CHAR] [varchar](255) NULL,
		[NVAL_NUM] [decimal](18, 5) NULL,
		[VALUEFLAG_CD] [varchar](50) NULL,
		[QUANTITY_NUM] [decimal](18, 5) NULL,
		[UNITS_CD] [varchar](50) NULL,
		[END_DATE] [datetime] NULL,
		[LOCATION_CD] [varchar](50) NULL,
		[OBSERVATION_BLOB] [varchar](max) NULL,
		[CONFIDENCE_NUM] [decimal](18, 5) NULL,
		[UPDATE_DATE] [datetime] NULL,
		[DOWNLOAD_DATE] [datetime] NULL,
		[IMPORT_DATE] [datetime] NULL,
		[SOURCESYSTEM_CD] [varchar](50) NULL,
		[UPLOAD_ID] [int] NULL,
		[TEXT_SEARCH_INDEX] [int] NULL
	)
	ALTER TABLE [CRC].[OBSERVATION_FACT_NEW] ADD DEFAULT ('@') FOR [MODIFIER_CD]
	ALTER TABLE [CRC].[OBSERVATION_FACT_NEW] ADD DEFAULT ((1)) FOR [INSTANCE_NUM]

	CREATE TABLE [CRC].[CONCEPT_DIMENSION_NEW](
		[CONCEPT_PATH] [varchar](700) NOT NULL,
		[CONCEPT_CD] [varchar](50) NULL,
		[NAME_CHAR] [varchar](2000) NULL,
		[CONCEPT_BLOB] [varchar](max) NULL,
		[UPDATE_DATE] [datetime] NULL,
		[DOWNLOAD_DATE] [datetime] NULL,
		[IMPORT_DATE] [datetime] NULL,
		[SOURCESYSTEM_CD] [varchar](50) NULL,
		[UPLOAD_ID] [int] NULL
	)


END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateStep2LoadDataTables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- **********************************************************
	-- **********************************************************
	-- **** Load tables (Customize for your ETL...)
	-- **********************************************************
	-- **********************************************************

	INSERT INTO [CRC].[PATIENT_DIMENSION_NEW] WITH (TABLOCK)
		SELECT * FROM [CRC].[PATIENT_DIMENSION] WITH (NOLOCK)

	INSERT INTO [CRC].[VISIT_DIMENSION_NEW] WITH (TABLOCK)
		SELECT * FROM [CRC].[VISIT_DIMENSION] WITH (NOLOCK)

	INSERT INTO [CRC].[OBSERVATION_FACT_NEW] WITH (TABLOCK)
		SELECT * FROM [CRC].[OBSERVATION_FACT] WITH (NOLOCK)

	INSERT INTO [CRC].[CONCEPT_DIMENSION_NEW] WITH (TABLOCK)
		SELECT * FROM [CRC].[CONCEPT_DIMENSION] WITH (NOLOCK)


END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateStep3IndexDataTables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- **********************************************************
	-- **********************************************************
	-- **** Add primary keys and indexes
	-- **********************************************************
	-- **********************************************************

	-- PATIENT_DIMENSION
	ALTER TABLE [CRC].[PATIENT_DIMENSION_NEW] ADD PRIMARY KEY (PATIENT_NUM) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE NONCLUSTERED COLUMNSTORE INDEX [CQ2_CSIDX_AllColumns] ON [CRC].[PATIENT_DIMENSION_NEW] (PATIENT_NUM, VITAL_STATUS_CD, BIRTH_DATE, DEATH_DATE, SEX_CD, AGE_IN_YEARS_NUM, LANGUAGE_CD, RACE_CD, MARITAL_STATUS_CD, RELIGION_CD, ZIP_CD, STATECITYZIP_PATH, INCOME_CD, SOURCESYSTEM_CD)

	-- VISIT_DIMENSION
	ALTER TABLE [CRC].[VISIT_DIMENSION_NEW] ADD PRIMARY KEY (PATIENT_NUM, ENCOUNTER_NUM) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE NONCLUSTERED COLUMNSTORE INDEX [CQ2_CSIDX_AllColumns] ON [CRC].[VISIT_DIMENSION_NEW] (ENCOUNTER_NUM, PATIENT_NUM, ACTIVE_STATUS_CD, START_DATE, END_DATE, INOUT_CD, LOCATION_CD, LOCATION_PATH, LENGTH_OF_STAY, SOURCESYSTEM_CD)

	-- OBSERVATION_FACT
	ALTER TABLE [CRC].[OBSERVATION_FACT_NEW] ADD PRIMARY KEY (CONCEPT_CD, PATIENT_NUM, ENCOUNTER_NUM, START_DATE, MODIFIER_CD, PROVIDER_ID, INSTANCE_NUM) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE NONCLUSTERED INDEX CQ2_IDX_Patient_Concept ON [CRC].[OBSERVATION_FACT_NEW] (PATIENT_NUM, CONCEPT_CD) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE NONCLUSTERED COLUMNSTORE INDEX [CQ2_CSIDX_AllColumns] ON [CRC].[OBSERVATION_FACT_NEW] (ENCOUNTER_NUM, PATIENT_NUM, CONCEPT_CD, PROVIDER_ID, START_DATE, MODIFIER_CD, INSTANCE_NUM, VALTYPE_CD, TVAL_CHAR, NVAL_NUM, VALUEFLAG_CD, UNITS_CD, END_DATE, LOCATION_CD, SOURCESYSTEM_CD)

	-- CONCEPT_DIMENSION
	ALTER TABLE [CRC].[CONCEPT_DIMENSION_NEW] ADD PRIMARY KEY (CONCEPT_PATH)


END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateStep4CreateCQ2Tables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- **********************************************************
	-- **********************************************************
	-- **** Load ontology
	-- **********************************************************
	-- **********************************************************

	-------------------------------------------------------------
	-- Get ontology paths and assign numeric IDs
	-------------------------------------------------------------

	-- Get a list of paths from the ontology
	SELECT DISTINCT ISNULL(C_FULLNAME,'') C_FULLNAME
		INTO #Paths
		FROM CRC.vwCQ2_Ontology
	ALTER TABLE #Paths ADD PRIMARY KEY (C_FULLNAME)

	-- Get a list of path parents
	;WITH a AS (
		SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9
	), n AS (
		SELECT a.n+10*b.n+100*c.n n FROM a, a b, a c
	)
	SELECT C_FULLNAME, ISNULL(n,0) PATH_LENGTH, ISNULL(LEFT(C_FULLNAME,n+2),'') PARENT_PATH
		INTO #PathParents
		FROM (
			SELECT C_FULLNAME, n
			FROM #Paths, n
			WHERE n.n <= LEN(C_FULLNAME)
		) t
		WHERE SUBSTRING(C_FULLNAME,n+2,1)='\'
	ALTER TABLE #PathParents ADD PRIMARY KEY (C_FULLNAME,PATH_LENGTH)

	-- Generate path IDs
	CREATE TABLE #CRC_CQ2_CONCEPT_PATH (
		CONCEPT_PATH_ID INT NOT NULL,
		C_FULLNAME VARCHAR(700) NOT NULL,
		NUM_CONCEPTS INT NOT NULL,
		CONCEPT_CD VARCHAR(50) NOT NULL,
		SUBTREE_END_ID INT NOT NULL
	)
	;WITH a AS (
		SELECT ROW_NUMBER() OVER (ORDER BY C_FULLNAME) CONCEPT_PATH_ID, C_FULLNAME
		FROM #Paths
	), b AS (
		SELECT p.PARENT_PATH, MAX(a.CONCEPT_PATH_ID) SUBTREE_END_ID
		FROM #PathParents p
			INNER JOIN a ON p.C_FULLNAME=a.C_FULLNAME
		GROUP BY p.PARENT_PATH
	)
	INSERT INTO #CRC_CQ2_CONCEPT_PATH WITH (TABLOCK)
		SELECT a.CONCEPT_PATH_ID, a.C_FULLNAME, 0, '', ISNULL(b.SUBTREE_END_ID,a.CONCEPT_PATH_ID)
		FROM a LEFT OUTER JOIN b ON a.C_FULLNAME=b.PARENT_PATH
	ALTER TABLE #CRC_CQ2_CONCEPT_PATH ADD PRIMARY KEY (C_FULLNAME)

	-------------------------------------------------------------
	-- Get concepts mapping to each ontology path
	-------------------------------------------------------------

	-- Lookup path concepts
	;WITH a AS (
		SELECT DISTINCT p.PARENT_PATH, c.CONCEPT_CD
		FROM CRC.vwCQ2_ConceptDimension c
			INNER JOIN #PathParents p
				ON c.CONCEPT_PATH=p.C_FULLNAME
	)
	SELECT b.CONCEPT_PATH_ID, b.C_FULLNAME, ISNULL(a.CONCEPT_CD,'') CONCEPT_CD
		INTO #CRC_CQ2_CONCEPT_PATH_CODE
		FROM a INNER JOIN #CRC_CQ2_CONCEPT_PATH b
			ON a.PARENT_PATH=b.C_FULLNAME
		WHERE b.CONCEPT_CD IS NOT NULL
	ALTER TABLE #CRC_CQ2_CONCEPT_PATH_CODE ADD PRIMARY KEY (C_FULLNAME, CONCEPT_CD)

	-- Update the path IDs with the number of concepts
	;WITH a AS (
		SELECT C_FULLNAME, COUNT(*) NUM_CONCEPTS, MAX(CONCEPT_CD) CONCEPT_CD
		FROM #CRC_CQ2_CONCEPT_PATH_CODE
		GROUP BY C_FULLNAME
	)
	UPDATE p
		SET p.NUM_CONCEPTS=a.NUM_CONCEPTS, p.CONCEPT_CD=(CASE WHEN a.NUM_CONCEPTS=1 THEN a.CONCEPT_CD ELSE '' END)
		FROM #CRC_CQ2_CONCEPT_PATH p
			INNER JOIN a
				ON p.C_FULLNAME=a.C_FULLNAME

	-------------------------------------------------------------
	-- Create the tables
	-------------------------------------------------------------
				
	-- Save CQ2_CONCEPT_PATH
	CREATE TABLE [CRC].[CQ2_CONCEPT_PATH_NEW] (
		CONCEPT_PATH_ID INT NOT NULL,
		C_FULLNAME VARCHAR(700) NOT NULL,
		NUM_CONCEPTS INT NOT NULL,
		CONCEPT_CD VARCHAR(50) NOT NULL,
		SUBTREE_END_ID INT NOT NULL
	)
	INSERT INTO [CRC].[CQ2_CONCEPT_PATH_NEW]
		SELECT CONCEPT_PATH_ID, C_FULLNAME, NUM_CONCEPTS, CONCEPT_CD, SUBTREE_END_ID
		FROM #CRC_CQ2_CONCEPT_PATH
	ALTER TABLE [CRC].[CQ2_CONCEPT_PATH_NEW] ADD PRIMARY KEY (CONCEPT_PATH_ID)
	CREATE UNIQUE NONCLUSTERED INDEX IDX_FULLNAME ON CRC.CQ2_CONCEPT_PATH_NEW (C_FULLNAME)
	CREATE NONCLUSTERED INDEX IDX_CONCEPT ON CRC.CQ2_CONCEPT_PATH_NEW (CONCEPT_CD)

	-- Save CQ2_CONCEPT_PATH_CODE
	CREATE TABLE [CRC].[CQ2_CONCEPT_PATH_CODE_NEW] (
		CONCEPT_PATH_ID INT NOT NULL,
		C_FULLNAME VARCHAR(700) NOT NULL,
		CONCEPT_CD VARCHAR(50) NOT NULL
	)
	INSERT INTO [CRC].[CQ2_CONCEPT_PATH_CODE_NEW] WITH (TABLOCK)
		SELECT CONCEPT_PATH_ID, C_FULLNAME, CONCEPT_CD
		FROM #CRC_CQ2_CONCEPT_PATH_CODE
	ALTER TABLE [CRC].[CQ2_CONCEPT_PATH_CODE_NEW] ADD PRIMARY KEY (CONCEPT_PATH_ID, CONCEPT_CD)
	CREATE UNIQUE NONCLUSTERED INDEX IDX_CONCEPT_CD_PATH_ID ON CRC.CQ2_CONCEPT_PATH_CODE_NEW (CONCEPT_CD, CONCEPT_PATH_ID)
	CREATE UNIQUE NONCLUSTERED INDEX IDX_FULLNAME_CONCEPT ON CRC.CQ2_CONCEPT_PATH_CODE_NEW (C_FULLNAME, CONCEPT_CD)

	-- Drop temp tables
	DROP TABLE #Paths
	DROP TABLE #PathParents
	DROP TABLE #CRC_CQ2_CONCEPT_PATH
	DROP TABLE #CRC_CQ2_CONCEPT_PATH_CODE

	-- **********************************************************
	-- **********************************************************
	-- **** Ontology concept (leaf) rollup
	-- **********************************************************
	-- **********************************************************

	-------------------------------------------------------------
	-- Fact counts by concept and patient
	-------------------------------------------------------------

	CREATE TABLE [CRC].[CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW] (
		CONCEPT_CD VARCHAR(50) NOT NULL,
		PATIENT_NUM INT NOT NULL,
		NUM_ENCOUNTERS INT,
		NUM_INSTANCES INT,
		NUM_FACTS INT,
		FIRST_START DATETIME,
		LAST_START DATETIME,
		LAST_END DATETIME,
		MIN_NVAL_NUM DECIMAL(18, 5),
		MAX_NVAL_NUM DECIMAL(18, 5),
		MIN_NVAL_L BIT,
		MAX_NVAL_G BIT
	)
	;WITH a AS (
		SELECT CONCEPT_CD,				
			PATIENT_NUM,
			ENCOUNTER_NUM,
			START_DATE,
			PROVIDER_ID,
			INSTANCE_NUM,
			COUNT(*) NUM_FACTS,
			MIN(START_DATE) FIRST_START,
			MAX(START_DATE) LAST_START,
			MAX(END_DATE) LAST_END,
			MIN(NVAL_NUM) MIN_NVAL_NUM,
			MAX(NVAL_NUM) MAX_NVAL_NUM,
			MAX(CASE WHEN VALTYPE_CD='N' AND TVAL_CHAR IN ('L','LE','NE') THEN 1 ELSE 0 END) MIN_NVAL_L,
			MAX(CASE WHEN VALTYPE_CD='N' AND TVAL_CHAR IN ('G','GE','NE') THEN 1 ELSE 0 END) MAX_NVAL_G
		FROM CRC.OBSERVATION_FACT_NEW
		GROUP BY CONCEPT_CD, PATIENT_NUM, ENCOUNTER_NUM, START_DATE, PROVIDER_ID, INSTANCE_NUM
	)
	INSERT INTO [CRC].[CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW] WITH (TABLOCK)
		SELECT CONCEPT_CD,
			PATIENT_NUM,
			COUNT(DISTINCT ENCOUNTER_NUM) NUM_ENCOUNTERS,
			COUNT(*) NUM_INSTANCES,
			SUM(NUM_FACTS) NUM_FACTS,
			MIN(FIRST_START) FIRST_START,
			MAX(LAST_START) LAST_START,
			MAX(LAST_END) LAST_END,
			MIN(MIN_NVAL_NUM) MIN_NVAL_NUM,
			MAX(MAX_NVAL_NUM) MAX_NVAL_NUM,
			MAX(MIN_NVAL_L*1) MIN_NVAL_L,
			MAX(MAX_NVAL_G*1) MAX_NVAL_G
		FROM a
		GROUP BY CONCEPT_CD, PATIENT_NUM
	ALTER TABLE [CRC].[CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW] ADD PRIMARY KEY (CONCEPT_CD, PATIENT_NUM) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE UNIQUE NONCLUSTERED INDEX IDX_PATIENT_CONCEPT ON CRC.CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW (PATIENT_NUM, CONCEPT_CD) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)

	-------------------------------------------------------------
	-- Fact counts by concept
	-------------------------------------------------------------

	CREATE TABLE [CRC].[CQ2_FACT_COUNTS_CONCEPT_NEW] (
		CONCEPT_CD VARCHAR(50) NOT NULL,
		NUM_PATIENTS INT,
		NUM_ENCOUNTERS BIGINT,
		NUM_INSTANCES BIGINT,
		NUM_FACTS BIGINT,
		FIRST_START DATETIME,
		LAST_START DATETIME,
		LAST_END DATETIME,
		MIN_NVAL_NUM DECIMAL(18, 5),
		MAX_NVAL_NUM DECIMAL(18, 5),
		MIN_NVAL_L BIT,
		MAX_NVAL_G BIT,
		MAX_OCCURS INT
	)
	INSERT INTO [CRC].[CQ2_FACT_COUNTS_CONCEPT_NEW] WITH (TABLOCK)
		SELECT CONCEPT_CD,
			COUNT(DISTINCT PATIENT_NUM) NUM_PATIENTS,
			SUM(NUM_ENCOUNTERS) NUM_ENCOUNTERS,
			SUM(NUM_INSTANCES) NUM_INSTANCES,
			SUM(NUM_FACTS) NUM_FACTS,
			MIN(FIRST_START) FIRST_START,
			MAX(LAST_START) LAST_START,
			MAX(LAST_END) LAST_END,
			MIN(MIN_NVAL_NUM) MIN_NVAL_NUM,
			MAX(MAX_NVAL_NUM) MAX_NVAL_NUM,
			MAX(MIN_NVAL_L*1) MIN_NVAL_L,
			MAX(MAX_NVAL_G*1) MAX_NVAL_G,
			MAX(NUM_INSTANCES) MAX_OCCURS
		FROM [CRC].[CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW]
		GROUP BY concept_cd
	ALTER TABLE [CRC].[CQ2_FACT_COUNTS_CONCEPT_NEW] ADD PRIMARY KEY (CONCEPT_CD)

	-- **********************************************************
	-- **********************************************************
	-- **** Ontology path (folder) rollup
	-- **********************************************************
	-- **********************************************************

	-------------------------------------------------------------
	-- Fact counts by path and patient
	-------------------------------------------------------------

	-- Get the concepts of folder paths
	SELECT c.CONCEPT_PATH_ID, c.CONCEPT_CD
		INTO #FolderConcepts
		FROM [CRC].[CQ2_CONCEPT_PATH_NEW] p
			INNER JOIN [CRC].[CQ2_CONCEPT_PATH_CODE_NEW] c
				ON p.CONCEPT_PATH_ID=c.CONCEPT_PATH_ID
		WHERE p.NUM_CONCEPTS>1
	ALTER TABLE #FolderConcepts ADD PRIMARY KEY (CONCEPT_CD, CONCEPT_PATH_ID)

	-- Caculate fact counts by path and patient
	CREATE TABLE [CRC].[CQ2_FACT_COUNTS_PATH_PATIENT_NEW] (
		CONCEPT_PATH_ID INT NOT NULL,
		PATIENT_NUM INT NOT NULL,
		NUM_ENCOUNTERS INT,
		NUM_INSTANCES INT,
		NUM_FACTS INT,
		FIRST_START DATETIME,
		LAST_START DATETIME,
		LAST_END DATETIME,
		MIN_NVAL_NUM DECIMAL(18, 5),
		MAX_NVAL_NUM DECIMAL(18, 5),
		MIN_NVAL_L BIT,
		MAX_NVAL_G BIT
	)
	INSERT INTO [CRC].[CQ2_FACT_COUNTS_PATH_PATIENT_NEW] WITH (TABLOCK)
		SELECT c.CONCEPT_PATH_ID, 
			p.PATIENT_NUM,
			SUM(NUM_ENCOUNTERS) NUM_ENCOUNTERS, -- Doesn't consider duplicates
			SUM(NUM_INSTANCES) NUM_INSTANCES,
			SUM(NUM_FACTS) NUM_FACTS,
			MIN(FIRST_START) FIRST_START,
			MAX(LAST_START) LAST_START,
			MAX(LAST_END) LAST_END,
			MIN(MIN_NVAL_NUM) MIN_NVAL_NUM,
			MAX(MAX_NVAL_NUM) MAX_NVAL_NUM,
			MAX(MIN_NVAL_L*1.0) MIN_NVAL_L,
			MAX(MAX_NVAL_G*1.0) MAX_NVAL_G
		FROM #FolderConcepts c
			INNER JOIN [CRC].[CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW] p
				ON c.CONCEPT_CD=p.CONCEPT_CD
		GROUP BY c.CONCEPT_PATH_ID, p.PATIENT_NUM
	ALTER TABLE [CRC].[CQ2_FACT_COUNTS_PATH_PATIENT_NEW] ADD PRIMARY KEY (CONCEPT_PATH_ID, PATIENT_NUM) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE UNIQUE NONCLUSTERED INDEX IDX_PATIENT_PATH_ID ON [CRC].[CQ2_FACT_COUNTS_PATH_PATIENT_NEW] (PATIENT_NUM, CONCEPT_PATH_ID) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)

	-- Drop temp table
	DROP TABLE #FolderConcepts

	-------------------------------------------------------------
	-- Fact counts by path
	-------------------------------------------------------------

	CREATE TABLE [CRC].[CQ2_FACT_COUNTS_PATH_NEW] (
		CONCEPT_PATH_ID INT NOT NULL,
		NUM_PATIENTS INT,
		NUM_ENCOUNTERS BIGINT,
		NUM_INSTANCES BIGINT,
		NUM_FACTS BIGINT,
		FIRST_START DATETIME,
		LAST_START DATETIME,
		LAST_END DATETIME,
		MIN_NVAL_NUM DECIMAL(18, 5),
		MAX_NVAL_NUM DECIMAL(18, 5),
		MIN_NVAL_L BIT,
		MAX_NVAL_G BIT,
		MAX_OCCURS INT
	)
	INSERT INTO [CRC].[CQ2_FACT_COUNTS_PATH_NEW] WITH (TABLOCK)
		SELECT CONCEPT_PATH_ID,
			COUNT(*) NUM_PATIENTS,
			SUM(NUM_ENCOUNTERS) NUM_ENCOUNTERS, -- Doesn't consider duplicates
			SUM(NUM_INSTANCES) NUM_INSTANCES,
			SUM(NUM_FACTS) NUM_FACTS,
			MIN(FIRST_START) FIRST_START,
			MAX(LAST_START) LAST_START,
			MAX(LAST_END) LAST_END,
			MIN(MIN_NVAL_NUM) MIN_NVAL_NUM,
			MAX(MAX_NVAL_NUM) MAX_NVAL_NUM,
			MAX(MIN_NVAL_L*1.0) MIN_NVAL_L,
			MAX(MAX_NVAL_G*1.0) MAX_NVAL_G,
			MAX(NUM_INSTANCES) MAX_OCCURS
		FROM CRC.CQ2_FACT_COUNTS_PATH_PATIENT_NEW
		GROUP BY CONCEPT_PATH_ID
	ALTER TABLE [CRC].[CQ2_FACT_COUNTS_PATH_NEW] ADD PRIMARY KEY (CONCEPT_PATH_ID)

	-- **********************************************************
	-- **********************************************************
	-- **** Sketches
	-- **********************************************************
	-- **********************************************************

	-------------------------------------------------------------
	-- Patient sketch hashes
	-------------------------------------------------------------

	-- Create two binary hash values per patient
	SELECT PATIENT_NUM, LEFT(H,20) B, RIGHT(H,20) V
		INTO #PatientHash
		FROM (
			SELECT PATIENT_NUM, 
				HASHBYTES('SHA1', cast(NEWID() AS VARCHAR(50))) H
			FROM CRC.PATIENT_DIMENSION_NEW
		) t
	CREATE UNIQUE CLUSTERED INDEX IDX_PK ON #PatientHash(V,PATIENT_NUM)

	-- Convert hash values to bin (B) and value (V) integers
	SELECT PATIENT_NUM, 
			CAST(CAST(B AS BINARY(3)) AS INT) % 32768 B,
			FLOOR(ROW_NUMBER() OVER (ORDER BY V)*n) V
		INTO #CQ2_SKETCH_PATIENT
		FROM #PatientHash
			CROSS JOIN (SELECT POWER(2,30)/CAST(COUNT(*)+1 AS FLOAT) n FROM #PatientHash) n

	-- Save the bin and value (split the bin into rows B and columns C)
	CREATE TABLE [CRC].[CQ2_SKETCH_PATIENT_NEW] (
		PATIENT_NUM INT NOT NULL,
		B15 SMALLINT NOT NULL,
		B TINYINT NOT NULL,
		C TINYINT NOT NULL,
		V INT NOT NULL
	)
	INSERT INTO [CRC].[CQ2_SKETCH_PATIENT_NEW] WITH (TABLOCK)
		SELECT PATIENT_NUM, B, B/256, B%256, V
		FROM #CQ2_SKETCH_PATIENT
	ALTER TABLE [CRC].[CQ2_SKETCH_PATIENT_NEW] ADD PRIMARY KEY (PATIENT_NUM) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)
	CREATE UNIQUE NONCLUSTERED INDEX IDX_V ON [CRC].[CQ2_SKETCH_PATIENT_NEW] (V) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)

	-- Drop the temp tables
	DROP TABLE #PatientHash
	DROP TABLE #CQ2_SKETCH_PATIENT

	-------------------------------------------------------------
	-- Path sketches
	-------------------------------------------------------------

	-- Create 2^15 (32768) row x 1 column sketch table
	CREATE TABLE #CQ2_SKETCH_PATH15 (
		CONCEPT_PATH_ID INT NOT NULL,
		B TINYINT NOT NULL,
		C TINYINT NOT NULL,
		V INT NOT NULL
	)
	-- Load multi-concept paths
	INSERT INTO #CQ2_SKETCH_PATH15 WITH (TABLOCK)
		SELECT p.CONCEPT_PATH_ID, s.B, s.C, MIN(V) V
			FROM [CRC].[CQ2_FACT_COUNTS_PATH_PATIENT_NEW] p
				INNER JOIN [CRC].[CQ2_SKETCH_PATIENT_NEW] s
					ON p.PATIENT_NUM = s.PATIENT_NUM
			GROUP BY p.CONCEPT_PATH_ID, s.B, s.C
	-- Load single-concept paths
	INSERT INTO #CQ2_SKETCH_PATH15 WITH (TABLOCK)
		SELECT c.CONCEPT_PATH_ID, s.B, s.C, MIN(V) V
			FROM [CRC].[CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW] p
				INNER JOIN [CRC].[CQ2_SKETCH_PATIENT_NEW] s
					ON p.PATIENT_NUM = s.PATIENT_NUM
				INNER JOIN [CRC].[CQ2_CONCEPT_PATH_NEW] c
					ON p.CONCEPT_CD = c.CONCEPT_CD AND c.CONCEPT_CD<>''
			GROUP BY c.CONCEPT_PATH_ID, s.B, s.C
	-- Add a primary key to the table
	ALTER TABLE #CQ2_SKETCH_PATH15 ADD PRIMARY KEY (CONCEPT_PATH_ID, B, C)

	-- Create 128 row x 256 column sketch table
	CREATE TABLE [CRC].[CQ2_SKETCH_PATH15x256_NEW] (
		CONCEPT_PATH_ID INT NOT NULL,
		B TINYINT NOT NULL,
		V0 INT, V1 INT, V2 INT, V3 INT, V4 INT, V5 INT, V6 INT, V7 INT, V8 INT, V9 INT, V10 INT, V11 INT, V12 INT, V13 INT, V14 INT, V15 INT,
		V16 INT, V17 INT, V18 INT, V19 INT, V20 INT, V21 INT, V22 INT, V23 INT, V24 INT, V25 INT, V26 INT, V27 INT, V28 INT, V29 INT, V30 INT, V31 INT, 
		V32 INT, V33 INT, V34 INT, V35 INT, V36 INT, V37 INT, V38 INT, V39 INT, V40 INT, V41 INT, V42 INT, V43 INT, V44 INT, V45 INT, V46 INT, V47 INT, 
		V48 INT, V49 INT, V50 INT, V51 INT, V52 INT, V53 INT, V54 INT, V55 INT, V56 INT, V57 INT, V58 INT, V59 INT, V60 INT, V61 INT, V62 INT, V63 INT, 
		V64 INT, V65 INT, V66 INT, V67 INT, V68 INT, V69 INT, V70 INT, V71 INT, V72 INT, V73 INT, V74 INT, V75 INT, V76 INT, V77 INT, V78 INT, V79 INT, 
		V80 INT, V81 INT, V82 INT, V83 INT, V84 INT, V85 INT, V86 INT, V87 INT, V88 INT, V89 INT, V90 INT, V91 INT, V92 INT, V93 INT, V94 INT, V95 INT, 
		V96 INT, V97 INT, V98 INT, V99 INT, V100 INT, V101 INT, V102 INT, V103 INT, V104 INT, V105 INT, V106 INT, V107 INT, V108 INT, V109 INT, V110 INT, V111 INT, 
		V112 INT, V113 INT, V114 INT, V115 INT, V116 INT, V117 INT, V118 INT, V119 INT, V120 INT, V121 INT, V122 INT, V123 INT, V124 INT, V125 INT, V126 INT, V127 INT, 
		V128 INT, V129 INT, V130 INT, V131 INT, V132 INT, V133 INT, V134 INT, V135 INT, V136 INT, V137 INT, V138 INT, V139 INT, V140 INT, V141 INT, V142 INT, V143 INT, 
		V144 INT, V145 INT, V146 INT, V147 INT, V148 INT, V149 INT, V150 INT, V151 INT, V152 INT, V153 INT, V154 INT, V155 INT, V156 INT, V157 INT, V158 INT, V159 INT, 
		V160 INT, V161 INT, V162 INT, V163 INT, V164 INT, V165 INT, V166 INT, V167 INT, V168 INT, V169 INT, V170 INT, V171 INT, V172 INT, V173 INT, V174 INT, V175 INT, 
		V176 INT, V177 INT, V178 INT, V179 INT, V180 INT, V181 INT, V182 INT, V183 INT, V184 INT, V185 INT, V186 INT, V187 INT, V188 INT, V189 INT, V190 INT, V191 INT, 
		V192 INT, V193 INT, V194 INT, V195 INT, V196 INT, V197 INT, V198 INT, V199 INT, V200 INT, V201 INT, V202 INT, V203 INT, V204 INT, V205 INT, V206 INT, V207 INT, 
		V208 INT, V209 INT, V210 INT, V211 INT, V212 INT, V213 INT, V214 INT, V215 INT, V216 INT, V217 INT, V218 INT, V219 INT, V220 INT, V221 INT, V222 INT, V223 INT, 
		V224 INT, V225 INT, V226 INT, V227 INT, V228 INT, V229 INT, V230 INT, V231 INT, V232 INT, V233 INT, V234 INT, V235 INT, V236 INT, V237 INT, V238 INT, V239 INT, 
		V240 INT, V241 INT, V242 INT, V243 INT, V244 INT, V245 INT, V246 INT, V247 INT, V248 INT, V249 INT, V250 INT, V251 INT, V252 INT, V253 INT, V254 INT, V255 INT
	)
	-- Load 128 row x 256 column sketch table
	INSERT INTO [CRC].[CQ2_SKETCH_PATH15x256_NEW] WITH (TABLOCK)
		SELECT CONCEPT_PATH_ID, B, 
			MAX(CASE WHEN C = 0 THEN V ELSE NULL END) V0, MAX(CASE WHEN C = 1 THEN V ELSE NULL END) V1, MAX(CASE WHEN C = 2 THEN V ELSE NULL END) V2, MAX(CASE WHEN C = 3 THEN V ELSE NULL END) V3, 
			MAX(CASE WHEN C = 4 THEN V ELSE NULL END) V4, MAX(CASE WHEN C = 5 THEN V ELSE NULL END) V5, MAX(CASE WHEN C = 6 THEN V ELSE NULL END) V6, MAX(CASE WHEN C = 7 THEN V ELSE NULL END) V7, 
			MAX(CASE WHEN C = 8 THEN V ELSE NULL END) V8, MAX(CASE WHEN C = 9 THEN V ELSE NULL END) V9, MAX(CASE WHEN C = 10 THEN V ELSE NULL END) V10, MAX(CASE WHEN C = 11 THEN V ELSE NULL END) V11, 
			MAX(CASE WHEN C = 12 THEN V ELSE NULL END) V12, MAX(CASE WHEN C = 13 THEN V ELSE NULL END) V13, MAX(CASE WHEN C = 14 THEN V ELSE NULL END) V14, MAX(CASE WHEN C = 15 THEN V ELSE NULL END) V15, 
			MAX(CASE WHEN C = 16 THEN V ELSE NULL END) V16, MAX(CASE WHEN C = 17 THEN V ELSE NULL END) V17, MAX(CASE WHEN C = 18 THEN V ELSE NULL END) V18, MAX(CASE WHEN C = 19 THEN V ELSE NULL END) V19, 
			MAX(CASE WHEN C = 20 THEN V ELSE NULL END) V20, MAX(CASE WHEN C = 21 THEN V ELSE NULL END) V21, MAX(CASE WHEN C = 22 THEN V ELSE NULL END) V22, MAX(CASE WHEN C = 23 THEN V ELSE NULL END) V23, 
			MAX(CASE WHEN C = 24 THEN V ELSE NULL END) V24, MAX(CASE WHEN C = 25 THEN V ELSE NULL END) V25, MAX(CASE WHEN C = 26 THEN V ELSE NULL END) V26, MAX(CASE WHEN C = 27 THEN V ELSE NULL END) V27, 
			MAX(CASE WHEN C = 28 THEN V ELSE NULL END) V28, MAX(CASE WHEN C = 29 THEN V ELSE NULL END) V29, MAX(CASE WHEN C = 30 THEN V ELSE NULL END) V30, MAX(CASE WHEN C = 31 THEN V ELSE NULL END) V31, 
			MAX(CASE WHEN C = 32 THEN V ELSE NULL END) V32, MAX(CASE WHEN C = 33 THEN V ELSE NULL END) V33, MAX(CASE WHEN C = 34 THEN V ELSE NULL END) V34, MAX(CASE WHEN C = 35 THEN V ELSE NULL END) V35, 
			MAX(CASE WHEN C = 36 THEN V ELSE NULL END) V36, MAX(CASE WHEN C = 37 THEN V ELSE NULL END) V37, MAX(CASE WHEN C = 38 THEN V ELSE NULL END) V38, MAX(CASE WHEN C = 39 THEN V ELSE NULL END) V39, 
			MAX(CASE WHEN C = 40 THEN V ELSE NULL END) V40, MAX(CASE WHEN C = 41 THEN V ELSE NULL END) V41, MAX(CASE WHEN C = 42 THEN V ELSE NULL END) V42, MAX(CASE WHEN C = 43 THEN V ELSE NULL END) V43, 
			MAX(CASE WHEN C = 44 THEN V ELSE NULL END) V44, MAX(CASE WHEN C = 45 THEN V ELSE NULL END) V45, MAX(CASE WHEN C = 46 THEN V ELSE NULL END) V46, MAX(CASE WHEN C = 47 THEN V ELSE NULL END) V47, 
			MAX(CASE WHEN C = 48 THEN V ELSE NULL END) V48, MAX(CASE WHEN C = 49 THEN V ELSE NULL END) V49, MAX(CASE WHEN C = 50 THEN V ELSE NULL END) V50, MAX(CASE WHEN C = 51 THEN V ELSE NULL END) V51, 
			MAX(CASE WHEN C = 52 THEN V ELSE NULL END) V52, MAX(CASE WHEN C = 53 THEN V ELSE NULL END) V53, MAX(CASE WHEN C = 54 THEN V ELSE NULL END) V54, MAX(CASE WHEN C = 55 THEN V ELSE NULL END) V55, 
			MAX(CASE WHEN C = 56 THEN V ELSE NULL END) V56, MAX(CASE WHEN C = 57 THEN V ELSE NULL END) V57, MAX(CASE WHEN C = 58 THEN V ELSE NULL END) V58, MAX(CASE WHEN C = 59 THEN V ELSE NULL END) V59, 
			MAX(CASE WHEN C = 60 THEN V ELSE NULL END) V60, MAX(CASE WHEN C = 61 THEN V ELSE NULL END) V61, MAX(CASE WHEN C = 62 THEN V ELSE NULL END) V62, MAX(CASE WHEN C = 63 THEN V ELSE NULL END) V63, 
			MAX(CASE WHEN C = 64 THEN V ELSE NULL END) V64, MAX(CASE WHEN C = 65 THEN V ELSE NULL END) V65, MAX(CASE WHEN C = 66 THEN V ELSE NULL END) V66, MAX(CASE WHEN C = 67 THEN V ELSE NULL END) V67, 
			MAX(CASE WHEN C = 68 THEN V ELSE NULL END) V68, MAX(CASE WHEN C = 69 THEN V ELSE NULL END) V69, MAX(CASE WHEN C = 70 THEN V ELSE NULL END) V70, MAX(CASE WHEN C = 71 THEN V ELSE NULL END) V71, 
			MAX(CASE WHEN C = 72 THEN V ELSE NULL END) V72, MAX(CASE WHEN C = 73 THEN V ELSE NULL END) V73, MAX(CASE WHEN C = 74 THEN V ELSE NULL END) V74, MAX(CASE WHEN C = 75 THEN V ELSE NULL END) V75, 
			MAX(CASE WHEN C = 76 THEN V ELSE NULL END) V76, MAX(CASE WHEN C = 77 THEN V ELSE NULL END) V77, MAX(CASE WHEN C = 78 THEN V ELSE NULL END) V78, MAX(CASE WHEN C = 79 THEN V ELSE NULL END) V79, 
			MAX(CASE WHEN C = 80 THEN V ELSE NULL END) V80, MAX(CASE WHEN C = 81 THEN V ELSE NULL END) V81, MAX(CASE WHEN C = 82 THEN V ELSE NULL END) V82, MAX(CASE WHEN C = 83 THEN V ELSE NULL END) V83, 
			MAX(CASE WHEN C = 84 THEN V ELSE NULL END) V84, MAX(CASE WHEN C = 85 THEN V ELSE NULL END) V85, MAX(CASE WHEN C = 86 THEN V ELSE NULL END) V86, MAX(CASE WHEN C = 87 THEN V ELSE NULL END) V87, 
			MAX(CASE WHEN C = 88 THEN V ELSE NULL END) V88, MAX(CASE WHEN C = 89 THEN V ELSE NULL END) V89, MAX(CASE WHEN C = 90 THEN V ELSE NULL END) V90, MAX(CASE WHEN C = 91 THEN V ELSE NULL END) V91, 
			MAX(CASE WHEN C = 92 THEN V ELSE NULL END) V92, MAX(CASE WHEN C = 93 THEN V ELSE NULL END) V93, MAX(CASE WHEN C = 94 THEN V ELSE NULL END) V94, MAX(CASE WHEN C = 95 THEN V ELSE NULL END) V95, 
			MAX(CASE WHEN C = 96 THEN V ELSE NULL END) V96, MAX(CASE WHEN C = 97 THEN V ELSE NULL END) V97, MAX(CASE WHEN C = 98 THEN V ELSE NULL END) V98, MAX(CASE WHEN C = 99 THEN V ELSE NULL END) V99, 
			MAX(CASE WHEN C = 100 THEN V ELSE NULL END) V100, MAX(CASE WHEN C = 101 THEN V ELSE NULL END) V101, MAX(CASE WHEN C = 102 THEN V ELSE NULL END) V102, MAX(CASE WHEN C = 103 THEN V ELSE NULL END) V103, 
			MAX(CASE WHEN C = 104 THEN V ELSE NULL END) V104, MAX(CASE WHEN C = 105 THEN V ELSE NULL END) V105, MAX(CASE WHEN C = 106 THEN V ELSE NULL END) V106, MAX(CASE WHEN C = 107 THEN V ELSE NULL END) V107, 
			MAX(CASE WHEN C = 108 THEN V ELSE NULL END) V108, MAX(CASE WHEN C = 109 THEN V ELSE NULL END) V109, MAX(CASE WHEN C = 110 THEN V ELSE NULL END) V110, MAX(CASE WHEN C = 111 THEN V ELSE NULL END) V111, 
			MAX(CASE WHEN C = 112 THEN V ELSE NULL END) V112, MAX(CASE WHEN C = 113 THEN V ELSE NULL END) V113, MAX(CASE WHEN C = 114 THEN V ELSE NULL END) V114, MAX(CASE WHEN C = 115 THEN V ELSE NULL END) V115, 
			MAX(CASE WHEN C = 116 THEN V ELSE NULL END) V116, MAX(CASE WHEN C = 117 THEN V ELSE NULL END) V117, MAX(CASE WHEN C = 118 THEN V ELSE NULL END) V118, MAX(CASE WHEN C = 119 THEN V ELSE NULL END) V119, 
			MAX(CASE WHEN C = 120 THEN V ELSE NULL END) V120, MAX(CASE WHEN C = 121 THEN V ELSE NULL END) V121, MAX(CASE WHEN C = 122 THEN V ELSE NULL END) V122, MAX(CASE WHEN C = 123 THEN V ELSE NULL END) V123, 
			MAX(CASE WHEN C = 124 THEN V ELSE NULL END) V124, MAX(CASE WHEN C = 125 THEN V ELSE NULL END) V125, MAX(CASE WHEN C = 126 THEN V ELSE NULL END) V126, MAX(CASE WHEN C = 127 THEN V ELSE NULL END) V127, 
			MAX(CASE WHEN C = 128 THEN V ELSE NULL END) V128, MAX(CASE WHEN C = 129 THEN V ELSE NULL END) V129, MAX(CASE WHEN C = 130 THEN V ELSE NULL END) V130, MAX(CASE WHEN C = 131 THEN V ELSE NULL END) V131, 
			MAX(CASE WHEN C = 132 THEN V ELSE NULL END) V132, MAX(CASE WHEN C = 133 THEN V ELSE NULL END) V133, MAX(CASE WHEN C = 134 THEN V ELSE NULL END) V134, MAX(CASE WHEN C = 135 THEN V ELSE NULL END) V135, 
			MAX(CASE WHEN C = 136 THEN V ELSE NULL END) V136, MAX(CASE WHEN C = 137 THEN V ELSE NULL END) V137, MAX(CASE WHEN C = 138 THEN V ELSE NULL END) V138, MAX(CASE WHEN C = 139 THEN V ELSE NULL END) V139, 
			MAX(CASE WHEN C = 140 THEN V ELSE NULL END) V140, MAX(CASE WHEN C = 141 THEN V ELSE NULL END) V141, MAX(CASE WHEN C = 142 THEN V ELSE NULL END) V142, MAX(CASE WHEN C = 143 THEN V ELSE NULL END) V143, 
			MAX(CASE WHEN C = 144 THEN V ELSE NULL END) V144, MAX(CASE WHEN C = 145 THEN V ELSE NULL END) V145, MAX(CASE WHEN C = 146 THEN V ELSE NULL END) V146, MAX(CASE WHEN C = 147 THEN V ELSE NULL END) V147, 
			MAX(CASE WHEN C = 148 THEN V ELSE NULL END) V148, MAX(CASE WHEN C = 149 THEN V ELSE NULL END) V149, MAX(CASE WHEN C = 150 THEN V ELSE NULL END) V150, MAX(CASE WHEN C = 151 THEN V ELSE NULL END) V151, 
			MAX(CASE WHEN C = 152 THEN V ELSE NULL END) V152, MAX(CASE WHEN C = 153 THEN V ELSE NULL END) V153, MAX(CASE WHEN C = 154 THEN V ELSE NULL END) V154, MAX(CASE WHEN C = 155 THEN V ELSE NULL END) V155, 
			MAX(CASE WHEN C = 156 THEN V ELSE NULL END) V156, MAX(CASE WHEN C = 157 THEN V ELSE NULL END) V157, MAX(CASE WHEN C = 158 THEN V ELSE NULL END) V158, MAX(CASE WHEN C = 159 THEN V ELSE NULL END) V159, 
			MAX(CASE WHEN C = 160 THEN V ELSE NULL END) V160, MAX(CASE WHEN C = 161 THEN V ELSE NULL END) V161, MAX(CASE WHEN C = 162 THEN V ELSE NULL END) V162, MAX(CASE WHEN C = 163 THEN V ELSE NULL END) V163, 
			MAX(CASE WHEN C = 164 THEN V ELSE NULL END) V164, MAX(CASE WHEN C = 165 THEN V ELSE NULL END) V165, MAX(CASE WHEN C = 166 THEN V ELSE NULL END) V166, MAX(CASE WHEN C = 167 THEN V ELSE NULL END) V167, 
			MAX(CASE WHEN C = 168 THEN V ELSE NULL END) V168, MAX(CASE WHEN C = 169 THEN V ELSE NULL END) V169, MAX(CASE WHEN C = 170 THEN V ELSE NULL END) V170, MAX(CASE WHEN C = 171 THEN V ELSE NULL END) V171, 
			MAX(CASE WHEN C = 172 THEN V ELSE NULL END) V172, MAX(CASE WHEN C = 173 THEN V ELSE NULL END) V173, MAX(CASE WHEN C = 174 THEN V ELSE NULL END) V174, MAX(CASE WHEN C = 175 THEN V ELSE NULL END) V175, 
			MAX(CASE WHEN C = 176 THEN V ELSE NULL END) V176, MAX(CASE WHEN C = 177 THEN V ELSE NULL END) V177, MAX(CASE WHEN C = 178 THEN V ELSE NULL END) V178, MAX(CASE WHEN C = 179 THEN V ELSE NULL END) V179, 
			MAX(CASE WHEN C = 180 THEN V ELSE NULL END) V180, MAX(CASE WHEN C = 181 THEN V ELSE NULL END) V181, MAX(CASE WHEN C = 182 THEN V ELSE NULL END) V182, MAX(CASE WHEN C = 183 THEN V ELSE NULL END) V183, 
			MAX(CASE WHEN C = 184 THEN V ELSE NULL END) V184, MAX(CASE WHEN C = 185 THEN V ELSE NULL END) V185, MAX(CASE WHEN C = 186 THEN V ELSE NULL END) V186, MAX(CASE WHEN C = 187 THEN V ELSE NULL END) V187, 
			MAX(CASE WHEN C = 188 THEN V ELSE NULL END) V188, MAX(CASE WHEN C = 189 THEN V ELSE NULL END) V189, MAX(CASE WHEN C = 190 THEN V ELSE NULL END) V190, MAX(CASE WHEN C = 191 THEN V ELSE NULL END) V191, 
			MAX(CASE WHEN C = 192 THEN V ELSE NULL END) V192, MAX(CASE WHEN C = 193 THEN V ELSE NULL END) V193, MAX(CASE WHEN C = 194 THEN V ELSE NULL END) V194, MAX(CASE WHEN C = 195 THEN V ELSE NULL END) V195, 
			MAX(CASE WHEN C = 196 THEN V ELSE NULL END) V196, MAX(CASE WHEN C = 197 THEN V ELSE NULL END) V197, MAX(CASE WHEN C = 198 THEN V ELSE NULL END) V198, MAX(CASE WHEN C = 199 THEN V ELSE NULL END) V199, 
			MAX(CASE WHEN C = 200 THEN V ELSE NULL END) V200, MAX(CASE WHEN C = 201 THEN V ELSE NULL END) V201, MAX(CASE WHEN C = 202 THEN V ELSE NULL END) V202, MAX(CASE WHEN C = 203 THEN V ELSE NULL END) V203, 
			MAX(CASE WHEN C = 204 THEN V ELSE NULL END) V204, MAX(CASE WHEN C = 205 THEN V ELSE NULL END) V205, MAX(CASE WHEN C = 206 THEN V ELSE NULL END) V206, MAX(CASE WHEN C = 207 THEN V ELSE NULL END) V207, 
			MAX(CASE WHEN C = 208 THEN V ELSE NULL END) V208, MAX(CASE WHEN C = 209 THEN V ELSE NULL END) V209, MAX(CASE WHEN C = 210 THEN V ELSE NULL END) V210, MAX(CASE WHEN C = 211 THEN V ELSE NULL END) V211, 
			MAX(CASE WHEN C = 212 THEN V ELSE NULL END) V212, MAX(CASE WHEN C = 213 THEN V ELSE NULL END) V213, MAX(CASE WHEN C = 214 THEN V ELSE NULL END) V214, MAX(CASE WHEN C = 215 THEN V ELSE NULL END) V215, 
			MAX(CASE WHEN C = 216 THEN V ELSE NULL END) V216, MAX(CASE WHEN C = 217 THEN V ELSE NULL END) V217, MAX(CASE WHEN C = 218 THEN V ELSE NULL END) V218, MAX(CASE WHEN C = 219 THEN V ELSE NULL END) V219, 
			MAX(CASE WHEN C = 220 THEN V ELSE NULL END) V220, MAX(CASE WHEN C = 221 THEN V ELSE NULL END) V221, MAX(CASE WHEN C = 222 THEN V ELSE NULL END) V222, MAX(CASE WHEN C = 223 THEN V ELSE NULL END) V223, 
			MAX(CASE WHEN C = 224 THEN V ELSE NULL END) V224, MAX(CASE WHEN C = 225 THEN V ELSE NULL END) V225, MAX(CASE WHEN C = 226 THEN V ELSE NULL END) V226, MAX(CASE WHEN C = 227 THEN V ELSE NULL END) V227, 
			MAX(CASE WHEN C = 228 THEN V ELSE NULL END) V228, MAX(CASE WHEN C = 229 THEN V ELSE NULL END) V229, MAX(CASE WHEN C = 230 THEN V ELSE NULL END) V230, MAX(CASE WHEN C = 231 THEN V ELSE NULL END) V231, 
			MAX(CASE WHEN C = 232 THEN V ELSE NULL END) V232, MAX(CASE WHEN C = 233 THEN V ELSE NULL END) V233, MAX(CASE WHEN C = 234 THEN V ELSE NULL END) V234, MAX(CASE WHEN C = 235 THEN V ELSE NULL END) V235, 
			MAX(CASE WHEN C = 236 THEN V ELSE NULL END) V236, MAX(CASE WHEN C = 237 THEN V ELSE NULL END) V237, MAX(CASE WHEN C = 238 THEN V ELSE NULL END) V238, MAX(CASE WHEN C = 239 THEN V ELSE NULL END) V239, 
			MAX(CASE WHEN C = 240 THEN V ELSE NULL END) V240, MAX(CASE WHEN C = 241 THEN V ELSE NULL END) V241, MAX(CASE WHEN C = 242 THEN V ELSE NULL END) V242, MAX(CASE WHEN C = 243 THEN V ELSE NULL END) V243, 
			MAX(CASE WHEN C = 244 THEN V ELSE NULL END) V244, MAX(CASE WHEN C = 245 THEN V ELSE NULL END) V245, MAX(CASE WHEN C = 246 THEN V ELSE NULL END) V246, MAX(CASE WHEN C = 247 THEN V ELSE NULL END) V247, 
			MAX(CASE WHEN C = 248 THEN V ELSE NULL END) V248, MAX(CASE WHEN C = 249 THEN V ELSE NULL END) V249, MAX(CASE WHEN C = 250 THEN V ELSE NULL END) V250, MAX(CASE WHEN C = 251 THEN V ELSE NULL END) V251, 
			MAX(CASE WHEN C = 252 THEN V ELSE NULL END) V252, MAX(CASE WHEN C = 253 THEN V ELSE NULL END) V253, MAX(CASE WHEN C = 254 THEN V ELSE NULL END) V254, MAX(CASE WHEN C = 255 THEN V ELSE NULL END) V255
		FROM #CQ2_SKETCH_PATH15
		GROUP BY CONCEPT_PATH_ID, B
	-- Add a primary key to the 128 row x 256 column sketch table
	ALTER TABLE [CRC].[CQ2_SKETCH_PATH15x256_NEW] ADD PRIMARY KEY (CONCEPT_PATH_ID, B) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)

	-- Create 1 row x 256 column sketch table
	CREATE TABLE [CRC].[CQ2_SKETCH_PATH8x256_NEW] (
		CONCEPT_PATH_ID INT NOT NULL,
		V0 INT, V1 INT, V2 INT, V3 INT, V4 INT, V5 INT, V6 INT, V7 INT, V8 INT, V9 INT, V10 INT, V11 INT, V12 INT, V13 INT, V14 INT, V15 INT, 
		V16 INT, V17 INT, V18 INT, V19 INT, V20 INT, V21 INT, V22 INT, V23 INT, V24 INT, V25 INT, V26 INT, V27 INT, V28 INT, V29 INT, V30 INT, V31 INT, 
		V32 INT, V33 INT, V34 INT, V35 INT, V36 INT, V37 INT, V38 INT, V39 INT, V40 INT, V41 INT, V42 INT, V43 INT, V44 INT, V45 INT, V46 INT, V47 INT, 
		V48 INT, V49 INT, V50 INT, V51 INT, V52 INT, V53 INT, V54 INT, V55 INT, V56 INT, V57 INT, V58 INT, V59 INT, V60 INT, V61 INT, V62 INT, V63 INT, 
		V64 INT, V65 INT, V66 INT, V67 INT, V68 INT, V69 INT, V70 INT, V71 INT, V72 INT, V73 INT, V74 INT, V75 INT, V76 INT, V77 INT, V78 INT, V79 INT, 
		V80 INT, V81 INT, V82 INT, V83 INT, V84 INT, V85 INT, V86 INT, V87 INT, V88 INT, V89 INT, V90 INT, V91 INT, V92 INT, V93 INT, V94 INT, V95 INT, 
		V96 INT, V97 INT, V98 INT, V99 INT, V100 INT, V101 INT, V102 INT, V103 INT, V104 INT, V105 INT, V106 INT, V107 INT, V108 INT, V109 INT, V110 INT, V111 INT, 
		V112 INT, V113 INT, V114 INT, V115 INT, V116 INT, V117 INT, V118 INT, V119 INT, V120 INT, V121 INT, V122 INT, V123 INT, V124 INT, V125 INT, V126 INT, V127 INT, 
		V128 INT, V129 INT, V130 INT, V131 INT, V132 INT, V133 INT, V134 INT, V135 INT, V136 INT, V137 INT, V138 INT, V139 INT, V140 INT, V141 INT, V142 INT, V143 INT, 
		V144 INT, V145 INT, V146 INT, V147 INT, V148 INT, V149 INT, V150 INT, V151 INT, V152 INT, V153 INT, V154 INT, V155 INT, V156 INT, V157 INT, V158 INT, V159 INT, 
		V160 INT, V161 INT, V162 INT, V163 INT, V164 INT, V165 INT, V166 INT, V167 INT, V168 INT, V169 INT, V170 INT, V171 INT, V172 INT, V173 INT, V174 INT, V175 INT, 
		V176 INT, V177 INT, V178 INT, V179 INT, V180 INT, V181 INT, V182 INT, V183 INT, V184 INT, V185 INT, V186 INT, V187 INT, V188 INT, V189 INT, V190 INT, V191 INT, 
		V192 INT, V193 INT, V194 INT, V195 INT, V196 INT, V197 INT, V198 INT, V199 INT, V200 INT, V201 INT, V202 INT, V203 INT, V204 INT, V205 INT, V206 INT, V207 INT, 
		V208 INT, V209 INT, V210 INT, V211 INT, V212 INT, V213 INT, V214 INT, V215 INT, V216 INT, V217 INT, V218 INT, V219 INT, V220 INT, V221 INT, V222 INT, V223 INT, 
		V224 INT, V225 INT, V226 INT, V227 INT, V228 INT, V229 INT, V230 INT, V231 INT, V232 INT, V233 INT, V234 INT, V235 INT, V236 INT, V237 INT, V238 INT, V239 INT, 
		V240 INT, V241 INT, V242 INT, V243 INT, V244 INT, V245 INT, V246 INT, V247 INT, V248 INT, V249 INT, V250 INT, V251 INT, V252 INT, V253 INT, V254 INT, V255 INT
	)
	-- Load 1 row x 256 column sketch table
	INSERT INTO [CRC].[CQ2_SKETCH_PATH8x256_NEW] WITH (TABLOCK)
		SELECT CONCEPT_PATH_ID, 
			MIN(V0) V0, MIN(V1) V1, MIN(V2) V2, MIN(V3) V3, MIN(V4) V4, MIN(V5) V5, MIN(V6) V6, MIN(V7) V7, MIN(V8) V8, MIN(V9) V9, MIN(V10) V10, MIN(V11) V11, MIN(V12) V12, MIN(V13) V13, MIN(V14) V14, MIN(V15) V15, 
			MIN(V16) V16, MIN(V17) V17, MIN(V18) V18, MIN(V19) V19, MIN(V20) V20, MIN(V21) V21, MIN(V22) V22, MIN(V23) V23, MIN(V24) V24, MIN(V25) V25, MIN(V26) V26, MIN(V27) V27, MIN(V28) V28, MIN(V29) V29, MIN(V30) V30, MIN(V31) V31, 
			MIN(V32) V32, MIN(V33) V33, MIN(V34) V34, MIN(V35) V35, MIN(V36) V36, MIN(V37) V37, MIN(V38) V38, MIN(V39) V39, MIN(V40) V40, MIN(V41) V41, MIN(V42) V42, MIN(V43) V43, MIN(V44) V44, MIN(V45) V45, MIN(V46) V46, MIN(V47) V47, 
			MIN(V48) V48, MIN(V49) V49, MIN(V50) V50, MIN(V51) V51, MIN(V52) V52, MIN(V53) V53, MIN(V54) V54, MIN(V55) V55, MIN(V56) V56, MIN(V57) V57, MIN(V58) V58, MIN(V59) V59, MIN(V60) V60, MIN(V61) V61, MIN(V62) V62, MIN(V63) V63, 
			MIN(V64) V64, MIN(V65) V65, MIN(V66) V66, MIN(V67) V67, MIN(V68) V68, MIN(V69) V69, MIN(V70) V70, MIN(V71) V71, MIN(V72) V72, MIN(V73) V73, MIN(V74) V74, MIN(V75) V75, MIN(V76) V76, MIN(V77) V77, MIN(V78) V78, MIN(V79) V79, 
			MIN(V80) V80, MIN(V81) V81, MIN(V82) V82, MIN(V83) V83, MIN(V84) V84, MIN(V85) V85, MIN(V86) V86, MIN(V87) V87, MIN(V88) V88, MIN(V89) V89, MIN(V90) V90, MIN(V91) V91, MIN(V92) V92, MIN(V93) V93, MIN(V94) V94, MIN(V95) V95, 
			MIN(V96) V96, MIN(V97) V97, MIN(V98) V98, MIN(V99) V99, MIN(V100) V100, MIN(V101) V101, MIN(V102) V102, MIN(V103) V103, MIN(V104) V104, MIN(V105) V105, MIN(V106) V106, MIN(V107) V107, MIN(V108) V108, MIN(V109) V109, MIN(V110) V110, MIN(V111) V111, 
			MIN(V112) V112, MIN(V113) V113, MIN(V114) V114, MIN(V115) V115, MIN(V116) V116, MIN(V117) V117, MIN(V118) V118, MIN(V119) V119, MIN(V120) V120, MIN(V121) V121, MIN(V122) V122, MIN(V123) V123, MIN(V124) V124, MIN(V125) V125, MIN(V126) V126, MIN(V127) V127, 
			MIN(V128) V128, MIN(V129) V129, MIN(V130) V130, MIN(V131) V131, MIN(V132) V132, MIN(V133) V133, MIN(V134) V134, MIN(V135) V135, MIN(V136) V136, MIN(V137) V137, MIN(V138) V138, MIN(V139) V139, MIN(V140) V140, MIN(V141) V141, MIN(V142) V142, MIN(V143) V143, 
			MIN(V144) V144, MIN(V145) V145, MIN(V146) V146, MIN(V147) V147, MIN(V148) V148, MIN(V149) V149, MIN(V150) V150, MIN(V151) V151, MIN(V152) V152, MIN(V153) V153, MIN(V154) V154, MIN(V155) V155, MIN(V156) V156, MIN(V157) V157, MIN(V158) V158, MIN(V159) V159, 
			MIN(V160) V160, MIN(V161) V161, MIN(V162) V162, MIN(V163) V163, MIN(V164) V164, MIN(V165) V165, MIN(V166) V166, MIN(V167) V167, MIN(V168) V168, MIN(V169) V169, MIN(V170) V170, MIN(V171) V171, MIN(V172) V172, MIN(V173) V173, MIN(V174) V174, MIN(V175) V175, 
			MIN(V176) V176, MIN(V177) V177, MIN(V178) V178, MIN(V179) V179, MIN(V180) V180, MIN(V181) V181, MIN(V182) V182, MIN(V183) V183, MIN(V184) V184, MIN(V185) V185, MIN(V186) V186, MIN(V187) V187, MIN(V188) V188, MIN(V189) V189, MIN(V190) V190, MIN(V191) V191, 
			MIN(V192) V192, MIN(V193) V193, MIN(V194) V194, MIN(V195) V195, MIN(V196) V196, MIN(V197) V197, MIN(V198) V198, MIN(V199) V199, MIN(V200) V200, MIN(V201) V201, MIN(V202) V202, MIN(V203) V203, MIN(V204) V204, MIN(V205) V205, MIN(V206) V206, MIN(V207) V207, 
			MIN(V208) V208, MIN(V209) V209, MIN(V210) V210, MIN(V211) V211, MIN(V212) V212, MIN(V213) V213, MIN(V214) V214, MIN(V215) V215, MIN(V216) V216, MIN(V217) V217, MIN(V218) V218, MIN(V219) V219, MIN(V220) V220, MIN(V221) V221, MIN(V222) V222, MIN(V223) V223, 
			MIN(V224) V224, MIN(V225) V225, MIN(V226) V226, MIN(V227) V227, MIN(V228) V228, MIN(V229) V229, MIN(V230) V230, MIN(V231) V231, MIN(V232) V232, MIN(V233) V233, MIN(V234) V234, MIN(V235) V235, MIN(V236) V236, MIN(V237) V237, MIN(V238) V238, MIN(V239) V239, 
			MIN(V240) V240, MIN(V241) V241, MIN(V242) V242, MIN(V243) V243, MIN(V244) V244, MIN(V245) V245, MIN(V246) V246, MIN(V247) V247, MIN(V248) V248, MIN(V249) V249, MIN(V250) V250, MIN(V251) V251, MIN(V252) V252, MIN(V253) V253, MIN(V254) V254, MIN(V255) V255
		FROM [CRC].[CQ2_SKETCH_PATH15x256_NEW] WITH (NOLOCK)
		GROUP BY CONCEPT_PATH_ID
	-- Add a primary key to the 1 row x 256 column sketch table
	ALTER TABLE [CRC].[CQ2_SKETCH_PATH8x256_NEW] ADD PRIMARY KEY (CONCEPT_PATH_ID) WITH (SORT_IN_TEMPDB=ON, DATA_COMPRESSION=PAGE)

	-- Drop temp table
	DROP TABLE #CQ2_SKETCH_PATH15

END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateStep5SwapTables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Append "_OLD" to the current tables 
	-------------------------------------------------------------

	-- Data tables
	EXEC sp_rename 'CRC.PATIENT_DIMENSION', 'PATIENT_DIMENSION_OLD';
	EXEC sp_rename 'CRC.VISIT_DIMENSION', 'VISIT_DIMENSION_OLD';
	EXEC sp_rename 'CRC.OBSERVATION_FACT', 'OBSERVATION_FACT_OLD';
	EXEC sp_rename 'CRC.CONCEPT_DIMENSION', 'CONCEPT_DIMENSION_OLD';
	-- CQ2 tables
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_CONCEPT_PATIENT', 'CQ2_FACT_COUNTS_CONCEPT_PATIENT_OLD';
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_CONCEPT', 'CQ2_FACT_COUNTS_CONCEPT_OLD';
	EXEC sp_rename 'CRC.CQ2_CONCEPT_PATH', 'CQ2_CONCEPT_PATH_OLD';
	EXEC sp_rename 'CRC.CQ2_CONCEPT_PATH_CODE', 'CQ2_CONCEPT_PATH_CODE_OLD';
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_PATH_PATIENT', 'CQ2_FACT_COUNTS_PATH_PATIENT_OLD';
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_PATH', 'CQ2_FACT_COUNTS_PATH_OLD';
	EXEC sp_rename 'CRC.CQ2_SKETCH_PATH15x256', 'CQ2_SKETCH_PATH15x256_OLD';
	EXEC sp_rename 'CRC.CQ2_SKETCH_PATH8x256', 'CQ2_SKETCH_PATH8x256_OLD';
	EXEC sp_rename 'CRC.CQ2_SKETCH_PATIENT', 'CQ2_SKETCH_PATIENT_OLD';

	-------------------------------------------------------------
	-- Remove "_NEW" from the new tables
	-------------------------------------------------------------

	-- Data tables	
	EXEC sp_rename 'CRC.PATIENT_DIMENSION_NEW', 'PATIENT_DIMENSION';
	EXEC sp_rename 'CRC.VISIT_DIMENSION_NEW', 'VISIT_DIMENSION';
	EXEC sp_rename 'CRC.OBSERVATION_FACT_NEW', 'OBSERVATION_FACT';
	EXEC sp_rename 'CRC.CONCEPT_DIMENSION_NEW', 'CONCEPT_DIMENSION';
	-- CQ2 tables
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_CONCEPT_PATIENT_NEW', 'CQ2_FACT_COUNTS_CONCEPT_PATIENT';
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_CONCEPT_NEW', 'CQ2_FACT_COUNTS_CONCEPT';
	EXEC sp_rename 'CRC.CQ2_CONCEPT_PATH_NEW', 'CQ2_CONCEPT_PATH';
	EXEC sp_rename 'CRC.CQ2_CONCEPT_PATH_CODE_NEW', 'CQ2_CONCEPT_PATH_CODE';
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_PATH_PATIENT_NEW', 'CQ2_FACT_COUNTS_PATH_PATIENT';
	EXEC sp_rename 'CRC.CQ2_FACT_COUNTS_PATH_NEW', 'CQ2_FACT_COUNTS_PATH';
	EXEC sp_rename 'CRC.CQ2_SKETCH_PATH15x256_NEW', 'CQ2_SKETCH_PATH15x256';
	EXEC sp_rename 'CRC.CQ2_SKETCH_PATH8x256_NEW', 'CQ2_SKETCH_PATH8x256';
	EXEC sp_rename 'CRC.CQ2_SKETCH_PATIENT_NEW', 'CQ2_SKETCH_PATIENT';

	-------------------------------------------------------------
	-- Swap the ontology tables (customize)
	-------------------------------------------------------------

	/*
	EXEC sp_rename 'ONT.I2B2', 'I2B2_OLD';
	EXEC sp_rename 'ONT.I2B2_NEW', 'I2B2';
	*/

END
GO
GO
CREATE PROCEDURE [CRC].[uspUpdateStep6DropOldTables]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-------------------------------------------------------------
	-- Drop "_OLD" tables 
	-------------------------------------------------------------

	-- Data tables
	DROP TABLE CRC.PATIENT_DIMENSION_OLD;
	DROP TABLE CRC.VISIT_DIMENSION_OLD;
	DROP TABLE CRC.OBSERVATION_FACT_OLD;
	DROP TABLE CRC.CONCEPT_DIMENSION_OLD;
	-- CQ2 tables
	DROP TABLE CRC.CQ2_FACT_COUNTS_CONCEPT_PATIENT_OLD;
	DROP TABLE CRC.CQ2_FACT_COUNTS_CONCEPT_OLD;
	DROP TABLE CRC.CQ2_CONCEPT_PATH_OLD;
	DROP TABLE CRC.CQ2_CONCEPT_PATH_CODE_OLD;
	DROP TABLE CRC.CQ2_FACT_COUNTS_PATH_PATIENT_OLD;
	DROP TABLE CRC.CQ2_FACT_COUNTS_PATH_OLD;
	DROP TABLE CRC.CQ2_SKETCH_PATH15x256_OLD;
	DROP TABLE CRC.CQ2_SKETCH_PATH8x256_OLD;
	DROP TABLE CRC.CQ2_SKETCH_PATIENT_OLD;
	-- Ontology tables
	/*
	DROP TABLE ONT.I2B2_OLD;
	*/

END
GO
GO
CREATE PROCEDURE [HIVE].[uspGetCellSchema]
	@Service VARCHAR(100),
	@DomainID VARCHAR(50),
	@UserID VARCHAR(50),
	@ProjectID VARCHAR(50),
	@Cell VARCHAR(100) = NULL OUTPUT,
	@CellSchema VARCHAR(100) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @DBLookupTable VARCHAR(100)
	DECLARE @ProjectPath VARCHAR(255)
	DECLARE @sql NVARCHAR(MAX)

	-- Get the cell
	SELECT @Cell = CELL, @DBLookupTable = DB_LOOKUP_TABLE
		FROM HIVE.SERVICE_LOOKUP
		WHERE [SERVICE] = @Service

	-- Get the cell schema
	IF (@DBLookupTable IS NULL)
	BEGIN
		SELECT @CellSchema = @Cell
	END
	ELSE
	BEGIN
		SELECT	@ProjectPath = PROJECT_PATH
			FROM PM.PM_PROJECT_DATA
			WHERE PROJECT_ID = @ProjectID
		IF (@DomainID IS NOT NULL) AND (@ProjectPath IS NOT NULL)
		BEGIN
			SELECT @sql = 'SELECT @CellSchemaOUT = C_DB_FULLSCHEMA 
							FROM '+@DBLookupTable+' 
							WHERE C_DOMAIN_ID = '''+REPLACE(@DomainID,'''','''''')+''' 
								AND C_PROJECT_PATH = '''+REPLACE(@ProjectPath,'''','''''')+'''
								AND C_OWNER_ID IN (''@'','''+REPLACE(@UserID,'''','''''')+''')
							ORDER BY (CASE WHEN C_OWNER_ID = ''@'' THEN 1 ELSE 0 END)'
			EXEC sp_executesql @sql,
								N'@CellSchemaOUT VARCHAR(100) OUTPUT',
								@CellSchemaOUT = @CellSchema OUTPUT
		END
	END

END
GO
GO
CREATE PROCEDURE [HIVE].[uspGetMessageHeader]
	@RequestXML XML,
	@SendingAppName NVARCHAR(MAX),
	@SendingAppVersion NVARCHAR(MAX),
	@ReceivingAppName NVARCHAR(MAX),
	@ReceivingAppVersion NVARCHAR(MAX),
	@MessageHeader NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @MessageNum NVARCHAR(100)
	DECLARE @InstanceNum NVARCHAR(100)
	DECLARE @ProjectID NVARCHAR(MAX)

	DECLARE @Domain NVARCHAR(MAX)
	DECLARE @Username NVARCHAR(MAX)
	DECLARE @Password NVARCHAR(MAX)

	-- Extract variables from the request message_header
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as i2b2
	)
	SELECT	@Domain = x.value('security[1]/domain[1]','NVARCHAR(MAX)'),
			@Username = x.value('security[1]/username[1]','NVARCHAR(MAX)'),
			@Password = x.value('security[1]/password[1]','NVARCHAR(MAX)'),
			@MessageNum = @RequestXML.value('i2b2:request[1]/message_header[1]/message_control_id[1]/message_num[1]','NVARCHAR(100)'),
			@InstanceNum = @RequestXML.value('i2b2:request[1]/message_header[1]/message_control_id[1]/instance_num[1]','NVARCHAR(100)'),
			@ProjectID = @RequestXML.value('i2b2:request[1]/message_header[1]/project_id[1]','NVARCHAR(100)')
	FROM @RequestXML.nodes('i2b2:request[1]/message_header[1]') AS R(x)

	-- Generate a message_num if one doesn't exist in the request	
	IF @MessageNum IS NULL
		EXEC HIVE.uspGetNewID 20, @MessageNum OUTPUT

	-- Add one to the instance_num
	SELECT @InstanceNum = (CASE WHEN IsNumeric(@InstanceNum) = 1 THEN CAST(CAST(@InstanceNum AS INT)+1 AS NVARCHAR(100)) ELSE '1' END)

	-- Form the response message_header	
	SELECT @MessageHeader = 
		'	<message_header>
				<i2b2_version_compatible>1.1</i2b2_version_compatible>
				<hl7_version_compatible>2.4</hl7_version_compatible>
				<sending_application>
					<application_name>' + ISNULL(@SendingAppName,'') + '</application_name>
					<application_version>' + ISNULL(@SendingAppVersion,'') + '</application_version>
				</sending_application>
				<sending_facility>
					<facility_name>i2b2 Hive</facility_name>
				</sending_facility>
				<receiving_application>
					<application_name>' + ISNULL(@ReceivingAppName,'') + '</application_name>
					<application_version>' + ISNULL(@ReceivingAppVersion,'') + '</application_version>
				</receiving_application>
				<receiving_facility>
					<facility_name>i2b2 Hive</facility_name>
				</receiving_facility>
				<datetime_of_message>' + CONVERT(NVARCHAR(MAX),GetDate(),127) + 'Z</datetime_of_message>
				<message_control_id>
					<message_num>' + @MessageNum + '</message_num>
					<instance_num>' + @InstanceNum + '</instance_num>
				</message_control_id>
				<processing_id>
					<processing_id>P</processing_id>
					<processing_mode>I</processing_mode>
				</processing_id>
				<accept_acknowledgement_type>AL</accept_acknowledgement_type>
				<application_acknowledgement_type>AL</application_acknowledgement_type>
				<country_code>US</country_code>
				<project_id>' + ISNULL(NULLIF(@ProjectID,''),'undefined') + '</project_id>
			</message_header>
		'

END
GO
GO
CREATE PROCEDURE [HIVE].[uspGetNewID]
	@Length INT,
	@NewID VARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @str NVARCHAR(62)
	DECLARE @i INT
	SELECT	@NewID = '',
			@i = 0,
			@str = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
	WHILE @i < @Length
	BEGIN
		SELECT @i = @i + 1
		SELECT @NewID = @NewID + SUBSTRING(@str,CAST(rand()*62 AS INT)+1,1)
	END

END
GO
GO
CREATE PROCEDURE [HIVE].[uspGetResponse]
	@Service VARCHAR(100) = NULL,
	@Operation VARCHAR(100) = NULL,
	@Request NVARCHAR(MAX) = NULL,
	@UserID VARCHAR(50) = NULL,
	@IPAddress VARCHAR(50) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Declare variables
	DECLARE @MessageID INT
	DECLARE @Cell VARCHAR(100)
	DECLARE @CellSchema VARCHAR(100)
	DECLARE @DomainID VARCHAR(50)
	DECLARE @ProjectID VARCHAR(50)
	DECLARE @RequestXML XML
	DECLARE @ResponseXML XML
	DECLARE @RequestType VARCHAR(100)
	DECLARE @ErrorNumber INT
	DECLARE @ErrorSeverity INT
	DECLARE @ErrorState INT
	DECLARE @ErrorProcedure VARCHAR(1000)
	DECLARE @ErrorLine INT
	DECLARE @ErrorMessage VARCHAR(4000)
	DECLARE @sql NVARCHAR(MAX)

	-- Log request (removing password)
	INSERT INTO HIVE.MessageLog(UserID, Service, Operation, RequestDate, IPAddress, RequestXML)
		SELECT @UserID, @Service, @Operation, GetDate(), @IPAddress,
				(CASE WHEN Pos3 > Pos2 + 1 THEN STUFF(@Request,Pos2+1,Pos3-Pos2-1,'') ELSE @Request END)
			FROM (SELECT CHARINDEX('<password',@Request) Pos1) t1
			CROSS APPLY (SELECT (CASE WHEN Pos1 > 0 THEN CHARINDEX('>',@Request,Pos1+1) ELSE 0 END) Pos2) t2
			CROSS APPLY (SELECT (CASE WHEN Pos2 > 0 THEN CHARINDEX('<',@Request,Pos2+1) ELSE 0 END) Pos3) t3
	SELECT @MessageID = @@IDENTITY

	-- Convert request to XML
	BEGIN TRY
		SELECT @RequestXML = CAST(@Request AS XML)
	END TRY
	BEGIN CATCH
		-- Capture the error
		SELECT	@ErrorNumber = ERROR_NUMBER(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE(),
				@ErrorProcedure = ERROR_PROCEDURE(),
				@ErrorLine = ERROR_LINE(),
				@ErrorMessage = ERROR_MESSAGE()
	END CATCH

	-- Get the domain and project
	SELECT	@DomainID = @RequestXML.value('/*[1]/message_header[1]/security[1]/domain[1]','varchar(50)'),
			@ProjectID = @RequestXML.value('/*[1]/message_header[1]/project_id[1]','varchar(50)')

	-- Get the cell and cell schema
	EXEC [HIVE].[uspGetCellSchema]	@Service = @Service,
									@DomainID = @DomainID,
									@UserID = @UserID,
									@ProjectID = @ProjectID,
									@Cell = @Cell OUTPUT,
									@CellSchema = @CellSchema OUTPUT

	-- Store the cell, schema, domain, and project to the message log
	UPDATE HIVE.MessageLog
		SET	Cell = @Cell,
			CellSchema = @CellSchema,
			DomainID = @DomainID,
			ProjectID = @ProjectID			
		WHERE MessageID = @MessageID

	-- Process request
	IF (@CellSchema IS NOT NULL) AND (@RequestXML IS NOT NULL)
	BEGIN
		BEGIN TRY
			SELECT @sql = 'EXEC '+CAST(@CellSchema AS NVARCHAR(MAX))+'.uspGetResponse @Service, @Operation, @RequestXML, @UserID, @RequestTypeOUT OUTPUT, @ResponseXMLOUT OUTPUT'
			EXEC sp_executesql @sql,
								N'@Service VARCHAR(100), @Operation VARCHAR(100), @RequestXML XML, @UserID VARCHAR(50), @RequestTypeOUT VARCHAR(100) OUTPUT, @ResponseXMLOUT XML OUTPUT',
								@Service = @Service, 
								@Operation = @Operation, 
								@RequestXML = @RequestXML, 
								@UserID = @UserID,
								@RequestTypeOUT = @RequestType OUTPUT,
								@ResponseXMLOUT = @ResponseXML OUTPUT
		END TRY
		BEGIN CATCH
			-- Capture the error
			SELECT	@ErrorNumber = ERROR_NUMBER(),
					@ErrorSeverity = ERROR_SEVERITY(),
					@ErrorState = ERROR_STATE(),
					@ErrorProcedure = ERROR_PROCEDURE(),
					@ErrorLine = ERROR_LINE(),
					@ErrorMessage = ERROR_MESSAGE()
		END CATCH
	END
	
	-- Store the result
	UPDATE HIVE.MessageLog
		SET	ResponseDate = GetDate(),
			DurationMS = DateDiff(ms,RequestDate,GetDate()),
			ErrorNumber = @ErrorNumber,
			ErrorSeverity = @ErrorSeverity,
			ErrorState = @ErrorState,
			ErrorProcedure = @ErrorProcedure,
			ErrorLine = @ErrorLine,
			ErrorMessage = @ErrorMessage,
			RequestType = @RequestType,
			ResponseXML = CAST(@ResponseXML AS NVARCHAR(MAX))
		WHERE MessageID = @MessageID
			
	-- Return the response message
	SELECT 0 ErrorNumber, 1 AddFormatting, @ResponseXML ResponseXML
	
END
GO
GO
CREATE PROCEDURE [HIVE].[uspGetResponseHeader]
	@Info NVARCHAR(MAX) = NULL,
	@StatusType NVARCHAR(MAX) = NULL,
	@StatusText NVARCHAR(MAX) = NULL,
	@PollingInterval NVARCHAR(MAX) = NULL,
	@PollingURL NVARCHAR(MAX) = NULL,
	@ResponseHeader NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT @ResponseHeader =	'<response_header>'
								+ ISNULL('<info>' + @Info + '</info>','')
								+ '<result_status>'
								+ '<status type="' + ISNULL(@StatusType,'ERROR') + '"' + HIVE.fnXMLValue('status',@StatusText)
								+ ISNULL('<polling_url interval_ms="' + @PollingInterval + '">' + @PollingURL + '</polling_url>','')
								+ '</result_status>'
								+ '</response_header>'

END
GO
GO
CREATE PROCEDURE [HIVE].[uspGetStandardResponse]
	@RequestXML XML,
	@SendingAppName VARCHAR(MAX),
	@SendingAppVersion VARCHAR(MAX),
	@ReceivingAppName VARCHAR(MAX),
	@ReceivingAppVersion VARCHAR(MAX),
	@Operation VARCHAR(MAX),
	@OperationProcedure VARCHAR(MAX),
	@MessageTag VARCHAR(MAX),
	@MessageNamespaces VARCHAR(MAX),
	@RequestType VARCHAR(100) = NULL OUTPUT,
	@ResponseXML XML = NULL OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Declare variables
	DECLARE @MessageHeader NVARCHAR(MAX)
	DECLARE @ResponseHeader NVARCHAR(MAX)
	DECLARE @MessageBody NVARCHAR(MAX)
	DECLARE @StatusType NVARCHAR(100)
	DECLARE @StatusText NVARCHAR(MAX)

	-- Get the message header
	EXEC HIVE.uspGetMessageHeader	@RequestXML = @RequestXML,
									@SendingAppName = @SendingAppName,
									@SendingAppVersion = @SendingAppVersion,
									@ReceivingAppName = @ReceivingAppName,
									@ReceivingAppVersion = @ReceivingAppVersion,
									@MessageHeader = @MessageHeader OUTPUT
		
	-- Get the message body
	IF @OperationProcedure IS NOT NULL
		EXEC @OperationProcedure	@Operation = @Operation,
									@RequestXML = @RequestXML,
									@RequestType = @RequestType OUTPUT,
									@StatusType = @StatusType OUTPUT,
									@StatusText = @StatusText OUTPUT,
									@MessageBody = @MessageBody OUTPUT
	ELSE
		SELECT @StatusType = 'ERROR', @StatusText = 'The requested operation is not supported'

	-- Get the response header
	EXEC HIVE.uspGetResponseHeader	@StatusType = @StatusType,
									@StatusText = @StatusText,
									@ResponseHeader = @ResponseHeader OUTPUT

	-- Form the response message
	SELECT @ResponseXML = CAST(
								'<' + @MessageTag + ' ' + @MessageNamespaces + '>'
								+ ISNULL(@MessageHeader,'')
								+ ISNULL(@ResponseHeader,'')
								+ ISNULL(@MessageBody,'')
								+ '</' + @MessageTag + '>'
							AS XML)

END
GO
GO
CREATE PROCEDURE [ONT].[uspGetResponse]
	@Service VARCHAR(100) = NULL,
	@Operation VARCHAR(100) = NULL,
	@RequestXML XML = NULL,
	@UserID VARCHAR(50) = NULL,
	@RequestType VARCHAR(100) = NULL OUTPUT,
	@ResponseXML XML = NULL OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Determine the procedure that will process the operation
	DECLARE @opProc VARCHAR(100)
	SELECT @opProc = OBJECT_SCHEMA_NAME(@@PROCID) + '.'
						+ (CASE WHEN @Operation IN ('getCategories','getChildren','getCodeInfo','getDirtyState','getModifierChildren','getModifierCodeInfo','getModifierInfo','getModifierNameInfo','getModifiers','getNameInfo','getProcessStatus','getSchemes','getTermInfo')
								THEN 'uspRunOperation'
							ELSE NULL END)

	-- Generate the ResponseXML using the standard method
	EXEC HIVE.uspGetStandardResponse
			@RequestXML = @RequestXML,
			@SendingAppName = 'Ontology Cell',
			@SendingAppVersion = '1.6',
			@ReceivingAppName = 'i2b2 Ontology',
			@ReceivingAppVersion = '1.6',
			@Operation = @Operation,
			@OperationProcedure = @opProc,
			@MessageTag = 'ns5:response',
			@MessageNamespaces = 'xmlns:ns2="http://www.i2b2.org/xsd/cell/fr/1.0/" xmlns:ns4="http://www.i2b2.org/xsd/cell/crc/psm/1.1/" xmlns:ns3="http://www.i2b2.org/xsd/cell/crc/loader/1.1/" xmlns:tns="http://ws.ontology.i2b2.harvard.edu" xmlns:ns9="http://www.i2b2.org/xsd/cell/pm/1.1/" xmlns:ns5="http://www.i2b2.org/xsd/hive/msg/1.1/" xmlns:ns6="http://www.i2b2.org/xsd/cell/ont/1.1/" xmlns:ns7="http://www.i2b2.org/xsd/cell/crc/psm/querydefinition/1.1/" xmlns:ns8="http://www.i2b2.org/xsd/cell/crc/psm/analysisdefinition/1.1/"',
			@RequestType = @RequestType OUTPUT,
			@ResponseXML = @ResponseXML OUTPUT

END
GO
GO
CREATE PROCEDURE [ONT].[uspRunOperation]
	@Operation VARCHAR(100),
	@RequestXML XML,
	@RequestType VARCHAR(100) OUTPUT,
	@StatusType NVARCHAR(100) OUTPUT,
	@StatusText NVARCHAR(MAX) OUTPUT,
	@MessageBody NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Declare variables
	DECLARE @Schema VARCHAR(100)
	DECLARE @Username VARCHAR(MAX)
	DECLARE @ProjectID VARCHAR(50)
	DECLARE @OpBody XML

	DECLARE @Type VARCHAR(10)
	DECLARE @Blob BIT
	DECLARE @Synonyms BIT
	DECLARE @Hiddens BIT
	DECLARE @Max INT
	DECLARE @Key VARCHAR(1000)
	DECLARE @Pos INT
	DECLARE @Table VARCHAR(50)
	DECLARE @Path VARCHAR(1000)
	DECLARE @TableName VARCHAR(255)
	DECLARE @TableFullName VARCHAR(1000)
	DECLARE @TableDisplayName VARCHAR(2000)
	DECLARE @AppliedPath VARCHAR(1000)
	DECLARE @AppliedConcept VARCHAR(1000)
	DECLARE @AppliedConceptTable VARCHAR(50)
	DECLARE @AppliedConceptPath VARCHAR(1000)
	DECLARE @HLevel INT
	DECLARE @Strategy VARCHAR(100)
	DECLARE @MatchStr VARCHAR(MAX)

	DECLARE @Items XML

	DECLARE @SQL NVARCHAR(MAX)

	CREATE TABLE #T (
		C_HLEVEL int,
		C_FULLNAME varchar(700),
		C_NAME varchar(2000),
		C_SYNONYM_CD char(1),
		C_VISUALATTRIBUTES char(3),
		C_TOTALNUM int,
		C_BASECODE varchar(50),
		C_METADATAXML text,
		C_FACTTABLECOLUMN varchar(50),
		C_TABLENAME varchar(50),
		C_COLUMNNAME varchar(50),
		C_COLUMNDATATYPE varchar(50),
		C_OPERATOR varchar(10),
		C_DIMCODE varchar(700),
		C_COMMENT text,
		C_TOOLTIP varchar(900),
		M_APPLIED_PATH varchar(700),
		UPDATE_DATE datetime,
		DOWNLOAD_DATE datetime,
		IMPORT_DATE datetime,
		SOURCESYSTEM_CD varchar(50),
		VALUETYPE_CD varchar(50),
		M_EXCLUSION_CD varchar(25),
		C_PATH varchar(700),
		C_SYMBOL varchar(50),
		C_KEY varchar(1000),
		C_KEY_PATH varchar(700),
		C_KEY_NAME varchar(max)
	)

	-- Get the schema
	SELECT @Schema = OBJECT_SCHEMA_NAME(@@PROCID)


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Extract variables from the RequestXML
	-- ***************************************************************************
	-- ***************************************************************************

	-- Extract variables
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns3,
		'http://www.i2b2.org/xsd/cell/ont/1.1/' as ns4
	), x AS (
		SELECT	@RequestXML.query('ns3:request[1]/message_header[1]/*') h,
				@RequestXML.query('ns3:request[1]/message_body[1]/*') b
	), y AS (
		SELECT	h,
				(CASE @Operation
					WHEN 'getCategories' THEN b.query('ns4:get_categories[1]')
					WHEN 'getModifiers' THEN b.query('ns4:get_modifiers[1]')
					WHEN 'getChildren' THEN b.query('ns4:get_children[1]')
					WHEN 'getModifierChildren' THEN b.query('ns4:get_modifier_children[1]')
					WHEN 'getTermInfo' THEN b.query('ns4:get_term_info[1]')
					WHEN 'getModifierInfo' THEN b.query('ns4:get_modifier_info[1]')
					WHEN 'getNameInfo' THEN b.query('ns4:get_name_info[1]')
					WHEN 'getModifierNameInfo' THEN b.query('ns4:get_modifier_name_info[1]')
					WHEN 'getCodeInfo' THEN b.query('ns4:get_code_info[1]')
					WHEN 'getModifierCodeInfo' THEN b.query('ns4:get_modifier_code_info[1]')
					WHEN 'getSchemes' THEN b.query('ns4:get_schemes[1]')
					ELSE NULL END) b
		FROM x
	)
	SELECT	@Username =			h.value('security[1]/username[1]','VARCHAR(MAX)'),
			@ProjectID =		h.value('project_id[1]','VARCHAR(50)'),
			@Type =				b.value('*[1]/@type[1]','VARCHAR(10)'),
			@Blob =				HIVE.fnStr2Bit(b.value('*[1]/@blob[1]','VARCHAR(10)')),
			@Synonyms =			HIVE.fnStr2Bit(b.value('*[1]/@synonyms[1]','VARCHAR(10)')),
			@Hiddens =			HIVE.fnStr2Bit(b.value('*[1]/@hiddens[1]','VARCHAR(10)')),
			@Max =				b.value('*[1]/@max[1]','INT'),
			@Key =				(CASE WHEN @Operation IN ('getChildren','getModifierChildren')
										THEN b.value('*[1]/parent[1]','VARCHAR(1000)')
									ELSE b.value('*[1]/self[1]','VARCHAR(1000)') END),
			@AppliedPath =		b.value('*[1]/applied_path[1]','VARCHAR(1000)'),
			@AppliedConcept =	b.value('*[1]/applied_concept[1]','VARCHAR(1000)'),
			@Table =			b.value('*[1]/@category[1]','VARCHAR(100)'),
			@Strategy =			b.value('*[1]/match_str[1]/@strategy[1]','VARCHAR(100)'),
			@MatchStr =			b.value('*[1]/match_str[1]','VARCHAR(MAX)'),
			@OpBody =		b.query('*[1]/*')
	FROM y

	-- Parse the key
	IF @Key IS NOT NULL
	BEGIN
		SELECT @Pos = CHARINDEX('\',@Key,3)
		IF @Pos > 1
			SELECT @Table = SUBSTRING(@Key,3,@Pos-3), @Path = SUBSTRING(@Key,@Pos,LEN(@Key))
	END

	-- Parse the applied concept
	IF @AppliedConcept IS NOT NULL
	BEGIN
		SELECT @Pos = CHARINDEX('\',@AppliedConcept,3)
		IF @Pos > 1
			SELECT @AppliedConceptTable = SUBSTRING(@AppliedConcept,3,@Pos-3), @AppliedConceptPath = SUBSTRING(@AppliedConcept,@Pos,LEN(@AppliedConcept))
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Validate variables
	-- ***************************************************************************
	-- ***************************************************************************

	-- Set default return values
 	SELECT	@StatusType = 'DONE',
 			@StatusText = 'Ontology processing completed'

	-- Validate key
	IF @Operation IN ('getModifiers','getChildren','getModifierChildren','getTermInfo','getModifierInfo','getModifierNameInfo','getModifierCodeInfo')
	BEGIN
		-- Check that a key was provided
		IF @Key IS NULL
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = (CASE WHEN @Operation IN ('getChildren','getModifierChildren')
											THEN 'No parent was provided'
										ELSE 'No self was provided'
										END),
					@MessageBody = NULL
			RETURN
		END

		-- Check that the key was valid
		IF (@Table IS NULL) OR (@Path IS NULL)
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = (CASE WHEN @Operation IN ('getChildren','getModifierChildren')
											THEN 'Invalid parent key'
										ELSE 'Invalid self key'
										END),
					@MessageBody = NULL
			RETURN
		END
	END

	-- Get table name and check table access
	IF @Operation IN ('getModifiers','getChildren','getModifierChildren','getTermInfo','getModifierInfo','getNameInfo','getModifierNameInfo','getModifierCodeInfo')
	BEGIN

		-- Check that a table code is explicitly provided if required for the operation
		IF @Operation IN ('getNameInfo')
			AND @Table IS NULL
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = 'Missing table',
					@MessageBody = NULL
			RETURN
		END

		-- Get table name from the table code
		SELECT @TableName = C_TABLE_NAME, @TableFullName = C_FULLNAME, @TableDisplayName = C_NAME
			FROM ..TABLE_ACCESS 
			WHERE C_TABLE_CD = @Table
				AND (ISNULL(C_PROTECTED_ACCESS,'N') <> 'Y'
					OR HIVE.fnHasUserRole(@ProjectID,@Username,'USER_PROT') = 1)

		-- Confirm the user has access to the table
		IF @TableName IS NULL
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = 'TABLE_ACCESS_DENIED',
					@MessageBody = NULL
			RETURN
		END

	END

	-- Check for the match string
	IF @Operation IN ('getNameInfo','getCodeInfo','getModifierNameInfo','getModifierCodeInfo')
	BEGIN
		IF @MatchStr IS NULL
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = 'Missing match string',
					@MessageBody = NULL
			RETURN
		END
		SELECT @MatchStr = Replace(@MatchStr,'''','''''')
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getCategories [Part 1] (root nodes)
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'getCategories'
	BEGIN
	
		INSERT INTO #T (C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_TOOLTIP, C_KEY)
			SELECT C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_FACTTABLECOLUMN, C_TABLE_NAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_TOOLTIP, '\\' + C_TABLE_CD + C_FULLNAME
				FROM ..TABLE_ACCESS
				WHERE (ISNULL(C_PROTECTED_ACCESS,'N') <> 'Y'
					OR HIVE.fnHasUserRole(@ProjectID,@Username,'USER_PROT') = 1)

	END



	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getModifiers [Part 1] (modifiers that apply to terms)
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getModifiers')
	BEGIN
		
		-- Load children into a temp table	
		SELECT @SQL = '
				SELECT C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL
				FROM '+@Schema+'.'+@TableName+'
				WHERE '''+REPLACE(@Path,'''','''''')+''' LIKE M_APPLIED_PATH
					AND C_HLEVEL = 1 
					AND ISNULL(M_EXCLUSION_CD,'''')<>''X''
					AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''I''
					'+(CASE WHEN @Hiddens = 0 THEN 'AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''H''' ELSE '' END)+'
					'+(CASE WHEN @Synonyms = 0 THEN 'AND C_SYNONYM_CD = ''N''' ELSE '' END)+'
					AND C_FULLNAME NOT IN (
						SELECT C_FULLNAME
						FROM '+@Schema+'.'+@TableName+'
						WHERE '''+REPLACE(@Path,'''','''''')+''' LIKE M_APPLIED_PATH
							AND C_HLEVEL = 1 AND ISNULL(M_EXCLUSION_CD,'''')=''X''
					)
			'

		INSERT INTO #T (C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL)
			EXEC sp_executesql @SQL

		UPDATE #T SET C_KEY = '\\' + @Table + C_FULLNAME

	END



	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getChildren [Part 1]
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getChildren','getModifierChildren')
	BEGIN

		-- Load children into a temp table	
		SELECT @SQL = '
				SELECT T.C_HLEVEL, T.C_FULLNAME, T.C_NAME, T.C_SYNONYM_CD, T.C_VISUALATTRIBUTES, T.C_TOTALNUM, T.C_BASECODE, T.C_METADATAXML, T.C_FACTTABLECOLUMN, T.C_TABLENAME, T.C_COLUMNNAME, T.C_COLUMNDATATYPE, T.C_OPERATOR, T.C_DIMCODE, T.C_COMMENT, T.C_TOOLTIP, T.M_APPLIED_PATH, T.UPDATE_DATE, T.DOWNLOAD_DATE, T.IMPORT_DATE, T.SOURCESYSTEM_CD, T.VALUETYPE_CD, T.M_EXCLUSION_CD, T.C_PATH, T.C_SYMBOL
				FROM '+@Schema+'.'+@TableName+' T, (
					SELECT TOP 1 C_HLEVEL, C_FULLNAME
					FROM '+@Schema+'.'+@TableName+'
					WHERE C_FULLNAME = '''+REPLACE(@Path,'''','''''')+'''
				) F
				WHERE T.C_HLEVEL = F.C_HLEVEL+1
					AND T.C_FULLNAME LIKE F.C_FULLNAME+''%''
					AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''I''
					'+(CASE WHEN @Hiddens = 0 THEN 'AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''H''' ELSE '' END)+'
					'+(CASE WHEN @Synonyms = 0 THEN 'AND C_SYNONYM_CD = ''N''' ELSE '' END)+'
					'+(CASE WHEN @Operation = 'getModifierChildren' AND @AppliedPath IS NOT NULL THEN 'AND M_APPLIED_PATH = '''+REPLACE(@AppliedPath,'''','''''')+'''' ELSE '' END)+'
			'

		INSERT INTO #T (C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL)
			EXEC sp_executesql @SQL

		-- Create the key
		UPDATE #T SET C_KEY = '\\' + @Table + C_FULLNAME

		-- Convert leaf nodes to folders if they have modifiers
		SELECT @SQL = '
			UPDATE t
			SET t.C_VISUALATTRIBUTES = ''F''+SUBSTRING(t.C_VISUALATTRIBUTES,2,2)
			FROM #T t
			WHERE LEFT(t.C_VISUALATTRIBUTES,1)=''L''
				AND EXISTS (
					SELECT *
					FROM '+@Schema+'.'+@TableName+' m
					WHERE t.C_FULLNAME LIKE m.M_APPLIED_PATH
						AND m.C_HLEVEL = 1
						AND ISNULL(m.M_EXCLUSION_CD,'''')<>''X''
				)
			'

		EXEC sp_executesql @SQL

	END




	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getTermInfo, getModifierInfo [Part 1] (get details about an item)
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getTermInfo','getModifierInfo')
	BEGIN

		-- Load children into a temp table	
		SELECT @SQL = '
				SELECT C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL
				FROM '+@Schema+'.'+@TableName+'
				WHERE C_FULLNAME = ''' + Replace(@Path,'''','''''') + '''
					AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''I''
					'+(CASE WHEN @Hiddens = 0 THEN 'AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''H''' ELSE '' END)+'
					'+(CASE WHEN @Synonyms = 0 THEN 'AND C_SYNONYM_CD = ''N''' ELSE '' END)+'
					'+(CASE WHEN @Operation = 'getModifierInfo' AND @AppliedPath IS NOT NULL THEN 'AND M_APPLIED_PATH = '''+REPLACE(@AppliedPath,'''','''''')+''' AND ISNULL(M_EXCLUSION_CD,'''')<>''X'' ' ELSE '' END)+'
			'

		INSERT INTO #T (C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL)
			EXEC sp_executesql @SQL

		UPDATE #T SET C_KEY = '\\' + @Table + C_FULLNAME

	END



	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getNameInfo, getModifierNameInfo [Part 1] (search for items by name)
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getNameInfo','getModifierNameInfo')
	BEGIN

		-- Load children into a temp table	
		SELECT @SQL = '
				SELECT C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL
				FROM '+@Schema+'.'+@TableName+'
				WHERE C_FULLNAME LIKE '''+Replace(@TableFullName,'''','''''')+'%''
					AND C_NAME LIKE '+(CASE @Strategy	WHEN 'contains' THEN '''%'+@MatchStr+'%''' 
														WHEN 'exact' THEN ''''+@MatchStr+''''
														WHEN 'right' THEN '''%'+@MatchStr+''''
														ELSE ''''+@MatchStr+'%''' END)+'
					AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''I''
					'+(CASE WHEN @Hiddens = 0 THEN 'AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''H''' ELSE '' END)+'
					'+(CASE WHEN @Synonyms = 0 THEN 'AND C_SYNONYM_CD = ''N''' ELSE '' END)+'
					'+(CASE WHEN @Operation = 'getModifierNameInfo' THEN 'AND '''+REPLACE(@Path,'''','''''')+''' LIKE M_APPLIED_PATH AND ISNULL(M_EXCLUSION_CD,'''')<>''X'' ' ELSE '' END)+'
			'

		INSERT INTO #T (C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL)
			EXEC sp_executesql @SQL

		UPDATE #T 
			SET C_KEY = '\\' + @Table + C_FULLNAME,
				C_KEY_PATH = C_FULLNAME,
				C_KEY_NAME = (CASE WHEN @Operation = 'getNameInfo' THEN '\'+REPLACE(C_NAME,'\','|')+'\' ELSE NULL END)


		IF @Operation = 'getNameInfo'
		BEGIN
			-- Add the parent path names to the front of the key name
			DECLARE @LoopNum INT
			SELECT @LoopNum=0
			WHILE (@LoopNum<20)
			BEGIN
				UPDATE #t
					SET C_KEY_PATH = LEFT(C_KEY_PATH,LEN(C_KEY_PATH)-CHARINDEX('\',REVERSE(C_KEY_PATH),2)+1)
					WHERE C_KEY_PATH LIKE @TableFullName+'_%'
				IF (@@ROWCOUNT=0)
					SELECT @LoopNum=100
				SELECT @SQL = '
					UPDATE t
					SET t.C_KEY_NAME = ''\''+REPLACE(o.C_NAME,''\'',''|'')+t.C_KEY_NAME
					FROM #t t
						INNER JOIN '+@Schema+'.'+@TableName+' o
							ON t.C_KEY_PATH = o.C_FULLNAME
								AND o.M_APPLIED_PATH=''@'' AND o.C_SYNONYM_CD=''N''
					WHERE t.C_KEY_PATH LIKE '''+REPLACE(@TableFullName,'''','''''')+'_%'''
				EXEC sp_executesql @SQL
				SELECT @LoopNum=@LoopNum+1
			END
			-- Add the table display name to the front of the key name
			UPDATE #T
				SET C_KEY_NAME = '\'+REPLACE(@TableDisplayName,'\','|')+C_KEY_NAME
				WHERE C_KEY_PATH = @TableFullName
		END

	END



	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getCodeInfo, getModifierCodeInfo [Part 1] (search for items by code)
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getCodeInfo','getModifierCodeInfo')
	BEGIN

		-- Load matching nodes into a temp table
		SELECT @SQL = ''
		SELECT @SQL = @SQL + (CASE WHEN @SQL = '' THEN '' ELSE ' UNION ALL ' END)
			+ '	SELECT C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL, 
						''\\'+C_TABLE_CD+''' + C_FULLNAME C_KEY
					FROM '+@Schema+'.'+C_TABLE_NAME+'
					WHERE C_BASECODE LIKE '+(CASE @Strategy	WHEN 'contains' THEN '''%'+@MatchStr+'%''' 
															WHEN 'exact' THEN ''''+@MatchStr+''''
															WHEN 'right' THEN '''%'+@MatchStr+''''
															ELSE ''''+@MatchStr+'%''' END)+'
						AND C_FULLNAME LIKE '''+REPLACE(C_FULLNAME,'''','''''')+'%''
						AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''I''
						'+(CASE WHEN @Hiddens = 0 THEN 'AND SUBSTRING(C_VISUALATTRIBUTES,2,1) <> ''H''' ELSE '' END)+'
						'+(CASE WHEN @Synonyms = 0 THEN 'AND C_SYNONYM_CD = ''N''' ELSE '' END)+'
						'+(CASE WHEN @Operation = 'getModifierCodeInfo' THEN 'AND '''+REPLACE(@Path,'''','''''')+''' LIKE M_APPLIED_PATH AND ISNULL(M_EXCLUSION_CD,'''')<>''X'' ' ELSE '' END)+'
				'
			FROM (
				SELECT C_TABLE_CD, C_TABLE_NAME, C_FULLNAME
				FROM ..TABLE_ACCESS
				WHERE C_TABLE_CD = (CASE WHEN @Operation = 'getModifierCodeInfo' THEN @Table ELSE C_TABLE_CD END)
					AND (ISNULL(C_PROTECTED_ACCESS,'N') <> 'Y'
						OR HIVE.fnHasUserRole(@ProjectID,@Username,'USER_PROT') = 1)

			) T

		INSERT INTO #T (C_HLEVEL, C_FULLNAME, C_NAME, C_SYNONYM_CD, C_VISUALATTRIBUTES, C_TOTALNUM, C_BASECODE, C_METADATAXML, C_FACTTABLECOLUMN, C_TABLENAME, C_COLUMNNAME, C_COLUMNDATATYPE, C_OPERATOR, C_DIMCODE, C_COMMENT, C_TOOLTIP, M_APPLIED_PATH, UPDATE_DATE, DOWNLOAD_DATE, IMPORT_DATE, SOURCESYSTEM_CD, VALUETYPE_CD, M_EXCLUSION_CD, C_PATH, C_SYMBOL, C_KEY)
			EXEC sp_executesql @SQL

	END



	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getSchemes
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'getSchemes'
	BEGIN
	
		-- Form MessageBody
		SELECT	@StatusType = 'DONE',
				@StatusText = 'Ontology processing completed',
				@MessageBody = 
					'<message_body>'
					+ '<ns6:concepts>'
					+ ISNULL(CAST((
						SELECT	0 "level",
								C_KEY "key",
								C_NAME "name",
								CAST('<totalnum xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:nil="true" />' AS XML),
								(CASE WHEN @Type='core' THEN C_DESCRIPTION ELSE NULL END) "description"
						FROM ..SCHEMES
						ORDER BY C_NAME, C_KEY
						FOR XML PATH('concept'), TYPE
					) AS NVARCHAR(MAX)),'')
					+ '</ns6:concepts>'
					+ '</message_body>'
	END




	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getCategories, getModifiers, getChildren, getModifierChildren,
	-- **** getTermInfo, getModifierInfo, getNameInfo, getModifierNameInfo,
	-- **** getCodeInfo, getModifierCodeInfo [Part 2]
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getCategories', 'getModifiers', 'getChildren', 'getModifierChildren',
						'getTermInfo', 'getModifierInfo', 'getNameInfo', 'getModifierNameInfo', 
						'getCodeInfo', 'getModifierCodeInfo')
	BEGIN

		-- Check that there are not too many children
		IF @Max IS NOT NULL
			IF @Max < (SELECT COUNT(*) FROM #T)
			BEGIN
				SELECT	@StatusType = 'ERROR',
						@StatusText = 'MAX_EXCEEDED',
						@MessageBody = NULL
				RETURN
			END
		

		-- Get each item XML
		SELECT @Items = (
				SELECT	C_HLEVEL "level",
						(CASE WHEN @Operation IN ('getModifiers','getModifierChildren') THEN M_APPLIED_PATH ELSE NULL END) "applied_path",
						REPLACE(REPLACE(REPLACE(C_KEY,'&','&amp;'),'<','&lt;'),'>','&gt;') "key",
						REPLACE(REPLACE(REPLACE(C_KEY_NAME,'&','&amp;'),'<','&lt;'),'>','&gt;') "key_name",
						(CASE WHEN @Operation IN ('getModifiers','getModifierChildren') THEN C_FULLNAME ELSE NULL END) "fullname",
						REPLACE(REPLACE(REPLACE(C_NAME,'&','&amp;'),'<','&lt;'),'>','&gt;') "name",
						C_SYNONYM_CD "synonym_cd",
						C_VISUALATTRIBUTES "visualattributes",
						CASE	WHEN C_TOTALNUM IS NULL
								THEN CAST('<totalnum xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:nil="true" />' AS XML)
								ELSE CAST('<totalnum>'+CAST(C_TOTALNUM AS VARCHAR(10))+'</totalnum>' AS XML)
								END,
						REPLACE(REPLACE(REPLACE(C_BASECODE,'&','&amp;'),'<','&lt;'),'>','&gt;') "basecode",
						(CASE WHEN @Blob = 1 THEN REPLACE(CAST(C_METADATAXML AS VARCHAR(MAX)),'<?xml version="1.0"?>','') ELSE NULL END) "metadataxml",
						C_FACTTABLECOLUMN "facttablecolumn",
						C_TABLENAME "tablename",
						C_COLUMNNAME "columnname",
						C_COLUMNDATATYPE "columndatatype",
						REPLACE(REPLACE(REPLACE(C_OPERATOR,'&','&amp;'),'<','&lt;'),'>','&gt;') "operator",
						REPLACE(REPLACE(REPLACE(C_DIMCODE,'&','&amp;'),'<','&lt;'),'>','&gt;') "dimcode",
						(CASE WHEN @Blob = 1 THEN C_COMMENT ELSE NULL END) "comment",
						REPLACE(REPLACE(REPLACE(C_TOOLTIP,'&','&amp;'),'<','&lt;'),'>','&gt;') "tooltip",
						(CASE WHEN @Type = 'all' THEN UPDATE_DATE ELSE NULL END) "update_date",
						(CASE WHEN @Type = 'all' THEN DOWNLOAD_DATE ELSE NULL END)  "download_date",
						(CASE WHEN @Type = 'all' THEN IMPORT_DATE ELSE NULL END)  "import_date",
						(CASE WHEN @Type = 'all' THEN SOURCESYSTEM_CD ELSE NULL END)  "sourcesystem_cd"
				FROM #T
				ORDER BY C_NAME, C_FULLNAME
				FOR XML PATH('concept'), TYPE
			)

		--insert into x(x) select cast(@Items as varchar(max)) from #T

		-- Convert "concept" tag to "modifier" for modifiers
		IF @Operation in ('getModifiers', 'getModifierChildren','getModifierInfo','getModifierNameInfo','getModifierCodeInfo')
		BEGIN
			SELECT @Items = (
				SELECT m.x.query('*')
				FROM @Items.nodes('concept') AS m(x)
				FOR XML PATH('modifier'), TYPE
			)
		END

		-- Form MessageBody
		SELECT	@StatusType = 'DONE',
				@StatusText = 'Ontology processing completed',
				@MessageBody = 
					'<message_body>'
					+ (CASE WHEN @Operation in ('getModifiers', 'getModifierChildren') THEN '<ns6:modifiers>' ELSE '<ns6:concepts>' END)
					+ ISNULL(CAST(@Items AS NVARCHAR(MAX)),'')
					+ (CASE WHEN @Operation in ('getModifiers', 'getModifierChildren') THEN '</ns6:modifiers>' ELSE '</ns6:concepts>' END)
					+ '</message_body>'

	END



END
GO
GO
CREATE PROCEDURE [PM].[uspConvertToToken]
	@Request NVARCHAR(MAX),
	@UserID VARCHAR(50),
	@IPAddress VARCHAR(50) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Define the token timeout period
	DECLARE @TokenTimeout INT
	SELECT @TokenTimeout = 15 -- minutes

	-- Get a session_id
	DECLARE @Password VARCHAR(MAX)
	EXEC HIVE.uspGetNewID 20, @Password OUTPUT
	SELECT @Password = 'SessionKey:'+@Password
	UPDATE PM.PM_USER_SESSION
		SET EXPIRED_DATE = GetDate()
		WHERE [USER_ID] = @UserID AND (EXPIRED_DATE IS NULL OR EXPIRED_DATE > GetDate())
	INSERT INTO PM.PM_USER_SESSION (USER_ID, SESSION_ID, EXPIRED_DATE)
		SELECT @UserID, @Password, DATEADD(mi,@TokenTimeout,GetDate())

	-- Record the successful authentication
	INSERT INTO HIVE.AuthenticateLog (Username,RequestDate,IPAddress,Success)
		SELECT @UserID, GetDate(), @IPAddress, 1

	-- Create the new password tag
	DECLARE @PasswordTag VARCHAR(MAX)
	SELECT @PasswordTag = '<password token_ms_timeout="' + CAST(@TokenTimeout*60*1000 AS VARCHAR(MAX)) + '" is_token="true">'+@Password

	-- Return the new request with the password token
	SELECT (CASE WHEN Pos3 > Pos2 + 1 THEN STUFF(@Request,Pos1,Pos3-Pos1,@PasswordTag) ELSE @Request END) RequestWithToken
		FROM (SELECT CHARINDEX('<password',@Request) Pos1) t1
		CROSS APPLY (SELECT (CASE WHEN Pos1 > 0 THEN CHARINDEX('>',@Request,Pos1+1) ELSE 0 END) Pos2) t2
		CROSS APPLY (SELECT (CASE WHEN Pos2 > 0 THEN CHARINDEX('<',@Request,Pos2+1) ELSE 0 END) Pos3) t3

END
GO
GO
CREATE PROCEDURE [PM].[uspGetAuthenticate]
	@Request NVARCHAR(MAX) = NULL,
	@IPAddress VARCHAR(50) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	BEGIN TRY

		-- Declare variables
		DECLARE @RequestXML XML
		DECLARE @Username VARCHAR(50)
		DECLARE @Password VARCHAR(255)
		DECLARE @PasswordToken BIT
		DECLARE @Authenticated TINYINT
		DECLARE @TryCustomAuthenticate BIT
		
		SELECT @Authenticated = 0, @TryCustomAuthenticate = 0

		-- Convert the request message to XML
		SELECT @RequestXML = CAST(@Request AS XML)
		
		-- Extract username and password
		SELECT @Username = x.value('security[1]/username[1]','VARCHAR(50)'),
				@Password = x.value('security[1]/password[1]','VARCHAR(50)'),
				@PasswordToken = HIVE.fnStr2Bit(x.value('security[1]/password[1]/@is_token[1]','VARCHAR(10)'))
			FROM (SELECT @RequestXML.query('//security') x) t

		-- Try to authenticate
		IF @Username<>'' AND @Password<>''
		BEGIN
			SELECT @Authenticated = 1
				WHERE EXISTS (
					SELECT USER_ID
						FROM PM.PM_USER_DATA 
						WHERE [USER_ID] = @Username 
							AND [PASSWORD] = SubString(master.dbo.fn_varbintohexstr(HashBytes('MD5', @Password)),3,32)
							AND @PasswordToken = 0 
							AND [PASSWORD] <> '' 
							AND [STATUS_CD]='A'
					UNION ALL
					SELECT s.USER_ID
						FROM PM.PM_USER_SESSION s, PM.PM_USER_DATA u
						WHERE s.[USER_ID] = @Username 
							AND s.SESSION_ID = @Password
							AND (@PasswordToken = 1 OR u.[PASSWORD] = '')
							AND s.EXPIRED_DATE > GetDate()
							AND s.[USER_ID] = u.[USER_ID]
							AND u.[STATUS_CD] = 'A'
				)
			SELECT @TryCustomAuthenticate = 1
				FROM PM.PM_USER_DATA
				WHERE @Authenticated = 0
					AND [USER_ID] = @Username
					AND [PASSWORD] = ''
		END
		
		IF @TryCustomAuthenticate = 0
		BEGIN
			INSERT INTO HIVE.AuthenticateLog (Username, RequestDate, IPAddress, Success)
				SELECT @Username, GETDATE(), @IPAddress, @Authenticated
		END
				
		SELECT 0 Error, @Authenticated Authenticated, @Username Username, @Password Password, @TryCustomAuthenticate TryCustomAuthenticate

	END TRY
	BEGIN CATCH

		INSERT INTO HIVE.AuthenticateLog (Username, RequestDate, IPAddress, Success)
			SELECT NULL, GETDATE(), @IPAddress, 0

		SELECT 1 Error, 0 Authenticated, '' Username, '' Password, 0 TryCustomAuthenticate

	END CATCH
	
	
END
GO
GO
CREATE PROCEDURE [PM].[uspGetResponse]
	@Service VARCHAR(100) = NULL,
	@Operation VARCHAR(100) = NULL,
	@RequestXML XML = NULL,
	@UserID VARCHAR(50) = NULL,
	@RequestType VARCHAR(100) = NULL OUTPUT,
	@ResponseXML XML = NULL OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Determine the procedure that will process the operation
	DECLARE @opProc VARCHAR(100)
	SELECT @opProc = OBJECT_SCHEMA_NAME(@@PROCID) + '.'
						+ (CASE @Operation
							WHEN 'getServices' THEN 'uspGetServices'
							ELSE NULL END)

	-- Generate the ResponseXML using the standard method
	EXEC HIVE.uspGetStandardResponse
			@RequestXML = @RequestXML,
			@SendingAppName = 'PM Cell',
			@SendingAppVersion = '1.6',
			@ReceivingAppName = 'PM Cell',
			@ReceivingAppVersion = '1.6',
			@Operation = @Operation,
			@OperationProcedure = @opProc,
			@MessageTag = 'ns2:response',
			@MessageNamespaces = 'xmlns:ns2="http://www.i2b2.org/xsd/hive/msg/1.1/" xmlns:ns4="http://www.i2b2.org/xsd/cell/pm/1.1/" xmlns:ns3="http://www.i2b2.org/xsd/hive/msg/version/" xmlns:tns="http://ws.pm.i2b2.harvard.edu"',
			@RequestType = @RequestType OUTPUT,
			@ResponseXML = @ResponseXML OUTPUT

END
GO
GO
CREATE PROCEDURE [PM].[uspGetServices]
	@Operation VARCHAR(100),
	@RequestXML XML,
	@RequestType VARCHAR(100) OUTPUT,
	@StatusType NVARCHAR(100) OUTPUT,
	@StatusText NVARCHAR(MAX) OUTPUT,
	@MessageBody NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Declare variables
	DECLARE @Domain NVARCHAR(MAX)
	DECLARE @Username VARCHAR(MAX)
	DECLARE @Password VARCHAR(MAX)
	DECLARE @PasswordToken BIT
	DECLARE @PasswordTimeout INT
	DECLARE @ProjectID VARCHAR(50)

	-- Extract variables from the request message_header
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as i2b2
	)
	SELECT	@Domain = x.value('security[1]/domain[1]','NVARCHAR(MAX)'),
			@Username = x.value('security[1]/username[1]','VARCHAR(MAX)'),
			@Password = x.value('security[1]/password[1]','VARCHAR(MAX)'),
			@PasswordToken = HIVE.fnStr2Bit(x.value('security[1]/password[1]/@is_token[1]','VARCHAR(10)')),
			@PasswordTimeout = x.value('security[1]/password[1]/@token_ms_timeout[1]','INT'),
			@ProjectID = @RequestXML.value('i2b2:request[1]/message_header[1]/project_id[1]','VARCHAR(50)')
	FROM @RequestXML.nodes('i2b2:request[1]/message_header[1]') AS R(x)

	-- Authenticate username and password
	IF NOT EXISTS (
		SELECT USER_ID
			FROM ..PM_USER_DATA 
			WHERE [USER_ID] = @Username 
				AND [PASSWORD] = SubString(master.dbo.fn_varbintohexstr(HashBytes('MD5', @Password)),3,32)
				AND @PasswordToken = 0 
				AND [PASSWORD] <> '' 
				AND [STATUS_CD]='A'
		UNION ALL
		SELECT s.USER_ID
			FROM ..PM_USER_SESSION s, ..PM_USER_DATA u
			WHERE s.[USER_ID] = @Username 
				AND s.SESSION_ID = @Password
				AND (@PasswordToken = 1 OR u.[PASSWORD] = '')
				AND s.EXPIRED_DATE > GetDate()
				AND s.[USER_ID] = u.[USER_ID]
				AND u.[STATUS_CD] = 'A'
	)
	BEGIN
		-- Return error message
		SELECT @StatusType = 'ERROR', @StatusText = 'Username or password does not exist', @MessageBody = NULL
		RETURN
	END
	
	-- Update session
	IF @PasswordToken = 1
	BEGIN
		UPDATE ..PM_USER_SESSION
			SET EXPIRED_DATE = DATEADD(ms,ISNULL(@PasswordTimeout,0),GetDate())
			WHERE [USER_ID] = @Username AND SESSION_ID = @Password
	END
	ELSE
	BEGIN
		EXEC HIVE.uspGetNewID 20, @Password OUTPUT
		SELECT @Password = 'SessionKey:'+@Password, @PasswordTimeout = 1800000
		UPDATE ..PM_USER_SESSION
			SET EXPIRED_DATE = GetDate()
			WHERE [USER_ID] = @Username AND (EXPIRED_DATE IS NULL OR EXPIRED_DATE > GetDate())
		INSERT INTO ..PM_USER_SESSION (USER_ID, SESSION_ID, EXPIRED_DATE)
			SELECT @Username, @Password, DATEADD(ms,@PasswordTimeout,GetDate())
	END

	-- Get project list
	DECLARE @ProjectList TABLE (ProjectID VARCHAR(50))
	INSERT INTO @ProjectList (ProjectID)
		SELECT DISTINCT r.PROJECT_ID
			FROM ..PM_PROJECT_USER_ROLES r, ..PM_PROJECT_DATA p
			WHERE r.USER_ID = @Username
				AND r.PROJECT_ID = (CASE WHEN ISNULL(NULLIF(@ProjectID,''),'undefined') = 'undefined' THEN r.PROJECT_ID ELSE @ProjectID END)
				AND r.PROJECT_ID = p.PROJECT_ID
				AND r.STATUS_CD = 'A'
				AND p.STATUS_CD = 'A'

	-- Form MessageBody
	SELECT	@StatusType = 'DONE',
			@StatusText = 'PM processing completed',
			@MessageBody = 
				'<message_body>'
				+ '<ns4:configure>'
				+ CAST((
					SELECT TOP 1
						ENVIRONMENT_CD "environment",
						HELPURL "helpURL",
						(
							SELECT	FULL_NAME "full_name",
									@Username "user_name",
									@PasswordTimeout "password/@token_ms_timeout",
									'true' "password/@is_token",
									@Password "password",
									@Domain "domain",
									'false' "is_admin",
									(
										SELECT	PROJECT_ID "@id",
												PROJECT_NAME "name",
												PROJECT_WIKI "wiki",
												PROJECT_PATH "path",
												(
													SELECT USER_ROLE_CD "role"
														FROM ..PM_PROJECT_USER_ROLES r
														WHERE r.PROJECT_ID = d.PROJECT_ID AND USER_ID = @Username
															AND r.STATUS_CD = 'A'
														FOR XML PATH(''), TYPE
												),
												(
													SELECT	PARAM_NAME_CD "param/@name",
															VALUE "param"
													FROM ..PM_PROJECT_PARAMS p
													WHERE p.PROJECT_ID = d.PROJECT_ID
														AND p.STATUS_CD = 'A'
													FOR XML PATH(''), TYPE
												)
											FROM ..PM_PROJECT_DATA d
											WHERE PROJECT_ID IN (SELECT ProjectID FROM @ProjectList)
											FOR XML PATH('project'), TYPE
									),
									(
										SELECT	PARAM_NAME_CD "param/@name",
												VALUE "param"
										FROM ..PM_USER_PARAMS
										WHERE USER_ID = @Username
											AND STATUS_CD = 'A'
										FOR XML PATH(''), TYPE
									)
								FROM ..PM_USER_DATA
								WHERE USER_ID = @Username
								FOR XML PATH(''), TYPE
						) "user",
						DOMAIN_NAME "domain_name",
						DOMAIN_ID "domain_id",
						'true' "active",
						(
							SELECT	PARAM_NAME_CD "param/@name",
									VALUE "param"
							FROM ..PM_HIVE_PARAMS p
							WHERE p.DOMAIN_ID = h.DOMAIN_ID
								AND p.STATUS_CD = 'A'
							FOR XML PATH(''), TYPE
						),
						(
							SELECT	CELL_ID "cell_data/@id",
									NAME "cell_data/name",
									URL "cell_data/url",
									PROJECT_PATH "cell_data/project_path",
									METHOD_CD "cell_data/method",
									(CASE WHEN CAN_OVERRIDE = 1 THEN 'true' ELSE 'false' END) "cell_data/can_override",
									(
										SELECT	PARAM_NAME_CD "param/@name",
												VALUE "param"
										FROM ..PM_CELL_PARAMS p
										WHERE p.CELL_ID = t.CELL_ID
											--PROJECT_PATH
											AND STATUS_CD = 'A'
										FOR XML PATH(''), TYPE
									) "cell_data"
								FROM (
									SELECT	c.CELL_ID, c.PROJECT_PATH, c.NAME, c.METHOD_CD, c.URL, c.CAN_OVERRIDE,
										ROW_NUMBER() OVER (PARTITION BY c.CELL_ID ORDER BY c.PROJECT_PATH DESC) k
									FROM ..PM_CELL_DATA c, ..PM_PROJECT_DATA p
									WHERE p.PROJECT_ID IN (SELECT ProjectID FROM @ProjectList)
										AND p.PROJECT_PATH LIKE c.PROJECT_PATH+'%'
										AND c.STATUS_CD = 'A'
								) t
								WHERE k = 1
								FOR XML PATH(''), TYPE
						) "cell_datas"
					FROM ..PM_HIVE_DATA h
					WHERE ACTIVE = 1 AND STATUS_CD = 'A'
					FOR XML PATH(''), TYPE
				) AS NVARCHAR(MAX))
				+ '</ns4:configure>'
				+ '</message_body>'

END
GO
GO
CREATE PROCEDURE [PM].[uspRegister]
	@user_id VARCHAR(50),
	@project_id VARCHAR(50)='Demo'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Quit if no user_id is defined
	IF ISNULL(@user_id,'') = ''
		RETURN

	-- Make sure the user exists and is associated with the project
	IF NOT EXISTS (SELECT * FROM PM.PM_USER_DATA WHERE USER_ID = @user_id)
	BEGIN
		INSERT INTO PM.PM_USER_DATA (USER_ID, FULL_NAME, PASSWORD, ENTRY_DATE, STATUS_CD)
			SELECT @user_id, @user_id, '', GetDate(), 'A'
		IF NOT EXISTS (SELECT * FROM PM.PM_PROJECT_USER_ROLES WHERE PROJECT_ID = @project_id AND USER_ID = @user_id)
			INSERT INTO PM.PM_PROJECT_USER_ROLES (PROJECT_ID, USER_ID, USER_ROLE_CD, ENTRY_DATE, STATUS_CD)
				SELECT @project_id, @user_id, 'DATA_OBFSC', GetDate(), 'A'
	END

	-- Make sure the user has a root workplace folder
	IF NOT EXISTS (SELECT * FROM WORK.WORKPLACE_ACCESS WHERE C_USER_ID = @user_id)
	BEGIN
		INSERT INTO WORK.WORKPLACE_ACCESS (C_TABLE_CD, C_TABLE_NAME, C_PROTECTED_ACCESS, C_HLEVEL, C_NAME, C_USER_ID, C_GROUP_ID, 
				C_SHARE_ID, C_INDEX, C_PARENT_INDEX, C_VISUALATTRIBUTES, C_TOOLTIP, C_ENTRY_DATE, C_CHANGE_DATE, C_STATUS_CD)
			SELECT 'WORK', 'WORKPLACE', 'N', 0, UPPER(@user_id), UPPER(@user_id), @project_id, 
				'N', CAST(NEWID() AS VARCHAR(50)), NULL, 'CA ', '@', GETDATE(), GETDATE(), 'A'
	END

	-- Get a session_id
	DECLARE @password VARCHAR(MAX)
	EXEC HIVE.uspGetNewID 20, @password OUTPUT
	SELECT @password = 'SessionKey:'+@password
	UPDATE PM.PM_USER_SESSION
		SET EXPIRED_DATE = GetDate()
		WHERE [USER_ID] = @user_id AND (EXPIRED_DATE IS NULL OR EXPIRED_DATE > GetDate())
	INSERT INTO PM.PM_USER_SESSION (USER_ID, SESSION_ID, EXPIRED_DATE)
		SELECT @user_id, @password, DATEADD(mi,15,GetDate())
	SELECT @password SESSION_ID

END
GO
GO
CREATE PROCEDURE [WORK].[uspGetResponse]
	@Service VARCHAR(100) = NULL,
	@Operation VARCHAR(100) = NULL,
	@RequestXML XML = NULL,
	@UserID VARCHAR(50) = NULL,
	@RequestType VARCHAR(100) = NULL OUTPUT,
	@ResponseXML XML = NULL OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Determine the procedure that will process the operation
	DECLARE @opProc VARCHAR(100)
	SELECT @opProc = OBJECT_SCHEMA_NAME(@@PROCID) + '.'
						+ (CASE WHEN @Operation IN ('annotateChild','getFoldersByProject','deleteChild','getChildren','addChild','renameChild','moveChild','getFoldersByUserId')
								THEN 'uspRunOperation'
							ELSE NULL END)

	-- Generate the ResponseXML using the standard method
	EXEC HIVE.uspGetStandardResponse
			@RequestXML = @RequestXML,
			@SendingAppName = 'Workplace Cell',
			@SendingAppVersion = '1.6',
			@ReceivingAppName = 'i2b2 Ontology',
			@ReceivingAppVersion = '1.6',
			@Operation = @Operation,
			@OperationProcedure = @opProc,
			@MessageTag = 'ns3:response',
			@MessageNamespaces = 'xmlns:ns2="http://www.i2b2.org/xsd/cell/crc/psm/1.1/" xmlns:ns4="http://www.i2b2.org/xsd/cell/work/1.1/" xmlns:ns3="http://www.i2b2.org/xsd/hive/msg/1.1/" xmlns:tns="http://ws.workplace.i2b2.harvard.edu" xmlns:ns5="http://www.i2b2.org/xsd/cell/crc/psm/querydefinition/1.1/" xmlns:ns6="http://www.i2b2.org/xsd/cell/crc/psm/analysisdefinition/1.1/" xmlns:ns7="http://www.i2b2.org/xsd/cell/pm/1.1/"',
			@RequestType = @RequestType OUTPUT,
			@ResponseXML = @ResponseXML OUTPUT

END
GO
GO
CREATE PROCEDURE [WORK].[uspRunOperation]
	@Operation VARCHAR(100),
	@RequestXML XML,
	@RequestType VARCHAR(100) OUTPUT,
	@StatusType NVARCHAR(100) OUTPUT,
	@StatusText NVARCHAR(MAX) OUTPUT,
	@MessageBody NVARCHAR(MAX) OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Declare variables
	DECLARE @Schema VARCHAR(100)
	DECLARE @Username VARCHAR(MAX)
	DECLARE @ProjectID VARCHAR(50)
	DECLARE @OpBody XML

	DECLARE @Blob BIT
	DECLARE @Category VARCHAR(1000)
	DECLARE @Max INT
	DECLARE @Node VARCHAR(255)
	DECLARE @Type VARCHAR(10)

	DECLARE @Path VARCHAR(1000)
	DECLARE @Pos INT
	DECLARE @PathTable VARCHAR(255)
	DECLARE @PathIndex VARCHAR(255)
	DECLARE @TableName VARCHAR(255)

	DECLARE @SQL NVARCHAR(MAX)

	CREATE TABLE #T (
		C_NAME varchar(255),
		C_USER_ID varchar(255),
		C_GROUP_ID varchar(255),
		C_SHARE_ID varchar(255),
		C_INDEX varchar(255),
		C_PARENT_INDEX varchar(255),
		C_VISUALATTRIBUTES char(3),
		C_PROTECTED_ACCESS char(1),
		C_TOOLTIP varchar(900),
		C_WORK_XML varchar(max),
		C_WORK_XML_SCHEMA varchar(max),
		C_WORK_XML_I2B2_TYPE varchar(255),
		C_ENTRY_DATE datetime,
		C_CHANGE_DATE datetime,
		C_STATUS_CD char(1)
	)

	-- Get the schema
	SELECT @Schema = OBJECT_SCHEMA_NAME(@@PROCID)


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Extract variables from the RequestXML
	-- ***************************************************************************
	-- ***************************************************************************

	-- Extract variables
	;WITH XMLNAMESPACES (
		'http://www.i2b2.org/xsd/hive/msg/1.1/' as ns3,
		'http://www.i2b2.org/xsd/cell/work/1.1/' as ns4
	), x AS (
		SELECT	@RequestXML.query('ns3:request[1]/message_header[1]/*') h,
				@RequestXML.query('ns3:request[1]/message_body[1]/*') b
	), y AS (
		SELECT	h,
				(CASE @Operation
					WHEN 'addChild' THEN b.query('ns4:add_child[1]')
					WHEN 'annotateChild' THEN b.query('ns4:annotate_child[1]')
					WHEN 'deleteChild' THEN b.query('ns4:delete_child[1]')
					WHEN 'moveChild' THEN b.query('ns4:move_child[1]')
					WHEN 'renameChild' THEN b.query('ns4:rename_child[1]')
					WHEN 'getFoldersByUserId' THEN b.query('ns4:get_folders_by_userId[1]')
					WHEN 'getFoldersByProject' THEN b.query('ns4:get_folders_by_project[1]')
					WHEN 'getChildren' THEN b.query('ns4:get_children[1]')
					ELSE NULL END) b
		FROM x
	)
	SELECT	@Username =		h.value('security[1]/username[1]','VARCHAR(MAX)'),
			@ProjectID =	h.value('project_id[1]','VARCHAR(50)'),
			@Blob =			HIVE.fnStr2Bit(b.value('*[1]/@blob[1]','VARCHAR(MAX)')),
			@Category =		b.value('*[1]/@category[1]','VARCHAR(MAX)'),
			@Max =			b.value('*[1]/@max[1]','VARCHAR(MAX)'),
			@Node =			b.value('*[1]/@node[1]','VARCHAR(MAX)'),
			@Type =			b.value('*[1]/@type[1]','VARCHAR(MAX)'),
			@Path =			(CASE @Operation
								WHEN 'addChild' THEN b.value('*[1]/parent_index[1]','VARCHAR(MAX)')
								WHEN 'setProtectedAccess' THEN b.value('*[1]/index[1]','VARCHAR(MAX)')
								WHEN 'getChildren' THEN b.value('*[1]/parent[1]','VARCHAR(MAX)')
								ELSE b.value('*[1]/node[1]','VARCHAR(MAX)') END),
			@OpBody =		b.query('*[1]/*')
	FROM y

	-- Parse the path
	SELECT @Pos = CHARINDEX('\',@Path,3)
	IF @Pos > 1
		SELECT @PathTable = SUBSTRING(@Path,3,@Pos-3), @PathIndex = SUBSTRING(@Path,@Pos+1,LEN(@Path))


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** Validate variables
	-- ***************************************************************************
	-- ***************************************************************************

	-- Set default return values
 	SELECT	@StatusType = 'DONE',
 			@StatusText = 'Workplace processing completed'

	-- Validate Path
	IF @Operation IN ('addChild','annotateChild','deleteChild','moveChild','renameChild','setProtectedAccess','getChildren')
	BEGIN
		-- Check if a Path was provided
		IF @Path IS NULL
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = (CASE @Operation
									WHEN 'addChild' THEN 'No parent_index was provided'
									WHEN 'setProtectedAccess' THEN 'No index was provided'
									WHEN 'getChildren' THEN 'No parent was provided'
									ELSE 'No node was provided' END),
					@MessageBody = NULL
			RETURN
		END

		-- Check that the path was valid
		IF (@PathTable IS NULL) OR (@PathIndex IS NULL)
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = (CASE @Operation
									WHEN 'addChild' THEN 'Invalid parent_index key'
									WHEN 'setProtectedAccess' THEN 'Invalid index key'
									WHEN 'getChildren' THEN 'Invalid parent key'
									ELSE 'Invalid node key' END),
					@MessageBody = NULL
			RETURN
		END

		-- Confirm that the user has access to the table
		SELECT @TableName = C_TABLE_NAME
			FROM ..WORKPLACE_ACCESS 
			WHERE C_TABLE_CD = @PathTable
				AND ISNULL(C_PROTECTED_ACCESS,'N') <> 'Y'
				AND (C_GROUP_ID = '@' OR C_GROUP_ID = @ProjectID)
				AND (C_SHARE_ID = 'Y' OR C_USER_ID = '@' OR C_USER_ID = @Username)

		IF @TableName IS NULL
		BEGIN
			SELECT	@StatusType = 'ERROR',
					@StatusText = 'TABLE_ACCESS_DENIED',
					@MessageBody = NULL
			RETURN
		END

	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** addChild
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'addChild'
	BEGIN	
		-- Extract variables from request message_body
		INSERT INTO #T (C_NAME, C_USER_ID, C_GROUP_ID, C_SHARE_ID, C_INDEX, C_PARENT_INDEX, C_VISUALATTRIBUTES, C_PROTECTED_ACCESS, C_TOOLTIP, C_WORK_XML, C_WORK_XML_SCHEMA, C_WORK_XML_I2B2_TYPE, C_ENTRY_DATE, C_CHANGE_DATE, C_STATUS_CD)
		SELECT	IsNull(x.value('name[1]','VARCHAR(255)'),'@') C_NAME,
				IsNull(x.value('user_id[1]','VARCHAR(255)'),@Username) C_USER_ID,
				IsNull(x.value('group_id[1]','VARCHAR(255)'),@ProjectID) C_GROUP_ID,
				x.value('share_id[1]','VARCHAR(255)') C_SHARE_ID,
				IsNull(x.value('index[1]','VARCHAR(255)'),CAST(NEWID() AS VARCHAR(50))) C_INDEX,
				@PathIndex C_PARENT_INDEX,
				IsNull(x.value('visual_attributes[1]','VARCHAR(3)'),'LA ') C_VISUALATTRIBUTES,
				NULL C_PROTECTED_ACCESS,
				IsNull(x.value('tooltip[1]','VARCHAR(255)'),x.value('name[1]','VARCHAR(255)')) C_TOOLTIP,
				CAST(x.query('work_xml[1]/*') AS VARCHAR(MAX)) C_WORK_XML,
				NULL C_WORK_XML_SCHEMA,
				x.value('work_xml_i2b2_type[1]','VARCHAR(255)') C_WORK_XML_I2B2_TYPE,
				GetDate() C_ENTRY_DATE,
				GetDate() C_CHANGE_DATE,
				'A' C_STATUS_CD
			FROM (SELECT @OpBody AS x) T

		-- Insert the child record
		SELECT @SQL = 'INSERT INTO '+@Schema+'.'+@TableName+' SELECT * FROM #T'
		EXEC sp_executesql @SQL
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** annotateChild
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'annotateChild'
	BEGIN
		SELECT @SQL = '
				UPDATE '+@Schema+'.'+@TableName+'
				SET C_TOOLTIP = '''+REPLACE(Tooltip,'''','''''')+'''
				WHERE C_INDEX = '''+REPLACE(@PathIndex,'''','''''')+'''
			'
		FROM (
			SELECT (CASE WHEN IsNull(Tooltip,'') = '' THEN '' ELSE Tooltip END) Tooltip
			FROM (SELECT @OpBody.value('tooltip[1]','VARCHAR(255)') Tooltip) T
		) T

		EXEC sp_executesql @SQL
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** renameChild
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'renameChild'
	BEGIN
		SELECT @SQL = '
				UPDATE '+@Schema+'.'+@TableName+'
				SET C_NAME = '''+REPLACE(Name,'''','''''')+'''
				WHERE C_INDEX = '''+REPLACE(@PathIndex,'''','''''')+'''
			'
		FROM (
			SELECT (CASE WHEN IsNull(Name,'') = '' THEN '@' ELSE Name END) Name
			FROM (SELECT @OpBody.value('name[1]','VARCHAR(255)') Name) T
		) T

		EXEC sp_executesql @SQL
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** deleteChild
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'deleteChild'
	BEGIN
		SELECT @SQL = '
				UPDATE '+@Schema+'.'+@TableName+'
				SET C_STATUS_CD = ''I''
				WHERE C_INDEX = '''+REPLACE(@PathIndex,'''','''''')+'''
			'

		EXEC sp_executesql @SQL
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** moveChild
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'moveChild'
	BEGIN
		SELECT @SQL = '
				UPDATE '+@Schema+'.'+@TableName+'
				SET C_PARENT_INDEX = '''+REPLACE(Parent,'''','''''')+'''
				WHERE C_INDEX = '''+REPLACE(@PathIndex,'''','''''')+'''
			'
		FROM (SELECT @OpBody.value('parent[1]','VARCHAR(255)') Parent) T
		WHERE IsNull(Parent,'')<>''

		EXEC sp_executesql @SQL
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getFoldersByUserId [Part 1]
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'getFoldersByUserId'
	BEGIN
		INSERT INTO #T (C_NAME, C_USER_ID, C_GROUP_ID, C_SHARE_ID, C_INDEX, C_PARENT_INDEX, C_VISUALATTRIBUTES, C_PROTECTED_ACCESS, C_TOOLTIP, C_WORK_XML, C_WORK_XML_SCHEMA, C_WORK_XML_I2B2_TYPE, C_ENTRY_DATE, C_CHANGE_DATE, C_STATUS_CD)
			SELECT C_NAME, C_USER_ID, C_GROUP_ID, C_SHARE_ID, '\\'+C_TABLE_CD+'\'+C_INDEX, C_PARENT_INDEX, C_VISUALATTRIBUTES, C_PROTECTED_ACCESS, C_TOOLTIP, NULL, NULL, NULL, C_ENTRY_DATE, C_CHANGE_DATE, C_STATUS_CD
				FROM ..WORKPLACE_ACCESS
				WHERE ISNULL(C_PROTECTED_ACCESS,'N') <> 'Y'
					AND C_STATUS_CD = 'A'
					AND (C_GROUP_ID = '@' OR C_GROUP_ID = @ProjectID)
					AND (C_SHARE_ID = 'Y' OR C_USER_ID = '@' OR C_USER_ID = @Username)
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getChildren [Part 1]
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation = 'getChildren'
	BEGIN
		-- Load children into a temp table	
		SELECT @SQL = '
				SELECT T.*
				FROM '+@Schema+'.'+@TableName+' T
				WHERE T.C_PARENT_INDEX = '''+REPLACE(@PathIndex,'''','''''')+'''
					AND C_STATUS_CD = ''A''
					AND SUBSTRING(C_VISUALATTRIBUTES,2,1) = ''A''
					AND ISNULL(C_PROTECTED_ACCESS,''N'') <> ''Y''
					AND (C_GROUP_ID = ''@'' OR C_GROUP_ID = '''+REPLACE(@ProjectID,'''','''''')+''')
					AND (C_SHARE_ID = ''Y'' OR C_USER_ID = ''@'' OR C_USER_ID = '''+REPLACE(@Username,'''','''''')+''')
			'

		INSERT INTO #T (C_NAME, C_USER_ID, C_GROUP_ID, C_SHARE_ID, C_INDEX, C_PARENT_INDEX, C_VISUALATTRIBUTES, C_PROTECTED_ACCESS, C_TOOLTIP, C_WORK_XML, C_WORK_XML_SCHEMA, C_WORK_XML_I2B2_TYPE, C_ENTRY_DATE, C_CHANGE_DATE, C_STATUS_CD)
			EXEC sp_executesql @SQL

		UPDATE #T SET C_INDEX = '\\' + @PathTable + '\' + C_INDEX
	END


	-- ***************************************************************************
	-- ***************************************************************************
	-- **** getFoldersByUserId, getChildren [Part 2]
	-- ***************************************************************************
	-- ***************************************************************************

	IF @Operation IN ('getFoldersByUserId','getChildren')
	BEGIN

		-- Check that there are not too many children
		IF @Max IS NOT NULL
			IF @Max < (SELECT COUNT(*) FROM #T)
			BEGIN
				SELECT	@StatusType = 'ERROR',
						@StatusText = 'MAX_EXCEEDED',
						@MessageBody = NULL
				RETURN
			END
			
		-- Form MessageBody
		SELECT	@MessageBody = 
					'<message_body>'
					+ '<ns4:folders>'
					+ ISNULL(CAST((
						SELECT	REPLACE(REPLACE(REPLACE(C_NAME,'&','&amp;'),'<','&lt;'),'>','&gt;') "name",
								C_USER_ID "user_id",
								C_GROUP_ID "group_id",
								C_PROTECTED_ACCESS "protected_access",
								C_SHARE_ID "share_id",
								REPLACE(REPLACE(REPLACE(C_INDEX,'&','&amp;'),'<','&lt;'),'>','&gt;') "index",
								C_PARENT_INDEX "parent_index",
								C_VISUALATTRIBUTES "visual_attributes",
								REPLACE(REPLACE(REPLACE(C_TOOLTIP,'&','&amp;'),'<','&lt;'),'>','&gt;') "tooltip",
								(CASE WHEN IsNull(@Blob,1) = 1 THEN REPLACE(CAST(C_WORK_XML AS VARCHAR(MAX)),'<?xml version="1.0"?>','') ELSE NULL END) "work_xml",
								C_WORK_XML_SCHEMA "work_xml_schema",
								C_WORK_XML_I2B2_TYPE "work_xml_i2b2_type",
								(CASE WHEN @Type = 'all' THEN C_ENTRY_DATE ELSE NULL END) "entry_date",
								(CASE WHEN @Type = 'all' THEN C_CHANGE_DATE ELSE NULL END)  "change_date"
						FROM #T
						ORDER BY CAST(C_NAME AS VARBINARY(MAX)), C_INDEX
						FOR XML PATH('folder'), TYPE
					) AS NVARCHAR(MAX)),'')
					+ '</ns4:folders>'
					+ '</message_body>'
	END

END
GO
